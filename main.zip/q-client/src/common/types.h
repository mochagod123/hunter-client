#ifndef TYPES_H
#define	TYPES_H

#include <gctypes.h>

#endif	/* TYPES_H */

