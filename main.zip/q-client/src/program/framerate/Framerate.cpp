#include "Framerate.h"
#include <net/minecraft/client/Minecraft.hpp>

Framerate::Framerate() {
    this->basetime = Minecraft::currentTimeMillis();
    this->counts = 0;
    this->framerate = 0.0f;
}

float Framerate::getFramerate() {
    return this->framerate;
}

void Framerate::count() {
    ++this->counts;
    unsigned long long now = Minecraft::currentTimeMillis();
    if (now - this->basetime >= 1000)
    {
        this->framerate = (tofloat(this->counts) * 1000.0f) / (tofloat(now) - tofloat(this->basetime));
        this->basetime = now;
        this->counts = 0;
    }
}