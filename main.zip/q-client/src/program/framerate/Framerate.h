#ifndef __FRAMERATE_H__
#define __FRAMERATE_H__

#include <net/library/converter.hpp>
#include "../../dynamic_libs/os_functions.h"

class Framerate {
public:

unsigned long long    basetime;
int                   counts;
float                 framerate;
    
Framerate();

float getFramerate();

void count();

};

#endif