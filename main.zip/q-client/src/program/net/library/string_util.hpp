#ifndef __STRING_UTIL_H__
#define __STRING_UTIL_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

#endif