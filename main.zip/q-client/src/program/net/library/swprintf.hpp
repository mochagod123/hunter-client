#ifndef __SWPRINTF_H__
#define __SWPRINTF_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/client/Minecraft.hpp>
#include <net/minecraft/network/packet/clientbound/ClientboundChatPacket.hpp>
#include <net/minecraft/network/listener/ClientPacketListener.hpp>

template <typename ... Args>
inline void log(std::basic_string<wchar_t> wcstr, Args ... args) {
    wchar_t result[100];
    swprintf(result, 100, wcstr.c_str(), args ...);
    if (Minecraft::GetInstance()->thePlayer != nullptr) {
        std::basic_string<wchar_t> wcstr = result;
        boost::shared_ptr<ClientboundChatPacket> packet(ClientboundChatPacket::Ctor(nullptr, wcstr, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
        Minecraft::GetInstance()->thePlayer->listener->handleChat(packet);
    }
}

#endif