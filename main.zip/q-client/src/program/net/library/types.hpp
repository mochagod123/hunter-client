#ifndef __TYPES_H__
#define __TYPES_H__

#include <cstdint>

typedef float          float32_t;
typedef double         float64_t;
typedef long double    float128_t;

#endif