#ifndef __STRUCTURE_BLOCK_H__
#define __STRUCTURE_BLOCK_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/block/Block.hpp>

namespace link {
    static const uint32_t __ct__14StructureBlockFv = 0x02972F18;
}

class StructureBlock : public Block {
public:

    static inline StructureBlock *Ctor() {
        return ((StructureBlock*(*)(StructureBlock*))link::__ct__14StructureBlockFv)
        (ptr);
    }

};

#endif