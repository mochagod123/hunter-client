#ifndef __C_CONSOLE_MINECRAFT_APP_H__
#define __C_CONSOLE_MINECRAFT_APP_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t ExitGame__20CConsoleMinecraftAppFv                = 0x02F50028;
    static const uint32_t RequestSignInUIChoices__20CConsoleMinecraftAppSFi = 0x02F27E50;
}

class CConsoleMinecraftApp {
public:

    static void ExitGame() {
        return ((void(*)())link::ExitGame__20CConsoleMinecraftAppFv)
        ();
    }

    static void RequestSignInUIChoices(int32_t unk_i0) {
        return ((void(*)(int32_t))link::RequestSignInUIChoices__20CConsoleMinecraftAppSFi)
        (unk_i0);
    }

};

#endif