#ifndef __C_INPUT_H__
#define __C_INPUT_H__

#include <net/library/types.hpp>

namespace link {
    static uint32_t GetText__6CInputFPwi                                                    = 0x0340A480;
    static uint32_t RequestKeyboard__6CInputFPCwT1UiT3PFPvb_iPvQ2_9C_4JInput13EKeyboardMode = 0x0340A33C;
}

class CInput {
public:

    static inline CInput *GetInput() {
        return *(CInput**)0x10A90E6C;
    }

    void GetText(wchar_t *buffer, int32_t length) {
        return ((void(*)(CInput*, wchar_t*, int32_t))link::GetText__6CInputFPwi)
        (this, buffer, length);
    }

    bool RequestKeyboard(const wchar_t *nothing, const wchar_t *default_text, uint32_t unk_Ui0, uint32_t max_size, int(*call_back)(void *, bool), void *unk_Vp0, int32_t eKeyboardMode) {
        return ((bool(*)(CInput*, const wchar_t*, const wchar_t*, uint32_t, uint32_t, int(*)(void *, bool), void*, int32_t))link::RequestKeyboard__6CInputFPCwT1UiT3PFPvb_iPvQ2_9C_4JInput13EKeyboardMode)
        (this, nothing, default_text, unk_Ui0, max_size, call_back, unk_Vp0, eKeyboardMode);
    }

};

#endif