#ifndef __C_MINECRAFT_APP_H__
#define __C_MINECRAFT_APP_H__

#include <net/library/types.hpp>

class CMinecraftApp {
public:
    
    uint32_t unk_0, unk_4, unk_8, unk_C;
    uint32_t unk_10, unk_14, unk_18, unk_1C;
    uint32_t unk_20, unk_24, unk_28, unk_2C;
    uint32_t unk_30, unk_34, unk_38, unk_3C;
    uint32_t unk_40, unk_44, unk_48, unk_4C;
    uint32_t unk_50, unk_54, unk_58, unk_5C;
    uint32_t unk_60, unk_64, unk_68, unk_6C;
    uint32_t unk_70, unk_74, unk_78, unk_7C;
    uint32_t unk_80, unk_84, unk_88, unk_8C;
    uint32_t unk_90, unk_94, unk_98, unk_9C;
    uint32_t unk_A0, unk_A4, unk_A8, unk_AC;
    uint32_t unk_B0, unk_B4, unk_B8, unk_BC;
    uint32_t unk_C0, unk_C4, unk_C8, unk_CC;
    uint32_t unk_D0, unk_D4, unk_D8, unk_DC;
    uint32_t unk_E0, unk_E4, unk_E8, unk_EC;
    uint32_t unk_F0, unk_F4, unk_F8, unk_FC;
    uint32_t unk_100, unk_104, unk_108, unk_10C;

    uint32_t unk_110, unk_114, unk_118, unk_11C;
    uint32_t unk_120, unk_124, unk_128, unk_12C;
    uint32_t unk_130, unk_134, unk_138, unk_13C;
    uint32_t unk_140, unk_144, unk_148, unk_14C;
    uint32_t unk_150, unk_154, unk_158, unk_15C;
    uint32_t unk_160, unk_164, unk_168, unk_16C;
    uint32_t unk_170, unk_174, unk_178, unk_17C;
    uint32_t unk_180, unk_184, unk_188, unk_18C;
    uint32_t unk_190, unk_194, unk_198, unk_19C;
    uint32_t unk_1A0, unk_1A4, unk_1A8, unk_1AC;
    uint32_t unk_1B0, unk_1B4, unk_1B8, unk_1BC;
    uint32_t unk_1C0, unk_1C4, unk_1C8, unk_1CC;
    uint32_t unk_1D0, unk_1D4, unk_1D8, unk_1DC;
    uint32_t unk_1E0, unk_1E4, unk_1E8, unk_1EC;
    uint32_t unk_1F0, unk_1F4, unk_1F8, unk_1FC;
    uint32_t unk_200, unk_204, unk_208, unk_20C;

    uint32_t unk_210, unk_214, unk_218, unk_21C;
    uint32_t unk_220, unk_224, unk_228, unk_22C;
    uint32_t unk_230, unk_234, unk_238, unk_23C;
    uint32_t unk_240, unk_244, unk_248, unk_24C;
    uint32_t unk_250, unk_254, unk_258, unk_25C;
    uint32_t unk_260, unk_264, unk_268, unk_26C;
    uint32_t unk_270, unk_274, unk_278, unk_27C;
    uint32_t unk_280, unk_284, unk_288, unk_28C;
    uint32_t unk_290, unk_294, unk_298, unk_29C;
    uint32_t unk_2A0, unk_2A4, unk_2A8, unk_2AC;
    uint32_t unk_2B0, unk_2B4, unk_2B8, unk_2BC;
    uint32_t unk_2C0, unk_2C4, unk_2C8, unk_2CC;
    uint32_t unk_2D0, unk_2D4, unk_2D8, unk_2DC;
    uint32_t unk_2E0, unk_2E4, unk_2E8, unk_2EC;
    uint32_t unk_2F0, unk_2F4, unk_2F8, unk_2FC;
    uint32_t unk_300, unk_304, unk_308, unk_30C;

    uint32_t unk_310, unk_314, unk_318, unk_31C;
    uint32_t unk_320, unk_324, unk_328, unk_32C;
    uint32_t unk_330, unk_334, unk_338, unk_33C;
    uint32_t unk_340, unk_344, unk_348, unk_34C;
    uint32_t unk_350, unk_354, unk_358, unk_35C;
    uint32_t unk_360, unk_364, unk_368, unk_36C;
    uint32_t unk_370, unk_374, unk_378, unk_37C;
    uint32_t unk_380, unk_384, unk_388, unk_38C;
    uint32_t unk_390, unk_394, unk_398, unk_39C;
    uint32_t unk_3A0, unk_3A4, unk_3A8, unk_3AC;
    uint32_t unk_3B0, unk_3B4, unk_3B8, unk_3BC;
    uint32_t unk_3C0, unk_3C4, unk_3C8, unk_3CC;
    uint32_t unk_3D0, unk_3D4, unk_3D8, unk_3DC;
    uint32_t unk_3E0, unk_3E4, unk_3E8, unk_3EC;
    uint32_t unk_3F0, unk_3F4, unk_3F8, unk_3FC;
    uint32_t unk_400, unk_404, unk_408, unk_40C;

    uint32_t unk_410, unk_414, unk_418, unk_41C;
    uint32_t unk_420, unk_424, unk_428, unk_42C;
    uint32_t unk_430, unk_434, unk_438, unk_43C;
    uint32_t unk_440, unk_444, unk_448, unk_44C;
    uint32_t unk_450, unk_454, unk_458, unk_45C;
    uint32_t unk_460, unk_464, unk_468, unk_46C;
    uint32_t unk_470, unk_474, unk_478, unk_47C;
    uint32_t unk_480, unk_484, unk_488, unk_48C;
    uint32_t unk_490, unk_494, unk_498, unk_49C;
    uint32_t unk_4A0, unk_4A4, unk_4A8, unk_4AC;
    uint32_t unk_4B0, unk_4B4, unk_4B8, unk_4BC;
    uint32_t unk_4C0, unk_4C4, unk_4C8, unk_4CC;
    uint32_t unk_4D0, unk_4D4, unk_4D8, unk_4DC;
    uint32_t unk_4E0, unk_4E4, unk_4E8, unk_4EC;
    uint32_t unk_4F0, unk_4F4, unk_4F8, unk_4FC;
    uint32_t unk_500, unk_504, unk_508, unk_50C;

    uint32_t unk_510, unk_514, unk_518, unk_51C;
    uint32_t unk_520, unk_524, unk_528, unk_52C;
    uint32_t unk_530, unk_534, unk_538, unk_53C;
    uint32_t unk_540, unk_544, unk_548, unk_54C;
    uint32_t unk_550, unk_554, unk_558, unk_55C;
    uint32_t unk_560, unk_564, unk_568, unk_56C;
    uint32_t unk_570, unk_574, unk_578, unk_57C;
    uint32_t unk_580, unk_584, unk_588, unk_58C;
    uint32_t unk_590, unk_594, unk_598, unk_59C;
    uint32_t unk_5A0, unk_5A4, unk_5A8, unk_5AC;
    uint32_t unk_5B0, unk_5B4, unk_5B8, unk_5BC;
    uint32_t unk_5C0, unk_5C4, unk_5C8, unk_5CC;
    uint32_t unk_5D0, unk_5D4, unk_5D8, unk_5DC;
    uint32_t unk_5E0, unk_5E4, unk_5E8, unk_5EC;
    uint32_t unk_5F0, unk_5F4, unk_5F8, unk_5FC;
    uint32_t unk_600, unk_604, unk_608, unk_60C;

    uint32_t unk_610, unk_614, unk_618, unk_61C;
    uint32_t unk_620, unk_624, unk_628, unk_62C;
    uint32_t unk_630, unk_634, unk_638, unk_63C;
    uint32_t unk_640, unk_644, unk_648, unk_64C;
    uint32_t unk_650, unk_654, unk_658, unk_65C;
    uint32_t unk_660, unk_664, unk_668, unk_66C;
    uint32_t unk_670, unk_674, unk_678, unk_67C;
    uint32_t unk_680, unk_684, unk_688, unk_68C;
    uint32_t unk_690, unk_694, unk_698, unk_69C;
    uint32_t unk_6A0, unk_6A4, unk_6A8, unk_6AC;
    uint32_t unk_6B0, unk_6B4, unk_6B8;

};

#endif