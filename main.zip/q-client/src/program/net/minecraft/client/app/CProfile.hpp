#ifndef __C_PROFILE_H__
#define __C_PROFILE_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t CreatePresenceString__8CProfileFiRQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x0341118C;
    static const uint32_t SetPresenceString__8CProfileFi                                                                                            = 0x034114F4;
    static const uint32_t ShowSigninUI__8CProfileFv                                                                                                 = 0x0340F4FC;
}

class CProfile {
public:

    static inline CProfile *GetProfile() {
        return *(CProfile**)0x10AD1C58;
    }

    inline void CreatePresenceString(int32_t id, std::basic_string<wchar_t> wcstr) {
        return ((void(*)(CProfile*, int32_t, std::basic_string<wchar_t>))link::CreatePresenceString__8CProfileFiRQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (this, id, wcstr);
    }

    inline void SetPresenceString(int32_t id) {
        return ((void(*)(CProfile*, int32_t))link::SetPresenceString__8CProfileFi)
        (this, id);
    }

    inline void ShowSigninUI() {
        return ((void(*)(CProfile*))link::ShowSigninUI__8CProfileFv)
        (this);
    }

};

#endif