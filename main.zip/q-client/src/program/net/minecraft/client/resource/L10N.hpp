#ifndef __L10N_H__
#define __L10N_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t GetString__4L10NSFi = 0x02F24864;
}

class L10N {
public:

    static inline wchar_t *GetString(int32_t table) {
        return ((wchar_t*(*)(int32_t))link::GetString__4L10NSFi)
        (table);
    }

    static inline void ReplaceString(uint32_t table, const wchar_t *target) {
        wcscpy((wchar_t*)L10N::GetString(table), target);
    }

};

#endif