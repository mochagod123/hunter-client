#ifndef __RESOURCE_LOCATION_H__
#define __RESOURCE_LOCATION_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t __pumpkin_head__16ResourceLocationSF                                                                                                     = 0x10a72470;
    static const uint32_t __block_list__16ResourceLocationSF                                                                                                       = 0x10A89190;
    static const uint32_t __item_list__16ResourceLocationSF                                                                                                        = 0x10a891e0;
    static const uint32_t __font_list__16ResourceLocationSF                                                                                                        = 0x10a72d30;
    static const uint32_t __ct__16ResourceLocationFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w                       = 0x03250B1C;
    static const uint32_t __ct__16ResourceLocationFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wT1                     = 0x03250D30;
}

class ResourceLocation {
private:

    static inline ResourceLocation *Ctor(ResourceLocation *ptr, std::basic_string<wchar_t> path) {
        return ((ResourceLocation*(*)(ResourceLocation*, std::basic_string<wchar_t>))link::__ct__16ResourceLocationFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (ptr, path);
    }

    static inline ResourceLocation *Ctor(ResourceLocation *ptr, std::basic_string<wchar_t> domain, std::basic_string<wchar_t> path) {
        return ((ResourceLocation*(*)(ResourceLocation*, std::basic_string<wchar_t>, std::basic_string<wchar_t>))link::__ct__16ResourceLocationFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wT1)
        (ptr, domain, path);
    }

public:

    inline ResourceLocation(std::basic_string<wchar_t> path) {
        ResourceLocation::Ctor(this, path);
    }

    inline ResourceLocation(std::basic_string<wchar_t> domain, std::basic_string<wchar_t> path) {
        ResourceLocation::Ctor(this, domain, path);
    }

    static inline const ResourceLocation *getPumpkinHead() {
        return (ResourceLocation*)link::__pumpkin_head__16ResourceLocationSF;
    }

    static inline const ResourceLocation *getBlockList() {
        return (ResourceLocation*)link::__block_list__16ResourceLocationSF;
    }

    static inline const ResourceLocation *getItemList() {
        return (ResourceLocation*)link::__item_list__16ResourceLocationSF;
    }

    static inline const ResourceLocation *getFontList() {
        return (ResourceLocation*)link::__font_list__16ResourceLocationSF;
    }

};

#endif