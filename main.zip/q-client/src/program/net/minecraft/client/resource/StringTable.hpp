#ifndef __STRING_TABLE_H__
#define __STRING_TABLE_H__

namespace link {
    static const uint32_t __CPR690____vc__Q3_5boost9unordered651unordered_map__tm__629_Q2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wQ2_3stdJ58JQ2_J9J100hash__tm__88_Q2_3stdJ58JQ2_3std104equal_to__tm__J247JQ2_3std218allocator__tm__200_Q2_3std189pair__tm__176_CQ2_3stdJ58JQ2_3stdJ58JFRCZ1Z_RZ2Z = 0x021AA5D4;
}

class StringTable {
public:

    uint32_t unk_0x0;
	uint32_t unk_0x4;
	uint32_t unk_0x8;
	uint32_t unk_0xC;
	uint32_t unk_0x10;
	uint32_t unk_0x14;
	uint32_t unk_0x18;
	uint32_t unk_0x1C;
	uint32_t unk_0x20;
	uint32_t unk_0x24;
	uint32_t unk_0x28;
	uint32_t unk_0x2C;
	uint32_t unk_0x30;
	uint32_t unk_0x34;
	uint32_t unk_0x38;
	uint32_t unk_0x3C;
	uint32_t unk_0x40;
	uint32_t unk_0x44;
	uint32_t unk_0x48;
	uint32_t unk_0x4C;
	uint32_t unk_0x50;
	uint32_t unk_0x54;
	uint32_t unk_0x58;

    static inline StringTable *GetL10NStringTable() {
        return *(StringTable**)0x109CC720;
    }

    inline void addString(int32_t id, std::basic_string<wchar_t> wcstr) {
        std::basic_string<wchar_t> *str_iter = ((std::basic_string<wchar_t>*(*)(void*, int32_t))link::__CPR690____vc__Q3_5boost9unordered651unordered_map__tm__629_Q2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wQ2_3stdJ58JQ2_J9J100hash__tm__88_Q2_3stdJ58JQ2_3std104equal_to__tm__J247JQ2_3std218allocator__tm__200_Q2_3std189pair__tm__176_CQ2_3stdJ58JQ2_3stdJ58JFRCZ1Z_RZ2Z)
        (*(void **)(this + 0x3C), id);
        *str_iter = wcstr;
    }

};

#endif