#ifndef __ICON_REGISTER_H__
#define __ICON_REGISTER_H__

class IconRegister {
public:



};

#endif