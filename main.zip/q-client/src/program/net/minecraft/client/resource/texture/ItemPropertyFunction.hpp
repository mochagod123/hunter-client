#ifndef __ITEM_PROPERTY_FUNCTION_H__
#define __ITEM_PROPERTY_FUNCTION_H__

class ItemPropertyFunction {
public:

};

#endif