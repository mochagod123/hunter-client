#ifndef __TEXTURE_H__
#define __TEXTURE_H__

#include <net/library/types.hpp>
#include <net/minecraft/rendering/buffer/BufferedImage.hpp>

namespace link {
    static const uint32_t transferFromImage__7TextureFP13BufferedImage = 0x03360B48;
}

class Texture {
public:

    inline void transferFromImage(BufferedImage *image) {
        return ((void(*)(Texture*, BufferedImage*))link::transferFromImage__7TextureFP13BufferedImage)
        (this, image);
    }

};

#endif