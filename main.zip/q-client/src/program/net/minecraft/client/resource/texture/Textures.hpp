#ifndef __TEXTURES_H__
#define __TEXTURES_H__

#include <net/library/types.hpp>
#include <net/minecraft/client/resource/ResourceLocation.hpp>
#include <net/minecraft/rendering/buffer/BufferedImage.hpp>

namespace link {
    static const uint32_t loadTexture__8TexturesFP13BufferedImagei                                                                                                 = 0x0338F694;
    static const uint32_t loadTexture__8TexturesFi                                                                                                                 = 0x0338EEEC;
    static const uint32_t bind__8TexturesFi                                                                                                                        = 0x0338EE78;
    static const uint32_t bindTexture__8TexturesFPC16ResourceLocation                                                                                              = 0x0338F014;
    // static const uint32_t addMemTexture__8TexturesFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wP19MemTextureProcessor = 0x03391A94;
}

class Textures {
public:

    inline void loadTexture(BufferedImage *image, int32_t unk) {
        return ((void(*)(Textures*, BufferedImage*, int32_t))link::loadTexture__8TexturesFP13BufferedImagei)
        (this, image, unk);
    }

    inline int32_t loadTexture(int32_t id) {
        return ((int32_t(*)(Textures*, int32_t))link::loadTexture__8TexturesFi)
        (this, id);
    }

    inline void bind(int32_t id) {
        return ((void(*)(Textures*, int32_t))link::bind__8TexturesFi)
        (this, id);
    }

    inline void bindTexture(const ResourceLocation *resource) {
        return ((void(*)(Textures*, const ResourceLocation*))link::bindTexture__8TexturesFPC16ResourceLocation)
        (this, resource);
    }

};

#endif