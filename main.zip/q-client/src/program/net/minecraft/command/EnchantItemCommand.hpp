#ifndef __ENCHANT_ITEM_COMMAND_H__
#define __ENCHANT_ITEM_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t preparePacket__18EnchantItemCommandSFQ2_5boost25shared_ptr__tm__8_6PlayeriT2 = 0x022F1518;
}

class EnchantItemCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket(boost::shared_ptr<Player> player, int32_t id, int32_t level) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, boost::shared_ptr<Player>, int32_t, int32_t))link::preparePacket__18EnchantItemCommandSFQ2_5boost25shared_ptr__tm__8_6PlayeriT2)
        (&packet, player, id, level);
        return packet;
    }

};

#endif