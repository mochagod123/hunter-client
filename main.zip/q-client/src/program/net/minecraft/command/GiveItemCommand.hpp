#ifndef __GIVE_ITEM_COMMAND_H__
#define __GIVE_ITEM_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t preparePacket__15GiveItemCommandSFQ2_5boost25shared_ptr__tm__8_6PlayeriN22RCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x02460E54;
}

class GiveItemCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket(boost::shared_ptr<Player> player, int32_t id, int32_t count, int32_t damage, std::basic_string<wchar_t> unk) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, boost::shared_ptr<Player>, int32_t, int32_t, int32_t, std::basic_string<wchar_t>))link::preparePacket__15GiveItemCommandSFQ2_5boost25shared_ptr__tm__8_6PlayeriN22RCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (&packet, player, id, count, damage, unk);
        return packet;
    }

};

#endif