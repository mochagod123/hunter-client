#ifndef __KILL_COMMAND_H__
#define __KILL_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t preparePacket__11KillCommandSFv = 0x02520B58;
}

class KillCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket() {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*))link::preparePacket__11KillCommandSFv)
        (&packet);
        return packet;
    }

};

#endif