#ifndef __SET_SPAWN_POINT_COMMAND_H__
#define __SET_SPAWN_POINT_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/entity/player/PlayerUID.hpp>

namespace link {
    static const uint32_t preparePacket__20SetSpawnpointCommandSF9PlayerUID = 0x028B6760;
}

class SetSpawnpointCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket(PlayerUID uid) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, PlayerUID))link::preparePacket__20SetSpawnpointCommandSF9PlayerUID)
        (&packet, uid);
        return packet;
    }

};

#endif