#ifndef __TELEPORT_COMMAND_H__
#define __TELEPORT_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/entity/player/PlayerUID.hpp>

namespace link {
    static const uint32_t preparePacket__15TeleportCommandSF9PlayerUIDT1   = 0x03364494;
    static const uint32_t preparePacket__15TeleportCommandSF9PlayerUIDfN22 = 0x033648F8;
}

class TeleportCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket(PlayerUID me, PlayerUID target) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, PlayerUID, PlayerUID))link::preparePacket__15TeleportCommandSF9PlayerUIDT1)
        (&packet, me, target);
        return packet;
    }

    static inline boost::shared_ptr<Packet> preparePacket(PlayerUID uid, float x, float y, float z) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, PlayerUID, float, float, float))link::preparePacket__15TeleportCommandSF9PlayerUIDfN22)
        (&packet, uid, x, y, z);
        return packet;
    }

};

#endif