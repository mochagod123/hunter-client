#ifndef __TIME_COMMAND_H__
#define __TIME_COMMAND_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t preparePacket__11TimeCommandSFL = 0x029F92E0;
}

class TimeCommand {
public:

    static inline boost::shared_ptr<Packet> preparePacket(int64_t time_0, int64_t time_1) {
        boost::shared_ptr<Packet> packet;
        ((void(*)(boost::shared_ptr<Packet>*, int64_t, int64_t))link::preparePacket__11TimeCommandSFL)
        (&packet, time_0, time_1);
        return packet;
    }

};

#endif