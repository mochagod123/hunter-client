#ifndef __ENTITY_H__
#define __ENTITY_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/util/Vec3.hpp>
#include <net/minecraft/util/AABB.hpp>

namespace link {
    static const uint32_t getCustomName__6EntityFv = 0x02346AD4;
    static const uint32_t moveTo__6EntityFdN21fT4  = 0x0233474C;
}

class Entity {
public:

    uint32_t unk_0x0;
    uint32_t unk_0x4;
    uint32_t unk_0x8;
    uint32_t Id;
    uint32_t unk_0x10;
    uint32_t unk_0x14;
    uint32_t unk_0x18;
    uint32_t unk_0x1C;
    uint32_t unk_0x20;
    uint32_t unk_0x24;
    uint32_t unk_0x28;
    uint32_t unk_0x2C;
    uint32_t unk_0x30;
    uint32_t unk_0x34;
    uint32_t unk_0x38;
    uint32_t unk_0x3C;
    uint32_t unk_0x40;
    uint32_t unk_0x44;
    uint32_t unk_0x48;
    uint32_t unk_0x4C;
    uint32_t unk_0x50;
    uint32_t unk_0x54;
    uint32_t unk_0x58;
    uint32_t unk_0x5C;
    uint32_t unk_0x60;
    uint32_t unk_0x64;
    uint32_t unk_0x68;
    uint32_t unk_0x6C;
    uint32_t unk_0x70;
    uint32_t unk_0x74;
    uint32_t unk_0x78;
    uint32_t unk_0x7C;
    uint32_t unk_0x80;
    uint32_t unk_0x84;
    uint32_t unk_0x88;
    uint32_t unk_0x8C;
    uint32_t unk_0x90;
    uint32_t unk_0x94;
    uint32_t unk_0x98;
    uint32_t unk_0x9C;
    uint32_t unk_0xA0;
    uint32_t unk_0xA4;
    uint32_t unk_0xA8;
    uint32_t unk_0xAC;
    uint32_t unk_0xB0;
    uint32_t unk_0xB4;
    uint32_t unk_0xB8;
    uint32_t unk_0xBC;
    uint32_t unk_0xC0;
    uint32_t unk_0xC4;
    uint32_t unk_0xC8;
    uint32_t unk_0xCC;
    uint32_t unk_0xD0;
    uint32_t unk_0xD4;
    uint32_t unk_0xD8;
    uint32_t unk_0xDC;
    uint32_t unk_0xE0;
    uint32_t unk_0xE4;
    uint32_t unk_0xE8;
    uint32_t unk_0xEC;
    uint32_t unk_0xF0;
    uint32_t unk_0xF4;
    uint32_t unk_0xF8;
    uint32_t unk_0xFC;
    uint32_t unk_0x100;
    uint32_t unk_0x104;
    uint32_t unk_0x108;
    uint32_t unk_0x10C;
    uint32_t unk_0x110;
    uint32_t unk_0x114;
    Vec3 position;
    double motionX;
    double motionY;
    double motionZ;
    float yaw;
	float pitch;
    float yaw_old;
    float pitch_old;
    AABB *boundingBox;
    uint32_t unk_0x15C;
    uint32_t unk_0x160;
    uint32_t unk_0x164;
    uint32_t unk_0x168;
    uint32_t unk_0x16C;
    uint32_t unk_0x170;
    uint32_t unk_0x174;
    uint32_t unk_0x178;
    uint32_t unk_0x17C;
    uint32_t unk_0x180;
    uint32_t unk_0x184;
    uint32_t unk_0x188;
    uint32_t unk_0x18C;
    uint32_t unk_0x190;
    uint32_t unk_0x194;
    uint32_t unk_0x198;
    float32_t eyeHeight;
    uint32_t unk_0x1A0;
    uint32_t unk_0x1A4;
    uint32_t unk_0x1A8;
    uint32_t unk_0x1AC;
    uint32_t unk_0x1B0;
    uint32_t unk_0x1B4;
    uint32_t unk_0x1B8;
    uint32_t unk_0x1BC;
    uint32_t unk_0x1C0;
    uint32_t unk_0x1C4;
    uint32_t unk_0x1C8;
    uint32_t unk_0x1CC;
    uint32_t unk_0x1D0;
    uint32_t unk_0x1D4;
    uint32_t unk_0x1D8;
    uint32_t unk_0x1DC;
    uint32_t unk_0x1E0;
    uint32_t unk_0x1E4; // Random
    uint32_t unk_0x1E8;
    uint32_t unk_0x1EC;
    uint32_t unk_0x1F0;
    uint32_t unk_0x1F4;
    uint32_t unk_0x1F8;
    uint32_t unk_0x1FC;
    uint32_t unk_0x200;
    uint32_t unk_0x204;
    uint32_t unk_0x208;
    uint32_t unk_0x20C;
    uint32_t unk_0x210;
    uint32_t unk_0x214;
    uint32_t unk_0x218;
    uint32_t unk_0x21C;
    uint32_t unk_0x220;
    uint32_t unk_0x224;
    uint32_t unk_0x228;
    uint32_t unk_0x22C;
    uint32_t unk_0x230;
    uint32_t unk_0x234;
    uint32_t unk_0x238;
    uint32_t unk_0x23C;
    uint32_t unk_0x240;
    uint32_t unk_0x244;
	uint32_t unk_0x248;
	uint32_t unk_0x24C;
    uint32_t unk_0x250;
    uint32_t unk_0x254;
    uint32_t unk_0x258;
    uint32_t unk_0x25C;
    uint32_t unk_0x260;
    uint32_t unk_0x264;
    uint32_t unk_0x268;
    uint32_t unk_0x26C;
    uint32_t unk_0x270;
    uint32_t unk_0x274;
    uint32_t unk_0x278;
    uint32_t unk_0x27C;
    uint32_t unk_0x280;
    uint32_t unk_0x284;
    uint32_t unk_0x288;
    uint32_t unk_0x28C;
    uint32_t unk_0x290;
    uint32_t unk_0x294;
    uint32_t unk_0x298;
    uint32_t unk_0x29C;
    uint32_t unk_0x2A0;
    uint32_t unk_0x2A4;
    uint32_t unk_0x2A8;
    uint32_t unk_0x2AC;
    uint32_t unk_0x2B0;
    uint32_t unk_0x2B4;
    uint32_t unk_0x2B8;
    uint32_t unk_0x2BC;
    uint32_t unk_0x2C0;
    uint32_t unk_0x2C4;
    uint32_t unk_0x2C8;
    uint32_t unk_0x2CC;
    uint32_t unk_0x2D0;
    uint32_t unk_0x2D4;
    uint32_t unk_0x2D8;
    uint32_t unk_0x2DC;
    uint32_t unk_0x2E0;
    uint32_t unk_0x2E4;
    uint32_t unk_0x2E8;
    uint32_t unk_0x2EC;
    uint32_t unk_0x2F0;
    uint32_t unk_0x2F4;
    uint32_t unk_0x2F8;
    uint32_t unk_0x2FC;
    uint32_t unk_0x300;
    uint32_t unk_0x304;
    uint32_t unk_0x308;
    uint32_t unk_0x30C;
    uint32_t unk_0x310;
    uint32_t unk_0x314;
    uint32_t unk_0x318;
    uint32_t unk_0x31C;
    uint32_t unk_0x320;
    uint32_t unk_0x324;
    uint32_t unk_0x328;
    uint32_t unk_0x32C;
    uint32_t unk_0x330;
    uint32_t unk_0x334;
    uint32_t unk_0x338;
    uint32_t unk_0x33C;
    uint32_t unk_0x340;
    uint32_t unk_0x344;
    void *vtable;
    uint32_t unk_0x34C;

    /*
    inline std::basic_string<wchar_t> getCustomName() {
        std::basic_string<wchar_t> wresult;
        ((void(*)(Entity*, std::basic_string<wchar_t>))link::getCustomName__6EntityFv)
        (this, wresult);
        return wresult;
    }
    */

    int32_t AimX() {
        return ((unsigned int)this + 0x144);
    }
    int32_t AimZ() {
        return ((unsigned int)this + 0x148);
    }
    int32_t AimY() {
        return ((unsigned int)this + 0x14C);
    }

    int32_t getX() {
        int32_t *ptr = *(int32_t**)((unsigned int)this + 0x54);
        return (int32_t)ptr;
    }
    int32_t getY() {
        int32_t *ptr = *(int32_t**)((unsigned int)this + 0x58);
        return (int32_t)ptr;
    }
    int32_t getZ() {
        int32_t *ptr = *(int32_t**)((unsigned int)this + 0x5C);
        return (int32_t)ptr;
    }

    uint64_t GetType() {
        uint32_t GetType_address = *(uint32_t*)((uint32_t)vtable + 0xC);

        // *(uint32_t*)0x40000000 = GetType_address;

        return ((uint64_t(*)(Entity*))GetType_address)
        (this);
    }

    void moveTo(double x, double y, double z, float yaw, float pitch) {
        ((void(*)(Entity*, double, double, double, float, float))link::moveTo__6EntityFdN21fT4)
        (this, x, y, z, yaw, pitch);
    }

};

#endif