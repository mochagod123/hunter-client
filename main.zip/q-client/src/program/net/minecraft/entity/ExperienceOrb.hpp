#ifndef __EXPERIENCE_ORB_H__
#define __EXPERIENCE_ORB_H__

#include <net/library/types.hpp>

class ExperienceOrb {
public:

};

#endif