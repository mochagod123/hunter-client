#ifndef __FISHING_HOOK_H__
#define __FISHING_HOOK_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/entity/player/Player.hpp>

namespace link {
    static const uint32_t getOwner__11FishingHookFv = 0x0241F684;
}

class FishingHook : public Entity {
public:

    boost::shared_ptr<Player> getOwner() {
        boost::shared_ptr<Player> player;
        ((void(*)(FishingHook*, boost::shared_ptr<Player>*))link::getOwner__11FishingHookFv)
        (this, &player);
        return player;
    }

};

#endif