#ifndef __PROJECTILE_H__
#define __PROJECTILE_H__

#include <net/library/types.hpp>
#include <net/minecraft/world/Level.hpp>

class Projectile {
public:

    uint32_t unk_0x0;
    uint32_t unk_0x4;
    Level *level;
    void *vtable;

};

#endif