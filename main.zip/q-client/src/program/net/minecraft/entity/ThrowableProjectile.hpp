#ifndef __THROWABLE_PROJECTILE_H__
#define __THROWABLE_PROJECTILE_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/entity/Projectile.hpp>

class ThrowableProjectile : public Entity {
public:

    Projectile m_projectile;
    uint32_t unk_0x360;
    uint32_t unk_0x364;
    uint32_t unk_0x368;
    uint32_t unk_0x36C;
    uint32_t unk_0x370;
    uint32_t unk_0x374;
    uint32_t unk_0x378;
    uint32_t unk_0x37C;
    uint32_t unk_0x380;
    uint32_t unk_0x384;
    uint32_t unk_0x388;
    uint32_t unk_0x38C;
    boost::shared_ptr<LivingEntity> owner;
    uint32_t unk_0x398;
    uint32_t unk_0x39C;
    uint32_t unk_0x3A0;
    uint32_t unk_0x3A4;

};

#endif