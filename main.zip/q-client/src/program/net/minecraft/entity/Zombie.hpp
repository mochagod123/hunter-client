#ifndef __ZOMBIE_H__
#define __ZOMBIE_H__

#include <net/library/types.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/entity/Entity.hpp>

namespace link {
    static const uint32_t __ct__6ZombieFP5Level = 0x02A3A914;
}

class Zombie : public Entity {
public:

    static inline Zombie *Ctor(Zombie *ptr, Level *level) {
        return ((Zombie*(*)(Zombie*, Level*))link::__ct__6ZombieFP5Level)
        (ptr, level);
    }

};

#endif