#ifndef __LARGE_FIRE_BALL_H__
#define __LARGE_FIRE_BALL_H__

#include <net/library/types.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/entity/Entity.hpp>

namespace link {
    static const uint32_t __ct__13LargeFireballFP5LeveldN52 = 0x025B6714;
}

class LargeFireball : public Entity {
public:

    static inline LargeFireball *Ctor(LargeFireball *ptr, Level *level, double startX, double startY, double startZ, double targetX, double targetY, double targetZ) {
        return ((LargeFireball*(*)(LargeFireball*, Level*, double, double, double, double, double, double))link::__ct__13LargeFireballFP5LeveldN52)
        (ptr, level, startX, startY, startZ, targetX, targetY, targetZ);
    }

};

#endif