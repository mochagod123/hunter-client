#ifndef __SMALL_FIRE_BALL_H__
#define __SMALL_FIRE_BALL_H__

#include <net/library/types.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/entity/Entity.hpp>

namespace link {
    static const uint32_t __ct__13SmallFireballFP5LeveldN52 = 0x02955018;
}

class SmallFireball : public Entity {
public:

    static inline SmallFireball *Ctor(SmallFireball *ptr, Level *level, double startX, double startY, double startZ, double targetX, double targetY, double targetZ) {
        return ((SmallFireball*(*)(SmallFireball*, Level*, double, double, double, double, double, double))link::__ct__13SmallFireballFP5LeveldN52)
        (ptr, level, startX, startY, startZ, targetX, targetY, targetZ);
    }

};

#endif