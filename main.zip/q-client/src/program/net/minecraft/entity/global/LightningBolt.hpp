#ifndef __LIGHTNING_BOLT_H__
#define __LIGHTNING_BOLT_H__

#include <net/library/types.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/entity/Entity.hpp>

namespace link {
    static const uint32_t __ct__13LightningBoltFP5LeveldN22b = 0x025D4CAC;
}

class LightningBolt : public Entity {
public:

    static inline LightningBolt *Ctor(LightningBolt *ptr, Level *level, double x, double y, double z, bool unk = false) {
        return ((LightningBolt*(*)(LightningBolt*, Level*, double, double, double, bool))link::__ct__13LightningBoltFP5LeveldN22b)
        (ptr, level, x, y, z, unk);
    }

};

#endif