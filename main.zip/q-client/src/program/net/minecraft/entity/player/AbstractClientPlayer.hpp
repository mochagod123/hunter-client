#ifndef __ABSTRACT_CLIENT_PLAYER_H__
#define __ABSTRACT_CLIENT_PLAYER_H__

#include <net/library/types.hpp>
#include <net/minecraft/entity/player/Player.hpp>

class AbstractClientPlayer : public Player {
public:

	uint32_t unk_0x868;
    uint32_t unk_0x86C;
    uint32_t unk_0x870;
    uint32_t unk_0x874;

};

#endif