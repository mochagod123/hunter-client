#ifndef __LOCAL_PLAYER_H__
#define __LOCAL_PLAYER_H__

#include <net/library/types.hpp>
#include <net/minecraft/item/ItemInstance.hpp>
#include <net/minecraft/entity/player/AbstractClientPlayer.hpp>

class ConsoleUIController;
class ClientPacketListener;

namespace link {
    static const uint32_t getCarriedItem__11LocalPlayerFv = 0x031F3AC4;
}

class LocalPlayer : public AbstractClientPlayer {
public:

    ClientPacketListener *listener;
    uint32_t unk_0x87C;
    uint32_t unk_0x880;
    uint32_t unk_0x884;
    uint32_t unk_0x888;
    uint32_t unk_0x88C;
    uint32_t unk_0x890;
    uint32_t unk_0x894;
    uint32_t unk_0x898;
    uint32_t unk_0x89C;
    uint32_t unk_0x8A0;
    uint32_t unk_0x8A4;
    uint32_t unk_0x8A8;
    uint32_t unk_0x8AC;
    uint32_t unk_0x8B0;
    ConsoleUIController *controller;
    uint32_t unk_0x8B8;
    uint32_t unk_0x8BC;
    uint32_t unk_0x8C0;
    uint32_t unk_0x8C4;
    uint32_t unk_0x8C8;
    uint32_t unk_0x8CC;
    uint32_t unk_0x8D0;
    uint32_t unk_0x8D4;
    uint32_t unk_0x8D8;
    uint32_t unk_0x8DC;
    uint32_t unk_0x8E0;
    uint32_t unk_0x8E4;
    uint32_t unk_0x8E8;
    uint32_t unk_0x8EC;
    uint32_t unk_0x8F0;
    uint32_t unk_0x8F4;
    uint32_t unk_0x8F8;
    uint32_t unk_0x8FC;
    uint32_t unk_0x900;
    uint32_t unk_0x904;
    uint32_t unk_0x908;
    uint32_t unk_0x90C;
    uint32_t unk_0x910;
    uint32_t unk_0x914;
    uint32_t unk_0x918;
    uint32_t unk_0x91C;
    uint32_t unk_0x920;
    uint32_t unk_0x924;
    uint32_t unk_0x928;
    uint32_t unk_0x92C;
    uint32_t unk_0x930;
    uint32_t unk_0x934;
    uint32_t unk_0x938;
    uint32_t unk_0x93C;
    uint32_t unk_0x940;
    uint32_t unk_0x944;
    uint32_t unk_0x948;
    uint32_t unk_0x94C;
    uint32_t unk_0x950;
    uint32_t unk_0x954;
    uint32_t unk_0x958;
    uint32_t unk_0x95C;
    uint32_t unk_0x960;
    uint32_t unk_0x964;
    uint32_t unk_0x968;
    uint32_t unk_0x96C;
    uint32_t unk_0x970;
    uint32_t unk_0x974;
    uint32_t unk_0x978;
    uint32_t unk_0x97C;
    uint32_t unk_0x980;
    uint32_t unk_0x984;
    uint32_t unk_0x988;
    uint32_t unk_0x98C;
    uint32_t unk_0x990;
    uint32_t unk_0x994;
    uint32_t unk_0x998;
    uint32_t unk_0x99C;
    uint32_t unk_0x9A0;
    uint32_t unk_0x9A4;
    uint32_t unk_0x9A8;
    uint32_t unk_0x9AC;
    uint32_t unk_0x9B0;
    uint32_t unk_0x9B4;
    uint32_t unk_0x9B8;
    uint32_t unk_0x9BC;
    uint32_t unk_0x9C0;
    uint32_t unk_0x9C4;
    uint32_t unk_0x9C8;
    uint32_t unk_0x9CC;
    uint32_t unk_0x9D0;
    uint32_t unk_0x9D4;
    uint32_t unk_0x9D8;
    uint32_t unk_0x9DC;
    uint32_t unk_0x9E0;
    uint32_t unk_0x9E4;
    uint32_t unk_0x9E8;
    uint32_t unk_0x9EC;
    uint32_t unk_0x9F0;
    uint32_t unk_0x9F4;
    uint32_t unk_0x9F8;
    uint32_t unk_0x9FC;
    uint32_t unk_0xA00;
    uint32_t unk_0xA04;
    uint32_t unk_0xA08;
    uint32_t unk_0xA0C;

    inline boost::shared_ptr<ItemInstance> getCarriedItem() {
        boost::shared_ptr<ItemInstance> iteminstance;
        ((void(*)(LocalPlayer*, boost::shared_ptr<ItemInstance>&))link::getCarriedItem__11LocalPlayerFv)
        (this, iteminstance);
        return iteminstance;
    }

};

#endif