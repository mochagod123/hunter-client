#ifndef __PLAYER_UID_H__
#define __PLAYER_UID_H__

class PlayerUID {
public:

    uint32_t highest, higher, middle, lower, lowest;

};

#endif