#ifndef __SERVER_PLAYER_H__
#define __SERVER_PLAYER_H__

#include <net/library/types.hpp>
#include <net/minecraft/entity/player/Player.hpp>
#include <net/minecraft/network/listener/ServerGamePacketListenerImpl.hpp>
#include <net/minecraft/world/gamemode/ServerPlayerGameMode.hpp>

class ServerPlayer : public Player {
public:

    uint32_t unk_0x868;
    ServerGamePacketListenerImpl *listener;
    uint32_t unk_0x870;
    uint32_t unk_0x874;
    ServerPlayerGameMode *gamemode;
    uint32_t unk_0x87C;
    uint32_t unk_0x880;
    uint32_t unk_0x884;
    uint32_t unk_0x888;
    uint32_t unk_0x88C;
    uint32_t unk_0x890;
    uint32_t unk_0x894;
    uint32_t unk_0x898;
    uint32_t unk_0x89C;
    uint32_t unk_0x8A0;
    uint32_t unk_0x8A4;
    uint32_t unk_0x8A8;
    uint32_t unk_0x8AC;
    uint32_t unk_0x8B0;
    uint32_t unk_0x8B4;
    uint32_t unk_0x8B8;
    uint32_t unk_0x8BC;
    uint32_t unk_0x8C0;
    uint32_t unk_0x8C4;
    uint32_t unk_0x8C8;
    uint32_t unk_0x8CC;
    uint32_t unk_0x8D0;
    uint32_t unk_0x8D4;
    uint32_t unk_0x8D8;
    uint32_t unk_0x8DC;
    uint32_t unk_0x8E0;
    uint32_t unk_0x8E4;
    uint32_t unk_0x8E8;
    uint32_t unk_0x8EC;
    uint32_t unk_0x8F0;
    uint32_t unk_0x8F4;
    uint32_t unk_0x8F8;
    uint32_t unk_0x8FC;
    uint32_t unk_0x900;
    uint32_t unk_0x904;
    uint32_t unk_0x908;
    uint32_t unk_0x90C;
    uint32_t unk_0x910;
    uint32_t unk_0x914;
    uint32_t unk_0x918;
    uint32_t unk_0x91C;
    uint32_t unk_0x920;
    uint32_t unk_0x924;
    uint32_t unk_0x928;
    uint32_t unk_0x92C;
    uint32_t unk_0x930;
    uint32_t unk_0x934;
    uint32_t unk_0x938;
    uint32_t unk_0x93C;
    uint32_t unk_0x940;
    uint32_t unk_0x944;

};

#endif