#ifndef __BOW_ITEM_H__
#define __BOW_ITEM_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/item/Item.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/util/InteractionHand.hpp>
#include <net/minecraft/client/resource/StringTable.hpp>
#include <net/minecraft/client/resource/ResourceLocation.hpp>
#include <net/minecraft/client/resource/texture/IconRegister.hpp>

namespace link {
    static const uint32_t __ct__7BowItemFv                                                                                = 0x02162460;
    static const uint32_t use__7BowItemFP5LevelQ2_5boost25shared_ptr__tm__8_6PlayerQ2_15InteractionHand16EInteractionHand = 0x021650A8;
}

class BowItem : public Item {
public:

    static inline BowItem *Ctor(BowItem *ptr) {
        return ((BowItem*(*)(BowItem*))link::__ct__7BowItemFv)
        (ptr);
    }

    inline void use(Level *level, boost::shared_ptr<Player> player, InteractionHand::EInteractionHand eInteractionHand) {
        return ((void(*)(BowItem*, Level*, boost::shared_ptr<Player>, InteractionHand::EInteractionHand))link::use__7BowItemFP5LevelQ2_5boost25shared_ptr__tm__8_6PlayerQ2_15InteractionHand16EInteractionHand)
        (this, level, player, eInteractionHand);
    }

};

#endif