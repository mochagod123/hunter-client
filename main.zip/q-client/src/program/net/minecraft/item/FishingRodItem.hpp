#ifndef __FISHING_ROD_ITEM_H__
#define __FISHING_ROD_ITEM_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/item/Item.hpp>
#include <net/minecraft/world/Level.hpp>
#include <net/minecraft/util/InteractionHand.hpp>
#include <net/minecraft/client/resource/texture/IconRegister.hpp>

namespace link {
    static const uint32_t __ct__14FishingRodItemFv                        = 0x0241509C;
    static const uint32_t registerIcons__14FishingRodItemFP12IconRegister = 0x02418A9C;
}

class FishingRodItem : public Item {
public:

    static inline FishingRodItem *Ctor(FishingRodItem *ptr) {
        return ((FishingRodItem*(*)(FishingRodItem*))link::__ct__14FishingRodItemFv)
        (ptr);
    }

    void registerIcons(IconRegister *icon) {
        return ((void(*)(FishingRodItem*, IconRegister*))link::registerIcons__14FishingRodItemFP12IconRegister)
        (this, icon);
    }

};

#endif