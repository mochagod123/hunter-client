#ifndef __ITEM_H__
#define __ITEM_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/block/Block.hpp>
#include <net/minecraft/client/resource/ResourceLocation.hpp>
#include <net/minecraft/client/resource/texture/IconRegister.hpp>

namespace link {
    static const uint32_t __ct__4ItemFv                                                                                                         = 0x024B65D8;
    static const uint32_t byId__4ItemSFi                                                                                                        = 0x02486698;
    static const uint32_t getId__4ItemSFP4Item                                                                                                  = 0x02492100;
    static const uint32_t byBlock__4ItemSFP5Block                                                                                               = 0x02485CE4;
    static const uint32_t registerItem__4ItemSFiRC16ResourceLocationP4Item                                                                      = 0x024B3D60;
    static const uint32_t registerItem__4ItemSFiRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wP4Item = 0x024B6340;
    static const uint32_t setMaxDamage__4ItemFi                                                                                                 = 0x024B6910;
    static const uint32_t registerIcons__4ItemFP12IconRegister                                                                                  = 0x024D0820;
    static const uint32_t addProperty__4ItemF16ResourceLocationPC20ItemPropertyFunction                                                         = 0x024B6554;
    static const uint32_t setAllowOffhand__4ItemFb                                                                                              = 0x024B63BC;
    static const uint32_t setMaxStackSize__4ItemFi                                                                                              = 0x024B2BD8;
    static const uint32_t setIconName__4ItemFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w          = 0x024B2B90;
    static const uint32_t setDescriptionId__4ItemFiT1                                                                                           = 0x024B2B24;
}

class Item {
public:

    static inline Item *Ctor(Item *ptr) {
        return ((Item*(*)(Item*))link::__ct__4ItemFv)
        (ptr);
    }

    static inline Item *byId(int32_t id) {
        return ((Item*(*)(int32_t))link::byId__4ItemSFi)
        (id);
    }

    static inline uint32_t getId(Item *item) {
        return ((uint32_t(*)(Item*))link::getId__4ItemSFP4Item)
        (item);
    }

    static inline Item *byBlock(Block *block) {
        return ((Item*(*)(Block*))link::byBlock__4ItemSFP5Block)
        (block);
    }

    static inline void registerItem(int32_t id, ResourceLocation resource, Item *item) {
        return ((void(*)(int32_t, ResourceLocation, Item*))link::registerItem__4ItemSFiRC16ResourceLocationP4Item)
        (id, resource, item);
    }

    static inline void registerItem(int32_t id, std::basic_string<wchar_t> path, Item *item) {
        return ((void(*)(int32_t, std::basic_string<wchar_t>, Item*))link::registerItem__4ItemSFiRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wP4Item)
        (id, path, item);
    }

    void setMaxDamage(int32_t damage) {
        return ((void(*)(Item*, int32_t))link::setMaxDamage__4ItemFi)
        (this, damage);
    }

    void registerIcons(IconRegister *icon) {
        return ((void(*)(Item*, IconRegister*))link::registerIcons__4ItemFP12IconRegister)
        (this, icon);
    }
    
    void setAllowOffhand(bool allow) {
        return ((void(*)(Item*, bool))link::setAllowOffhand__4ItemFb)
        (this, allow);
    }

    void setMaxStackSize(int32_t size) {
        return ((void(*)(Item*, int32_t))link::setMaxStackSize__4ItemFi)
        (this, size);
    }

    void setIconName(std::basic_string<wchar_t> name) {
        return ((void(*)(Item*, std::basic_string<wchar_t>))link::setIconName__4ItemFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (this, name);
    }

    void setDescriptionId(int32_t unk_i0, int32_t unk_i1) {
        return ((void(*)(Item*, int32_t, int32_t))link::setDescriptionId__4ItemFiT1)
        (this, unk_i0, unk_i1);
    }

    // void addProperty()

};

#endif