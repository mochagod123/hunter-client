#ifndef __ITEM_INSTANCE_H__
#define __ITEM_INSTANCE_H__

#include <net/library/types.hpp>
#include <net/minecraft/item/Item.hpp>
#include <net/minecraft/block/Block.hpp>
#include <net/minecraft/nbt/CompoundTag.hpp>
#include <net/minecraft/nbt/Enchantment.hpp>

namespace link {
    static const uint32_t __ct__12ItemInstanceFP5Blocki           = 0x02485E60;
    static const uint32_t __ct__12ItemInstanceFP4Itemi            = 0x024861BC;
    static const uint32_t enchant__12ItemInstanceFP11Enchantmenti = 0x02496058;
    static const uint32_t setAuxValue__12ItemInstanceFi           = 0x02488B2C;
    static const uint32_t setTag__12ItemInstanceFP11CompoundTag   = 0x0248E080;
}

class ItemInstance {
public:

    uint32_t unk_0x0;
	uint32_t unk_0x4;
	int32_t  count;
	uint32_t popTime;
	Item *base;
	CompoundTag *tag;
	uint32_t unk_0x18;
	int32_t  damage;
	uint32_t unk_0x20;
	uint32_t unk_0x24;
	uint32_t unk_0x28;
	uint32_t unk_0x2C;
	uint32_t unk_0x30;
	uint32_t unk_0x34;
	uint32_t unk_0x38;
	uint32_t unk_0x3C;
	uint32_t unk_0x40;

    static ItemInstance* Ctor(ItemInstance* ptr, Block* block, int32_t count){
        return ((ItemInstance*(*)(ItemInstance*, Block*, int32_t))link::__ct__12ItemInstanceFP5Blocki)
        (ptr, block, count);
    }

    static ItemInstance* Ctor(ItemInstance* ptr, Item* item, int32_t count){
        return ((ItemInstance*(*)(ItemInstance*, Item*, int32_t))link::__ct__12ItemInstanceFP4Itemi)
        (ptr, item, count);
    }

    void enchant(Enchantment *enchantment, int32_t level) {
        return ((void(*)(ItemInstance*, Enchantment*, int32_t))link::enchant__12ItemInstanceFP11Enchantmenti)
        (this, enchantment, level);
    }

    void setAuxValue(int32_t damage){
        return ((void(*)(ItemInstance*, int32_t))link::setAuxValue__12ItemInstanceFi)
        (this, damage);
    }

    void setTag(CompoundTag *tag) {
        return ((void(*)(ItemInstance*, CompoundTag*))link::setTag__12ItemInstanceFP11CompoundTag)
        (this, tag);
    }

};

#endif