#ifndef __COMPOUND_TAG_H__
#define __COMPOUND_TAG_H__

#include <net/library/basic_string.hpp>
#include <net/minecraft/nbt/Tag.hpp>

namespace link {
    static const uint32_t __ct__11CompoundTagFv                                                                                                = 0x022182C0;
    static const uint32_t put__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wP3Tag    = 0x02218A80;
    static const uint32_t putByte__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wUc   = 0x0221ACC8;
    static const uint32_t putShort__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_ws   = 0x0221AD6C;
    static const uint32_t putInt__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wi     = 0x0221AE10;
    static const uint32_t putLong__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wL    = 0x0221AEB4;
    static const uint32_t putFloat__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wf   = 0x0221AF68;
    static const uint32_t putDouble__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wd  = 0x0221B01C;
    static const uint32_t putBoolean__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wb = 0x0221B23C;
}

class CompoundTag : public Tag {
public:

    static inline CompoundTag *Ctor(CompoundTag *ptr) {
        return ((CompoundTag*(*)(CompoundTag*))link::__ct__11CompoundTagFv)
        (ptr);
    }

    inline void put(std::basic_string<wchar_t> name, Tag *src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, Tag*))link::put__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wP3Tag)
        (this, name, src);
    }

    void putByte(std::basic_string<wchar_t> name, int8_t src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, int8_t))link::putByte__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wUc)
        (this, name, src);
    }

    void putShort(std::basic_string<wchar_t> name, int16_t src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, int16_t))link::putShort__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_ws)
        (this, name, src);
    }

    void putInt(std::basic_string<wchar_t> name, int32_t src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, int32_t))link::putInt__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wi)
        (this, name, src);
    }

    void putLong(std::basic_string<wchar_t> name, int64_t src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, int64_t))link::putLong__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wL)
        (this, name, src);
    }

    void putFloat(std::basic_string<wchar_t> name, float src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, float))link::putFloat__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wf)
        (this, name, src);
    }

    void putDouble(std::basic_string<wchar_t> name, double src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, double))link::putDouble__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wd)
        (this, name, src);
    }

    void putBoolean(std::basic_string<wchar_t> name, bool src) {
        return ((void(*)(CompoundTag*, std::basic_string<wchar_t>, bool))link::putBoolean__11CompoundTagFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wb)
        (this, name, src);
    }

};

#endif