#ifndef __ENCHANTMENT_H__
#define __ENCHANTMENT_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t byId__11EnchantmentSFi = 0x022C8F28;
}

class Enchantment {
public:

    static inline Enchantment *byId(int32_t id) {
        return ((Enchantment*(*)(int32_t))link::byId__11EnchantmentSFi)
        (id);
    }

};

#endif