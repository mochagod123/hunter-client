#ifndef __LIST_TAG_H__
#define __LIST_TAG_H__

#include <net/minecraft/nbt/Tag.hpp>

namespace link {
    static const uint32_t __ct__7ListTagFi    = 0x02573958;
    static const uint32_t add__7ListTagFP3Tag = 0x02573F8C;
}

class ListTag : public Tag {
public:

    static inline ListTag *Ctor(ListTag *ptr, int32_t unk_i0) {
        return ((ListTag*(*)(ListTag*, int32_t))link::__ct__7ListTagFi)
        (ptr, unk_i0);
    }

    inline void add(Tag *tag) {
        return ((void(*)(ListTag*, Tag*))link::add__7ListTagFP3Tag)
        (this, tag);
    }

};

#endif