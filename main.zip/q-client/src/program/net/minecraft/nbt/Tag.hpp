#ifndef __TAG_H__
#define __TAG_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __ct__3TagFv = 0x02994730;
}

class Tag {
public:

    static inline Tag *Ctor(Tag *ptr) {
        return ((Tag*(*)(Tag*))link::__ct__3TagFv)
        (ptr);
    }

};

#endif