#ifndef __CGAME_NETWORK_MANAGER_H__
#define __CGAME_NETWORK_MANAGER_H__

#include <net/library/types.hpp>
#include <net/minecraft/network/FriendSessionInfo.hpp>

namespace link {
    static const uint32_t JoinGame__19CGameNetworkManagerFP17FriendSessionInfoib = 0x02D57558;
    static const uint32_t IsHost__19CGameNetworkManagerFv                        = 0x02d54bd4;
}

class CGameNetworkManager {
public:

    static inline CGameNetworkManager *GetNetworkManager() {
        return (CGameNetworkManager*)0x109f83fc;
    }

    void JoinGame(FriendSessionInfo *info, int32_t unk_i0, bool unk_b0) {
        return ((void(*)(CGameNetworkManager*, FriendSessionInfo*, int32_t, bool))link::JoinGame__19CGameNetworkManagerFP17FriendSessionInfoib)
        (this, info, unk_i0, unk_b0);
    }

    bool IsHost() {
        return ((bool(*)(CGameNetworkManager*))link::IsHost__19CGameNetworkManagerFv)
        (this);
    }

};

#endif