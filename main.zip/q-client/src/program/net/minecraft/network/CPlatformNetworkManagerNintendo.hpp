#ifndef __C_PLATFORM_NETWORK_MANAGER_NINTENDO_H__
#define __C_PLATFORM_NETWORK_MANAGER_NINTENDO_H__

#include <net/library/types.hpp>
#include <net/library/vector.hpp>
#include <net/minecraft/network/FriendSessionInfo.hpp>

namespace link {
    static const uint32_t GetSessionList__31CPlatformNetworkManagerNintendoFiT1b = 0x0346DCC8;
}

class CPlatformNetworkManagerNintendo {
public:

    static CPlatformNetworkManagerNintendo *GetInstance() {
        return *(CPlatformNetworkManagerNintendo**)0x109C91E4;
    }

    std::vector<FriendSessionInfo *> *GetSessionList(int32_t unk_i0, int32_t unk_i1, bool unk_b0) {
        return  ((std::vector<FriendSessionInfo *>*(*)(CPlatformNetworkManagerNintendo*, int32_t, int32_t, bool))link::GetSessionList__31CPlatformNetworkManagerNintendoFiT1b)
        (this, unk_i0, unk_i1, unk_b0);
    }

};

#endif