#ifndef __FRIEND_SESSION_INFO_H__
#define __FRIEND_SESSION_INFO_H__

#include <net/library/types.hpp>
#include <cassert>
#include <net/minecraft/network/GameSessionData.hpp>

class FriendSessionInfo {
public:

    uint32_t sessionId_0;
    uint32_t sessionId_1;
    uint32_t sessionId_2;
    uint32_t sessionId_3;
    char nnid[17];
    void *unk_0x24;
    wchar_t *name;
    uint32_t unk_0x2C;
    uint32_t unk_0x30;
    GameSessionData session_data;

};
static_assert(sizeof(FriendSessionInfo) == 0x108, "Size");

#endif