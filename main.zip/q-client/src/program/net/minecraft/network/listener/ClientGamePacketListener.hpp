#ifndef __CLIENT_GAME_PACKET_LISTENER_H__
#define __CLIENT_GAME_PACKET_LISTENER_H__

#include <net/minecraft/network/listener/PacketListener.hpp>

class ClientGamePacketListener : public PacketListener {
public:

};

#endif