#ifndef __CLIENT_PACKET_LISTENER_H__
#define __CLIENT_PACKET_LISTENER_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/network/listener/ClientGamePacketListener.hpp>
#include <net/minecraft/network/packet/clientbound/ClientboundChatPacket.hpp>
#include <net/minecraft/network/packet/clientbound/ClientboundAddExperienceOrbPacket.hpp>

namespace link {
    static const uint32_t send__20ClientPacketListenerFQ2_5boost25shared_ptr__tm__8_6Packet                                                = 0x0304A5D8;
    static const uint32_t handleChat__20ClientPacketListenerFQ2_5boost42shared_ptr__tm__24_21ClientboundChatPacket                         = 0x03054C08;
    static const uint32_t handleAddExperienceOrb__20ClientPacketListenerFQ2_5boost54shared_ptr__tm__36_33ClientboundAddExperienceOrbPacket = 0x030485CC;
}

class ClientPacketListener : public ClientGamePacketListener {
public:

    void send(boost::shared_ptr<Packet> packet) {
        return ((void(*)(ClientPacketListener*, boost::shared_ptr<Packet>))link::send__20ClientPacketListenerFQ2_5boost25shared_ptr__tm__8_6Packet)
        (this, packet);
    }

    void handleChat(boost::shared_ptr<ClientboundChatPacket> packet) {
        return ((void(*)(ClientPacketListener*, boost::shared_ptr<ClientboundChatPacket>))link::handleChat__20ClientPacketListenerFQ2_5boost42shared_ptr__tm__24_21ClientboundChatPacket)
        (this, packet);
    }

    void handleAddExperienceOrb(boost::shared_ptr<ClientboundAddExperienceOrbPacket> packet) {
        return ((void(*)(ClientPacketListener*, boost::shared_ptr<ClientboundAddExperienceOrbPacket>))link::handleAddExperienceOrb__20ClientPacketListenerFQ2_5boost54shared_ptr__tm__36_33ClientboundAddExperienceOrbPacket)
        (this, packet);
    }

};

#endif