#ifndef __PACKET_LISTENER_H__
#define __PACKET_LISTENER_H__

class PacketListener {
public:

};

#endif