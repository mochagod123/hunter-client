#ifndef __SERVER_GAME_PACKET_LISTENER_IMPL_H__
#define __SERVER_GAME_PACKET_LISTENER_IMPL_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t send__28ServerGamePacketListenerImplFQ2_5boost25shared_ptr__tm__8_6Packet = 0x03249FB4;
	static const uint32_t teleport__28ServerGamePacketListenerImplFdN21fT4bT6                       = 0x03293E88;
}

class MinecraftServer;
class ServerPlayer;

class ServerGamePacketListenerImpl {
public:

    uint32_t unk_0x0;
    uint32_t unk_0x4;
    void *connection;
    uint32_t unk_0xC;
	uint32_t unk_0x10;
	uint32_t unk_0x14;
	uint32_t unk_0x18;
	uint32_t unk_0x1C;
	uint32_t unk_0x20;
	uint32_t unk_0x24;
	uint32_t unk_0x28;
	uint32_t unk_0x2C;
	uint32_t unk_0x30;
	uint32_t unk_0x34;
	uint32_t unk_0x38;
	uint32_t unk_0x3C;
	uint32_t unk_0x40;
	uint32_t unk_0x44;
	uint32_t unk_0x48;
	uint32_t unk_0x4C;
	uint32_t unk_0x50;
	uint32_t unk_0x54;
	uint32_t unk_0x58;
	uint32_t unk_0x5C;
	uint32_t unk_0x60;
	uint32_t unk_0x64;
	MinecraftServer *server;
	boost::shared_ptr<ServerPlayer> player;
	uint32_t unk_0x74;
	uint32_t unk_0x78;
	uint32_t unk_0x7C;
	uint32_t unk_0x80;
	uint32_t unk_0x84;
	uint32_t unk_0x88;
	uint32_t unk_0x8C;
	uint32_t unk_0x90;
	uint32_t unk_0x94;
	uint32_t unk_0x98;
	uint32_t unk_0x9C;
	uint32_t unk_0xA0;
	uint32_t unk_0xA4;
	uint32_t unk_0xA8;
	uint32_t unk_0xAC;
	uint32_t unk_0xB0;
	uint32_t unk_0xB4;
	uint32_t unk_0xB8;
	uint32_t unk_0xBC;
	uint32_t unk_0xC0;
	uint32_t unk_0xC4;
	uint32_t unk_0xC8;
	uint32_t unk_0xCC;
	uint32_t unk_0xD0;
	uint32_t unk_0xD4;
	uint32_t unk_0xD8;
	uint32_t unk_0xDC;
	uint32_t unk_0xE0;
	uint32_t unk_0xE4;
	uint32_t unk_0xE8;
	uint32_t unk_0xEC;
	uint32_t unk_0xF0;
	uint32_t unk_0xF4;
	uint32_t unk_0xF8;
	uint32_t unk_0xFC;
	uint32_t unk_0x100;
	uint32_t unk_0x104;
	uint32_t unk_0x108;
	uint32_t unk_0x10C;
	uint32_t unk_0x110;
	uint32_t unk_0x114;
	uint32_t unk_0x118;
	uint32_t unk_0x11C;
	uint32_t unk_0x120;
	uint32_t unk_0x124;
	uint32_t unk_0x128;
	uint32_t unk_0x12C;
	uint32_t unk_0x130;
	uint32_t unk_0x134;
	uint32_t unk_0x138;
	uint32_t unk_0x13C;
	uint32_t unk_0x140;
	uint32_t unk_0x144;
	uint32_t unk_0x148;
	uint32_t unk_0x14C;
	uint32_t unk_0x150;
	uint32_t unk_0x154;

    void send(boost::shared_ptr<Packet> packet) {
        return ((void(*)(ServerGamePacketListenerImpl*, boost::shared_ptr<Packet>))link::send__28ServerGamePacketListenerImplFQ2_5boost25shared_ptr__tm__8_6Packet)
        (this, packet);
    }

	void teleport(double x, double y, double z, float yaw, float pitch, bool unk_b0, bool unk_b1) {
		return ((void(*)(ServerGamePacketListenerImpl*, double, double, double, float, float, bool, bool))link::teleport__28ServerGamePacketListenerImplFdN21fT4bT6)
        (this, x, y, z, yaw, pitch, unk_b0, unk_b1);
	}

};

#endif