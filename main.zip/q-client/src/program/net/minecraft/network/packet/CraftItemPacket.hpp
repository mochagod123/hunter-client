#ifndef __CRAFT_ITEM_PACKET_H__
#define __CRAFT_ITEM_PACKET_H__

#include <net/library/types.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__15CraftItemPacketFiT1s = 0x0222DD24;
}

class CraftItemPacket : public Packet {
public:

    static inline CraftItemPacket *Ctor(CraftItemPacket *ptr, int32_t id, int32_t unk_i0, int16_t unk_s0) {
        return ((CraftItemPacket*(*)(CraftItemPacket*, int32_t, int32_t, int16_t))link::__ct__15CraftItemPacketFiT1s)
        (ptr, id, unk_i0, unk_s0);
    }

};

#endif