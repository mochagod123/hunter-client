#ifndef __DISCONNECT_PACKET_H__
#define __DISCONNECT_PACKET_H__

#include <net/library/types.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __CPR65____ct__16DisconnectPacketFQ2_J6J17eDisconnectReason = 0x022CCCAC;
}

class DisconnectPacket : public Packet {
public:

    enum class eDisconnectReason {
        error_0 = 0x0,
        unk_0 = 0x1,
        error_1 = 0x2, error_2 = 0x3, error_3 = 0x4, error_4 = 0x5, error_5 = 0x6,
        kicked_by_flying = 0x7,
        kicked_0 = 0x8, kicked_1 = 0x9,
        error_7 = 0xa, error_8 = 0xb, error_9 = 0xc,
        max_player = 0xd,
        game_version_old = 0xe,
        game_version_new = 0xf,
        error_a = 0x10, error_b = 0x11, error_c = 0x12, error_d = 0x13,
        content_access_limit = 0x14,
        content_access_limit_local = 0x15,
        error_e = 0x16, error_f = 0x17, error_10 = 0x18, 
        no_one_playing_friend = 0x19,
        kicked_already = 0x1a,
        only_friends = 0x1b,
        error_11 = 0x1c, error_12 = 0x1d,
        mii_already_used = 0x1e,
        cant_join_game = 0x1f,
        not_found_joinable_game = 0x20,
        error_back_main_menu = 0x21
    };

    static inline DisconnectPacket *Ctor(DisconnectPacket *ptr, DisconnectPacket::eDisconnectReason reason) {
        return ((DisconnectPacket*(*)(DisconnectPacket*, DisconnectPacket::eDisconnectReason))link::__CPR65____ct__16DisconnectPacketFQ2_J6J17eDisconnectReason)
        (ptr, reason);
    }

};

#endif