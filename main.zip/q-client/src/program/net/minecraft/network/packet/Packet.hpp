#ifndef __PACKET_H__
#define __PACKET_H__

#include <net/library/types.hpp>

namespace link {
	static const uint32_t __ct__6PacketFv = 0x026FF6C0;
}

class Packet {
public:

    uint32_t unk_0x0;
	uint32_t unk_0x4;
	uint32_t unk_0x8;
	uint32_t unk_0xC;

	static inline Packet *Ctor(Packet *ptr) {
		return ((Packet*(*)(Packet*))link::__ct__6PacketFv)
        (ptr);
	}

};

#endif