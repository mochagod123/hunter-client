#ifndef __CLIENT_BOUND_ADD_ENTITY_PACKET_H__
#define __CLIENT_BOUND_ADD_ENTITY_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__26ClientboundAddEntityPacketFQ2_5boost25shared_ptr__tm__8_6EntityiN62 = 0x021CDA00;
}

class ClientboundAddEntityPacket : public Packet {
public:

    static inline ClientboundAddEntityPacket *Ctor(ClientboundAddEntityPacket *ptr, boost::shared_ptr<Entity> entity, int32_t startX, int32_t startY, int32_t startZ, int32_t unk_i0, int32_t targetX, int32_t targetY, int32_t targetZ) {
        return ((ClientboundAddEntityPacket*(*)(ClientboundAddEntityPacket*, boost::shared_ptr<Entity>, int32_t, int32_t, int32_t, int32_t, int32_t, int32_t, int32_t))link::__ct__26ClientboundAddEntityPacketFQ2_5boost25shared_ptr__tm__8_6EntityiN62)
        (ptr, entity, startX, startY, startZ, unk_i0, targetX, targetY, targetZ);
    }

};

#endif