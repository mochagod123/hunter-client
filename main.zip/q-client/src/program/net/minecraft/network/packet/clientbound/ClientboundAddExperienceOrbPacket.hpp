#ifndef __CLIENT_BOUND_ADD_EXPERIENCE_ORB_PACKET_H__
#define __CLIENT_BOUND_ADD_EXPERIENCE_ORB_PACKET_H__

#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/entity/ExperienceOrb.hpp>

namespace link {
    static const uint32_t __ct__33ClientboundAddExperienceOrbPacketFQ2_5boost34shared_ptr__tm__16_13ExperienceOrbiN42 = 0x021DFA10;
}

class ClientboundAddExperienceOrbPacket : public Packet {
public:

    static inline ClientboundAddExperienceOrbPacket *Ctor(ClientboundAddExperienceOrbPacket *ptr, boost::shared_ptr<ExperienceOrb> orb, int32_t unk_i0, int32_t unk_i1, int32_t unk_i2, int32_t unk_i3, int32_t unk_i4) {
        return ((ClientboundAddExperienceOrbPacket*(*)(ClientboundAddExperienceOrbPacket*, boost::shared_ptr<ExperienceOrb>, int32_t, int32_t, int32_t, int32_t, int32_t))link::__ct__33ClientboundAddExperienceOrbPacketFQ2_5boost34shared_ptr__tm__16_13ExperienceOrbiN42)
        (ptr, orb, unk_i0, unk_i1, unk_i2, unk_i3, unk_i4);
    }

};

#endif