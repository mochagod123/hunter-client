#ifndef __CLIENT_BOUND_ADD_GLOBAL_ENTITY_PACKET_H__
#define __CLIENT_BOUND_ADD_GLOBAL_ENTITY_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__32ClientboundAddGlobalEntityPacketFQ2_5boost25shared_ptr__tm__8_6Entity = 0x021CE644;
}

class ClientboundAddGlobalEntityPacket : public Packet {
public:

    static inline ClientboundAddGlobalEntityPacket *Ctor(ClientboundAddGlobalEntityPacket *ptr, boost::shared_ptr<Entity> entity) {
        return ((ClientboundAddGlobalEntityPacket*(*)(ClientboundAddGlobalEntityPacket*, boost::shared_ptr<Entity>))link::__ct__32ClientboundAddGlobalEntityPacketFQ2_5boost25shared_ptr__tm__8_6Entity)
        (ptr, entity);
    }

};

#endif