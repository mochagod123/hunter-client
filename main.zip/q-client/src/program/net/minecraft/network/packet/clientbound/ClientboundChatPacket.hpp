#ifndef __CLIENT_BOUND_CHAT_PACKET_H__
#define __CLIENT_BOUND_CHAT_PACKET_H__

#include <net/library/basic_string.hpp>
#include <net/library/vector.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __CPR166____ct__21ClientboundChatPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wQ2_J6J18EChatPacketMessagei = 0x021B7408;
}

class ClientboundChatPacket : public Packet {
public:

    std::vector<std::basic_string<wchar_t> > str_v;

    enum class EChatPacketMessage {
        unk_0
    };

    static inline ClientboundChatPacket *Ctor(ClientboundChatPacket *ptr, std::basic_string<wchar_t> msg, ClientboundChatPacket::EChatPacketMessage eChatPacketMessage, int32_t unk_i0) {
        return ((ClientboundChatPacket*(*)(ClientboundChatPacket*, std::basic_string<wchar_t>, ClientboundChatPacket::EChatPacketMessage, int32_t))link::__CPR166____ct__21ClientboundChatPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wQ2_J6J18EChatPacketMessagei)
        (ptr, msg, eChatPacketMessage, unk_i0);
    }

};

#endif