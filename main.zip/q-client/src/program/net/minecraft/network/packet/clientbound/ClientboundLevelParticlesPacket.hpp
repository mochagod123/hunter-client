#ifndef __CLIENT_BOUND_LEVEL_PARTICLES_PACKET_H__
#define __CLIENT_BOUND_LEVEL_PARTICLES_PACKET_H__

#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/util/ParticleType.hpp>
#include <net/minecraft/util/arrayWithLength.hpp>

namespace link {
    static const uint32_t __ct__31ClientboundLevelParticlesPacketFPC12ParticleTypebfN63i24arrayWithLength__tm__2_i = 0x021E2740;
}

class ClientboundLevelParticlesPacket : public Packet {
public:

    static inline ClientboundLevelParticlesPacket *Ctor(ClientboundLevelParticlesPacket *ptr, ParticleType *particle, bool unk_b0, float x, float y, float z, float unk_f3, float unk_f4, float unk_f5, float unk_f6, int32_t unk_i0, arrayWithLength<int32_t> unk_awl0) {
        return ((ClientboundLevelParticlesPacket*(*)(ClientboundLevelParticlesPacket*, ParticleType*, bool, float, float, float, float, float, float, float, int32_t, arrayWithLength<int32_t>))link::__ct__31ClientboundLevelParticlesPacketFPC12ParticleTypebfN63i24arrayWithLength__tm__2_i)
        (ptr, particle, unk_b0, x, y, z, unk_f3, unk_f4, unk_f5, unk_f6, unk_i0, unk_awl0);
    }

};

#endif