#ifndef __CLIENT_BOUND_MAP_ITEM_DATA_PACKET_H__
#define __CLIENT_BOUND_MAP_ITEM_DATA_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/vector.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/util/arrayWithLength.hpp>
#include <net/minecraft/world/map/MapDecoration.hpp>

namespace link {
    static const uint32_t __CPR154____ct__28ClientboundMapItemDataPacketFiUcbRCQ2_3std72vector__tm__58_13MapDecorationQ2_3std33allocator__tm__16_J67J25arrayWithLength__tm__3_UcN41 = 0x021E4060;
}

class ClientboundMapItemDataPacket : public Packet {
public:

    static inline ClientboundMapItemDataPacket *Ctor(ClientboundMapItemDataPacket *ptr, int32_t mapId, uint8_t scale, bool unk_b0, std::vector<MapDecoration> const &unk_vector0, arrayWithLength<uint8_t> unk_awl0, int32_t updateX, int32_t updateY, int32_t updateWidth, int32_t updateHeight) {
        return ((ClientboundMapItemDataPacket*(*)(ClientboundMapItemDataPacket*, int32_t, uint8_t, bool, std::vector<MapDecoration>, arrayWithLength<uint8_t>, int32_t, int32_t, int32_t, int32_t))link::__CPR154____ct__28ClientboundMapItemDataPacketFiUcbRCQ2_3std72vector__tm__58_13MapDecorationQ2_3std33allocator__tm__16_J67J25arrayWithLength__tm__3_UcN41)
        (ptr, mapId, scale, unk_b0, unk_vector0, unk_awl0, updateX, updateY, updateWidth, updateHeight);
    }

};

#endif