#ifndef __CLIENT_BOUND_SOUND_PACKET_H__
#define __CLIENT_BOUND_SOUND_PACKET_H__

#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/util/sound/SoundEvent.hpp>

namespace link {
    static const uint32_t getSound__22ClientboundSoundPacketFv = 0x022299D8;
}

class ClientboundSoundPacket : public Packet {
public:

    SoundEvent *getSound() {
        return ((SoundEvent*(*)(ClientboundSoundPacket*))link::getSound__22ClientboundSoundPacketFv)
        (this);
    }

};

#endif