#ifndef __SERVER_BOUND_CHAT_PACKET_H__
#define __SERVER_BOUND_CHAT_PACKET_H__

#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__21ServerboundChatPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x028A98DC;
}

class ServerboundChatPacket : public Packet {
public:

    uint32_t unk_0x10;
    uint32_t unk_0x14;
    std::basic_string<wchar_t> message;

    static inline ServerboundChatPacket *Ctor(ServerboundChatPacket *ptr, std::basic_string<wchar_t> msg) {
        return ((ServerboundChatPacket*(*)(ServerboundChatPacket*, std::basic_string<wchar_t>))link::__ct__21ServerboundChatPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (ptr, msg);
    }

};

#endif