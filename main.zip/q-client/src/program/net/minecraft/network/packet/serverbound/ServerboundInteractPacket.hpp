#ifndef __SEVER_BOUND_INTERACT_PACKET_H__
#define __SEVER_BOUND_INTERACT_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/util/Vec3.hpp>
#include <net/minecraft/util/InteractionHand.hpp>

namespace link {
    static const uint32_t __ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6Entity                                             = 0x028AC244;
    static const uint32_t __ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6EntityQ2_15InteractionHand16EInteractionHand       = 0x028AC354;
    static const uint32_t __ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6EntityQ2_15InteractionHand16EInteractionHandP4Vec3 = 0x028AC46C;
}

class ServerboundInteractPacket : public Packet {
public:

    static inline ServerboundInteractPacket *Ctor(ServerboundInteractPacket *ptr, boost::shared_ptr<Entity> entity) {
        return ((ServerboundInteractPacket*(*)(ServerboundInteractPacket*, boost::shared_ptr<Entity>))link::__ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6Entity)
        (ptr, entity);
    }

    static inline ServerboundInteractPacket *Ctor(ServerboundInteractPacket *ptr, boost::shared_ptr<Entity> entity, InteractionHand::EInteractionHand eInteractionHand) {
        return ((ServerboundInteractPacket*(*)(ServerboundInteractPacket*, boost::shared_ptr<Entity>, InteractionHand::EInteractionHand))link::__ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6EntityQ2_15InteractionHand16EInteractionHand)
        (ptr, entity, eInteractionHand);
    }

    static inline ServerboundInteractPacket *Ctor(ServerboundInteractPacket *ptr, boost::shared_ptr<Entity> entity, InteractionHand::EInteractionHand eInteractionHand, Vec3 *v3) {
        return ((ServerboundInteractPacket*(*)(ServerboundInteractPacket*, boost::shared_ptr<Entity>, InteractionHand::EInteractionHand, Vec3*))link::__ct__25ServerboundInteractPacketFQ2_5boost25shared_ptr__tm__8_6EntityQ2_15InteractionHand16EInteractionHandP4Vec3)
        (ptr, entity, eInteractionHand, v3);
    }

};

#endif