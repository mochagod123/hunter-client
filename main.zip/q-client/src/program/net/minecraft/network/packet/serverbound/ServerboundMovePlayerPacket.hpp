#ifndef __SEVER_BOUND_MOVE_PLAYER_PACKET_H__
#define __SEVER_BOUND_MOVE_PLAYER_PACKET_H__

#include <net/library/types.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__Q2_27ServerboundMovePlayerPacket3PosFdN31bT5 = 0x028AD6C4;
    static const uint32_t __ct__27ServerboundMovePlayerPacketFbT1            = 0x028ACF38;
}

class ServerboundMovePlayerPacket : public Packet {
public:

    static inline ServerboundMovePlayerPacket *Ctor(ServerboundMovePlayerPacket *ptr, bool unk_b0, bool unk_b1) {
        return ((ServerboundMovePlayerPacket*(*)(ServerboundMovePlayerPacket*, bool, bool))link::__ct__27ServerboundMovePlayerPacketFbT1)
        (ptr, unk_b0, unk_b1);
    }

    class Pos {
    public:

        static inline ServerboundMovePlayerPacket *Ctor(ServerboundMovePlayerPacket *ptr, double x, double y, double unk_d0, double z, bool unk_b0, bool unk_b1) {
            return ((ServerboundMovePlayerPacket*(*)(ServerboundMovePlayerPacket*, double, double, double, double, bool, bool))link::__ct__Q2_27ServerboundMovePlayerPacket3PosFdN31bT5)
            (ptr, x, y, unk_d0, z, unk_b0, unk_b1);
        }

    };

};

#endif