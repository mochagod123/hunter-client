#ifndef __SERVER_BOUND_PLAYER_ACTION_PACKET_H__
#define __SERVER_BOUND_PLAYER_ACTION_PACKET_H__

#include <net/minecraft/util/BlockPos.hpp>
#include <net/minecraft/util/Direction.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __CPR103____ct__29ServerboundPlayerActionPacketFQ2_J6J6ActionRC8BlockPosPC9Directioni = 0x028AEC5C;
}

class ServerboundPlayerActionPacket : public Packet {
public:

    enum class Action {
        startDestroyBlock = 0,
        stopDestroyBlock = 1,
        continueDestroyBlock = 2,
        dropAllItems = 3,
        dropItem = 4,
        releaseItem = 5,
        swapHeldItems = 6
    };

    uint32_t unk_0x10;
	uint32_t unk_0x14;
	BlockPos position;
	Direction *direction;
	Action action;
	int32_t duration;

    static inline ServerboundPlayerActionPacket *Ctor(ServerboundPlayerActionPacket *ptr, ServerboundPlayerActionPacket::Action action, BlockPos position, Direction *direction, int32_t duration) {
        return ((ServerboundPlayerActionPacket*(*)(ServerboundPlayerActionPacket*, ServerboundPlayerActionPacket::Action, BlockPos, Direction*, int32_t))link::__CPR103____ct__29ServerboundPlayerActionPacketFQ2_J6J6ActionRC8BlockPosPC9Directioni)
        (ptr, action, position, direction, duration);
    }

};

#endif