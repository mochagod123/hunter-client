#ifndef __SEVER_BOUND_PRE_LOGIN_PACKET_H__
#define __SEVER_BOUND_PRE_LOGIN_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__25ServerboundPreLoginPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x028AFC9C;
}

class ServerboundPreLoginPacket : public Packet {
public:

    uint32_t unk_0x10;
    uint32_t unk_0x14;
    uint32_t unk_0x18;
    std::basic_string<wchar_t> name;

    static inline ServerboundPreLoginPacket *Ctor(ServerboundPreLoginPacket *ptr, std::basic_string<wchar_t> wcstr) {
        return ((ServerboundPreLoginPacket*(*)(ServerboundPreLoginPacket*, std::basic_string<wchar_t>))link::__ct__25ServerboundPreLoginPacketFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (ptr, wcstr);
    }

};

#endif