#ifndef __SEVER_BOUND_SET_CREATIVE_MODE_SLOT_PACKET_H__
#define __SEVER_BOUND_SET_CREATIVE_MODE_SLOT_PACKET_H__

#include <net/library/types.hpp>
#include <net/library/not_null_ptr.hpp>
#include <net/minecraft/item/Item.hpp>
#include <net/minecraft/item/ItemInstance.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__36ServerboundSetCreativeModeSlotPacketFi35not_null_ptr__tm__15_12ItemInstance = 0x028B09F8;
}

class ServerboundSetCreativeModeSlotPacket : public Packet {
public:

    static inline ServerboundSetCreativeModeSlotPacket *Ctor(ServerboundSetCreativeModeSlotPacket *ptr, int32_t slot, not_null_ptr<ItemInstance> item) {
        return ((ServerboundSetCreativeModeSlotPacket*(*)(ServerboundSetCreativeModeSlotPacket*, int32_t, not_null_ptr<ItemInstance>))link::__ct__36ServerboundSetCreativeModeSlotPacketFi35not_null_ptr__tm__15_12ItemInstance)
        (ptr, slot, item);
    }

};

#endif