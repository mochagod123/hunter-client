#ifndef __SERVER_BOUND_USE_ITEM_ON_PACKET_H__
#define __SERVER_BOUND_USE_ITEM_ON_PACKET_H__

#include <net/minecraft/util/BlockPos.hpp>
#include <net/minecraft/util/Direction.hpp>
#include <net/minecraft/util/InteractionHand.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__26ServerboundUseItemOnPacketFRC8BlockPosPC9DirectionQ2_15InteractionHand16EInteractionHandfN24 = 0x028B25B8;
}

class ServerboundUseItemOnPacket : public Packet {
public:

    static inline ServerboundUseItemOnPacket *Ctor(ServerboundUseItemOnPacket *ptr, BlockPos position, Direction *direction, InteractionHand::EInteractionHand eInteractionHand, float unk_f0, float unk_f1, float unk_f2) {
        return ((ServerboundUseItemOnPacket*(*)(ServerboundUseItemOnPacket*, BlockPos, Direction*, InteractionHand::EInteractionHand, float, float, float))link::__ct__26ServerboundUseItemOnPacketFRC8BlockPosPC9DirectionQ2_15InteractionHand16EInteractionHandfN24)
        (ptr, position, direction, eInteractionHand, unk_f0, unk_f1, unk_f2);
    }

    static inline ServerboundUseItemOnPacket *Ctor(ServerboundUseItemOnPacket *ptr, BlockPos position, Direction *direction, InteractionHand::EInteractionHand eInteractionHand) {
        return ((ServerboundUseItemOnPacket*(*)(ServerboundUseItemOnPacket*, BlockPos, Direction*, InteractionHand::EInteractionHand))link::__ct__26ServerboundUseItemOnPacketFRC8BlockPosPC9DirectionQ2_15InteractionHand16EInteractionHandfN24)
        (ptr, position, direction, eInteractionHand);
    }

};

#endif