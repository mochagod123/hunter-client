#ifndef __SERVER_BOUND_USE_ITEM_PACKET_H__
#define __SERVER_BOUND_USE_ITEM_PACKET_H__

#include <net/minecraft/util/InteractionHand.hpp>
#include <net/minecraft/network/packet/Packet.hpp>

namespace link {
    static const uint32_t __ct__24ServerboundUseItemPacketFQ2_15InteractionHand16EInteractionHand = 0x028B2B8C;
}

class ServerboundUseItemPacket : public Packet {
public:

    static inline ServerboundUseItemPacket *Ctor(ServerboundUseItemPacket *ptr, InteractionHand::EInteractionHand eInteractionHand) {
        return ((ServerboundUseItemPacket*(*)(ServerboundUseItemPacket*, InteractionHand::EInteractionHand))link::__ct__24ServerboundUseItemPacketFQ2_15InteractionHand16EInteractionHand)
        (ptr, eInteractionHand);
    }

};

#endif