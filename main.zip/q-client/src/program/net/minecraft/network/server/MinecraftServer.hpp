#ifndef __MINECRAFT_SERVER_H__
#define __MINECRAFT_SERVER_H__

#include <net/library/types.hpp>
#include <net/minecraft/network/server/PlayerList.hpp>
#include <net/minecraft/world/ServerLevel.hpp>

namespace link {
    static const uint32_t getPlayers__15MinecraftServerFv = 0x03225F74;
    static const uint32_t getLevel__15MinecraftServerFi   = 0x03222954;
}

class MinecraftServer {
public:

    uint32_t unk_0x0;
    uint32_t unk_0x4;
	uint32_t unk_0x8;
	uint32_t unk_0xC;
	uint32_t unk_0x10;
	PlayerList *playerList;
	uint32_t unk_0x18;
	uint32_t unk_0x1C;
	uint32_t unk_0x20;
	uint32_t unk_0x24;
	uint32_t unk_0x28;
	uint32_t unk_0x2C;
	uint32_t unk_0x30;
	uint32_t unk_0x34;
	uint32_t unk_0x38;
	uint32_t unk_0x3C;
	uint32_t unk_0x40;
	uint32_t unk_0x44;
	uint32_t unk_0x48;
	uint32_t unk_0x4C;
	uint32_t unk_0x50;
	uint32_t unk_0x54;
    uint32_t unk_0x58;
    uint32_t unk_0x5C;
    uint32_t unk_0x60;
	uint32_t unk_0x64;
    uint32_t unk_0x68;
    uint32_t unk_0x6C;
	uint32_t unk_0x70;
	uint32_t unk_0x74;
	uint32_t unk_0x78;
	uint32_t unk_0x7C;
	uint32_t unk_0x80;
	uint32_t unk_0x84;
	uint32_t unk_0x88;
	uint32_t unk_0x8C;
	uint32_t unk_0x90;
	uint32_t unk_0x94;
	uint32_t unk_0x98;
	uint32_t unk_0x9C;
	void *commandDispatcher;
	uint32_t unk_0xA4;
	uint32_t unk_0xA8;
	uint32_t unk_0xAC;
	uint32_t unk_0xB0;
	bool unk_0xB4;
	bool unk_0xB5;
	bool animalsAllowed;
	bool npcsEnabled;
	bool pvpAllowed;
	bool flightAllowed;
	bool unk_0xBA;
	bool unk_0xBB;
	uint32_t unk_0xBC;
	uint32_t unk_0xC0;
	uint32_t unk_0xC4;
	uint32_t unk_0xC8;
	uint32_t unk_0xCC;
	uint32_t unk_0xD0;
	uint32_t unk_0xD4;
	uint32_t unk_0xD8;
	int32_t maxBuildHeight;
	uint32_t unk_0xE0;
	bool forceGameType;
	bool unk_0xE5;
	bool unk_0xE6;
	bool unk_0xE7;
	uint32_t unk_0xE8;
	uint32_t unk_0xEC;
	uint32_t unk_0xF0;
	uint32_t unk_0xF4;
	uint32_t unk_0xF8;
	uint32_t unk_0xFC;
	uint32_t unk_0x100;
	uint32_t unk_0x104;
	uint32_t unk_0x108;
	uint32_t unk_0x10C;
	uint32_t unk_0x110;
	uint32_t unk_0x114;
	uint32_t unk_0x118;
	uint32_t unk_0x11C;
	uint32_t unk_0x120;
	uint32_t unk_0x124;
	uint32_t unk_0x128;
	uint32_t unk_0x12C;
	uint32_t unk_0x130;
	uint32_t unk_0x134;
	uint32_t unk_0x138;
	uint32_t unk_0x13C;
	uint32_t unk_0x140;
	uint32_t unk_0x144;
	uint32_t unk_0x148;
	uint32_t unk_0x14C;

    static inline MinecraftServer *GetInstance() {
        return *(MinecraftServer**)0x109CD8FC;
    }

    inline PlayerList *getPlayers() {
        return ((PlayerList*(*)(MinecraftServer*))link::getPlayers__15MinecraftServerFv)
        (this);
    }

    inline ServerLevel *getLevel(int32_t lvl_id) {
        return ((ServerLevel*(*)(MinecraftServer*, int32_t))link::getLevel__15MinecraftServerFi)
        (this, lvl_id);
    }

};

#endif