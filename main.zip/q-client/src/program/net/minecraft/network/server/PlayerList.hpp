#ifndef __PLAYER_LIST_H__
#define __PLAYER_LIST_H__

#include <net/library/types.hpp>
#include <net/library/vector.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/network/packet/Packet.hpp>
#include <net/minecraft/entity/player/ServerPlayer.hpp>

namespace link {
    static const uint32_t broadcastAll__10PlayerListFQ2_5boost25shared_ptr__tm__8_6Packet                                                         = 0x03286804;
    static const uint32_t getPlayerByName__10PlayerListFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x032A785C;
}

class PlayerList {
public:

    std::vector<boost::shared_ptr<ServerPlayer>> players;
	uint32_t unk_0x10;
    uint32_t unk_0x14;
    uint32_t unk_0x18;
    uint32_t unk_0x1C;
    uint32_t unk_0x20;
    uint32_t unk_0x24;
    uint32_t unk_0x28;
    uint32_t unk_0x2C;
    uint32_t unk_0x30;
    uint32_t unk_0x34;
    uint32_t unk_0x38;
    uint32_t unk_0x3C;
    uint32_t unk_0x40;
    uint32_t unk_0x44;
    uint32_t unk_0x48;
    uint32_t unk_0x4C;
    uint32_t unk_0x50;
    uint32_t unk_0x54;
    uint32_t unk_0x58;
    uint32_t unk_0x5C;
    uint32_t unk_0x60;
    uint32_t unk_0x64;
    uint32_t unk_0x68;
    uint32_t unk_0x6C;
    uint32_t unk_0x70;
    uint32_t unk_0x74;
    uint32_t unk_0x78;
    uint32_t unk_0x7C;
    uint32_t unk_0x80;
    uint32_t unk_0x84;
    uint32_t unk_0x88;
    uint32_t unk_0x8C;
    uint32_t unk_0x90;
    uint32_t unk_0x94;
    uint32_t unk_0x98;
    uint32_t unk_0x9C;
    uint32_t unk_0xA0;
    uint32_t unk_0xA4;
    uint32_t unk_0xA8;
    uint32_t unk_0xAC;
    uint32_t unk_0xB0;
    uint32_t unk_0xB4;
    uint32_t unk_0xB8;
    uint32_t unk_0xBC;
    uint32_t unk_0xC0;
    uint32_t unk_0xC4;
    uint32_t unk_0xC8;
    uint32_t unk_0xCC;
    uint32_t unk_0xD0;
    uint32_t unk_0xD4;
    uint32_t unk_0xD8;
    uint32_t unk_0xDC;
    uint32_t unk_0xE0;
    uint32_t unk_0xE4;
    uint32_t unk_0xE8;
    uint32_t unk_0xEC;
    uint32_t unk_0xF0;

    inline void broadcastAll(boost::shared_ptr<Packet> packet) {
        return ((void(*)(PlayerList*, boost::shared_ptr<Packet>))link::broadcastAll__10PlayerListFQ2_5boost25shared_ptr__tm__8_6Packet)
        (this, packet);
    }

    inline Player *getPlayerByName(std::basic_string<wchar_t> wcstr) {
        Player *player;
        ((void(*)(PlayerList*, Player*, std::basic_string<wchar_t>))link::getPlayerByName__10PlayerListFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (this, player, wcstr);
        return player;
    }

    inline std::vector<boost::shared_ptr<ServerPlayer>> getPlayers() {
        return this->players;
    }

};

#endif