#ifndef __FONT_H__
#define __FONT_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t draw__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wbT2        = 0x030E9534;
    static const uint32_t draw__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiN22bT5    = 0x030E9A10;
    static const uint32_t drawShadow__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiN22 = 0x03126B88;
}

class Font {
public:

    void draw(std::basic_string<wchar_t> wcstr, bool unk_b0, bool unk_b1) {
        return ((void(*)(Font*, std::basic_string<wchar_t>, bool, bool))link::draw__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wbT2)
        (this, wcstr, unk_b0, unk_b1);
    }

    void draw(std::basic_string<wchar_t> wcstr, int32_t x, int32_t y, int32_t z, bool unk_b0, bool unk_b1) {
        return ((void(*)(Font*, std::basic_string<wchar_t>, int32_t, int32_t, int32_t, bool, bool))link::draw__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiN22bT5)
        (this, wcstr, x, y, z, unk_b0, unk_b1);
    }

    void drawShadow(std::basic_string<wchar_t> wcstr, int32_t x, int32_t y, int32_t argb) {
        return ((void(*)(Font*, std::basic_string<wchar_t>, int32_t, int32_t, int32_t))link::drawShadow__4FontFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiN22)
        (this, wcstr, x, y, argb);
    }

};

#endif