#ifndef __GL_STATE_MANAGER_H__
#define __GL_STATE_MANAGER_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t pushMatrix__14GlStateManagerSFv       = 0x030E4B3C;
    static const uint32_t popMatrix__14GlStateManagerSFv        = 0x030E4BD8;
    static const uint32_t scalef__14GlStateManagerSFfN21        = 0x030E4B6C;
    static const uint32_t translatef__14GlStateManagerSFfN21    = 0x030E4B54;
    static const uint32_t ortho__14GlStateManagerSFdN51         = 0x03110D4C;
    static const uint32_t loadIdentity__14GlStateManagerSFv     = 0x03103080;
    static const uint32_t matrixMode__14GlStateManagerSFi       = 0x03103064;
    static const uint32_t disableCull__14GlStateManagerSFv      = 0x030F974C;
    static const uint32_t disableLighting__14GlStateManagerSFv  = 0x030E4B24;
    static const uint32_t disableTexture__14GlStateManagerSFv   = 0x030E6268;
    static const uint32_t enableBlend__14GlStateManagerSFv      = 0x030E5284;
    static const uint32_t disableBlend__14GlStateManagerSFv     = 0x030E5328;
    static const uint32_t blendFunc__14GlStateManagerSFiT1      = 0x030E52A0;
    static const uint32_t disableDepthTest__14GlStateManagerSFv = 0x030E9B9C;
    static const uint32_t depthMask__14GlStateManagerSFb        = 0x030E52FC;
    static const uint32_t depthFunc__14GlStateManagerSFi        = 0x030E9BD4;
    static const uint32_t disableAlphaTest__14GlStateManagerSFv = 0x03108E10;
    static const uint32_t color4f__14GlStateManagerSFfN31       = 0x030E4BA8;
    static const uint32_t enableDepthTest__14GlStateManagerSFv  = 0x030E9BB8;
    static const uint32_t enableAlphaTest__14GlStateManagerSFv  = 0x031056BC;
    static const uint32_t genTexture__14GlStateManagerSFv       = 0x03124EF8;
    static const uint32_t rotatef__14GlStateManagerSFfN31       = 0x030E4B84;
    static const uint32_t color3f__14GlStateManagerSFfN21       = 0x030E9394;
}

class GlStateManager {
public:

    static void pushMatrix() {
        return ((void(*)())link::pushMatrix__14GlStateManagerSFv)
        ();
    }
    static void popMatrix() {
        return ((void(*)())link::popMatrix__14GlStateManagerSFv)
        ();
    }
    static void scalef(float x, float y, float z) {
        return ((void(*)(float, float, float))link::scalef__14GlStateManagerSFfN21)
        (x, y, z);
    }
    static void translatef(float x, float y, float z) {
        return ((void(*)(float, float, float))link::translatef__14GlStateManagerSFfN21)
        (x, y, z);
    }
    static void ortho(double left,double right,double bottom,double top,double znear,double zfar) {
        return ((void(*)(double, double, double, double, double, double))link::ortho__14GlStateManagerSFdN51)
        (left, right, bottom, top, znear, zfar);
	}
    static void loadIdentity() {
        return ((void(*)())link::loadIdentity__14GlStateManagerSFv)
        ();
    }
    static void matrixMode(int32_t i0) {
        return ((void(*)(int32_t))link::matrixMode__14GlStateManagerSFi)
        (i0);
    }
    static void disableCull() {
        return ((void(*)())link::disableCull__14GlStateManagerSFv)
        ();
    }
    static void disableLighting() {
        return ((void(*)())link::disableLighting__14GlStateManagerSFv)
        ();
    }
    static void disableTexture() {
        return ((void(*)())link::disableTexture__14GlStateManagerSFv)
        ();
    }
    static void enableBlend() {
        return ((void(*)())link::enableBlend__14GlStateManagerSFv)
        ();
    }
    static void disableBlend() {
        return ((void(*)())link::disableBlend__14GlStateManagerSFv)
        ();
    }
    static void blendFunc(int32_t i0, int32_t i1) {
        return ((void(*)(int32_t, int32_t))link::blendFunc__14GlStateManagerSFiT1)
        (i0, i1);
    }
    static void disableDepthTest() {
        return ((void(*)())link::disableDepthTest__14GlStateManagerSFv)();
    }
    static void depthMask(bool b0) {
        return ((void(*)(bool))link::depthMask__14GlStateManagerSFb)
        (b0);
    }
    static void depthFunc(int32_t i0) {
        return ((void(*)(int32_t))link::depthFunc__14GlStateManagerSFi)
        (i0);
    }

    static void disableAlphaTest() {
        return ((void(*)())link::disableAlphaTest__14GlStateManagerSFv)
        ();
    }

    static void color4f(float unk_f0, float unk_f1, float unk_f2, float unk_f3) {
        return ((void(*)(float, float, float, float))link::color4f__14GlStateManagerSFfN31)
        (unk_f0, unk_f1, unk_f2, unk_f3);
    }

    static void color3f(float r, float g, float b) {
        return ((void(*)(float, float, float))link::color3f__14GlStateManagerSFfN21)
        (r, g, b);
    }

    static void enableDepthTest() {
        return ((void(*)())link::enableDepthTest__14GlStateManagerSFv)
        ();
    }

    static void enableAlphaTest() {
        return ((void(*)())link::enableAlphaTest__14GlStateManagerSFv)
        ();
    }

    static int32_t genTexture() {
        return ((int32_t(*)())link::genTexture__14GlStateManagerSFv)
        ();
    }

    static void rotatef(float angle, float x, float y, float z) {
        return ((void(*)(float, float, float, float))link::rotatef__14GlStateManagerSFfN31)
        (angle, x, y, z);
    }

};

#endif