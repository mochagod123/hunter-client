#ifndef __TESSELATOR_H__
#define __TESSELATOR_H__

#include <net/library/types.hpp>
#include <net/minecraft/rendering/buffer/BufferBuilder.hpp>

namespace link {
    static const uint32_t getInstance__10TesselatorSFv = 0x03337EF0;
    static const uint32_t getBuilder__10TesselatorFv   = 0x03337EE8;
}

class Tesselator {
public:

    static inline Tesselator *getInstance() {
        return ((Tesselator*(*)())link::getInstance__10TesselatorSFv)
        ();
    }

    inline BufferBuilder *getBuilder() {
        return ((BufferBuilder*(*)(Tesselator*))link::getBuilder__10TesselatorFv)
        (this);
    }

};

#endif