#ifndef __BUFFER_BUILDER_H__
#define __BUFFER_BUILDER_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t begin__13BufferBuilderFi           = 0x02FD1FB4;
    static const uint32_t begin__13BufferBuilderFv           = 0x02FD33F8;
    static const uint32_t end__13BufferBuilderFv             = 0x02FD2288;
    static const uint32_t vertex__13BufferBuilderFfN21       = 0x02FD2A34;
    static const uint32_t vertexDouble__13BufferBuilderFdN21 = 0x02FD368C;
    static const uint32_t vertexUV__13BufferBuilderFfN41     = 0x02FD2AF4;
    static const uint32_t color__13BufferBuilderFiT1         = 0x02FD36C4;
    static const uint32_t color__13BufferBuilderFi           = 0x02FD36A8;
}

class BufferBuilder {
public:

    void begin(int32_t unk) {
        return ((void(*)(BufferBuilder*, int32_t))link::begin__13BufferBuilderFi)
        (this, unk);
    }

    void begin() {
        return ((void(*)(BufferBuilder*))link::begin__13BufferBuilderFv)
        (this);
    }

    void end() {
        return ((void(*)(BufferBuilder*))link::end__13BufferBuilderFv)
        (this);
    }

    void vertex(float x, float y, float z) {
        return ((void(*)(BufferBuilder*, float, float, float))link::vertex__13BufferBuilderFfN21)
        (this, x, y, z);
    }

    void vertexDouble(double x, double y, double z) {
        return ((void(*)(BufferBuilder*, double, double, double))link::vertexDouble__13BufferBuilderFdN21)
        (this, x, y, z);
    }

    void vertexUV(float tex_x, float tex_y, float tex_z, float x, float y) {
        return ((void(*)(BufferBuilder*, float, float, float, float, float))link::vertexUV__13BufferBuilderFfN41)
        (this, tex_x, tex_y, tex_z, x, y);
    }

    void color(int32_t rgb, int32_t a) {
        return ((void(*)(BufferBuilder*, int32_t, int32_t))link::vertex__13BufferBuilderFfN21)
        (this, rgb, a);
    }

    void color(int32_t argb) {
        return ((void(*)(BufferBuilder*, int32_t))link::color__13BufferBuilderFi)
        (this, argb);
    }

};

#endif