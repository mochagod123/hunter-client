#ifndef __BUFFERED_IMAGE_H__
#define __BUFFERED_IMAGE_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __ct__13BufferedImageFPUcUi = 0x03029A40;
}

class BufferedImage {
public:

    static inline BufferedImage *Ctor(BufferedImage *ptr, uint8_t *buffer, uint32_t unk) {
        return ((BufferedImage*(*)(BufferedImage*, uint8_t*, uint32_t))link::__ct__13BufferedImageFPUcUi)
        (ptr, buffer, unk);
    }

};

#endif