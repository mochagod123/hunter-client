#ifndef __GUI_H__
#define __GUI_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t setSingleMessage__3GuiFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiT2 = 0x031390F8;
    static const uint32_t setNowPlaying__3GuiFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w       = 0x03139174;
}

class Gui {
public:

    void setSingleMessage(std::basic_string<wchar_t> wcstr, int32_t unk_i0, int32_t length) {
        return ((void(*)(Gui*, std::basic_string<wchar_t>, int32_t, int32_t))link::setSingleMessage__3GuiFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_wiT2)
        (this, wcstr, unk_i0, length);
    }

    void setNowPlaying(std::basic_string<wchar_t> wcstr) {
        return ((void(*)(Gui*, std::basic_string<wchar_t>))link::setNowPlaying__3GuiFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (this, wcstr);
    }

};

#endif