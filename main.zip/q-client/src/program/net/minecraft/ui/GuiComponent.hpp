#ifndef __GUI_COMPONENT_H__
#define __GUI_COMPONENT_H__

class GuiComponent {
public:



};

#endif