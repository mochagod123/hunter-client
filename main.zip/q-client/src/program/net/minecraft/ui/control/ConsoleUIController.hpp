#ifndef __CONSOLE_UI_CONTROLLER_H__
#define __CONSOLE_UI_CONTROLLER_H__

#include <net/library/types.hpp>
#include <net/minecraft/util/sound/SoundEvent.hpp>

namespace link {
    static const uint32_t SetAchievementUnlocked__19ConsoleUIControllerFiN3 = 0x02DAAD4C;
    static const uint32_t SetTooltipText__19ConsoleUIControllerFUiT1i       = 0x02DA72E8;
    static const uint32_t ShowTooltip__19ConsoleUIControllerFUiT1b          = 0x02DA7450;
    static const uint32_t PlayUISFX__19ConsoleUIControllerFPC10SoundEvent   = 0x02DA7918;
}

class ConsoleUIController {
public:

    static inline ConsoleUIController *GetUIController() {
        return (ConsoleUIController*)0x109f95e0;
    }

    inline void SetAchievementUnlocked(int32_t unk_i0, int32_t id, int32_t unk_i2, int32_t unk_i3) {
        return ((void(*)(ConsoleUIController*, int32_t, int32_t, int32_t, int32_t))link::SetAchievementUnlocked__19ConsoleUIControllerFiN3)
        (this, unk_i0, id, unk_i2, unk_i3);
    }

    inline void SetTooltipText(uint32_t unk_Ui0, uint32_t unk_Ui1, int32_t unk_i0) {
        return ((void(*)(ConsoleUIController*, uint32_t, uint32_t, int32_t))link::SetTooltipText__19ConsoleUIControllerFUiT1i)
        (this, unk_Ui0, unk_Ui1, unk_i0);
    }

    inline void ShowTooltip(uint32_t unk_Ui0, uint32_t unk_Ui1, bool unk_b0) {
        return ((void(*)(ConsoleUIController*, uint32_t, uint32_t, bool))link::ShowTooltip__19ConsoleUIControllerFUiT1b)
        (this, unk_Ui0, unk_Ui1, unk_b0);
    }

    inline void PlayUISFX(SoundEvent *sound) {
        return ((void(*)(ConsoleUIController*, SoundEvent*))link::PlayUISFX__19ConsoleUIControllerFPC10SoundEvent)
        (this, sound);
    }

};

#endif