#ifndef __UI_CONTROL_H__
#define __UI_CONTROL_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __ct__9UIControlFv       = 0x02DBD7E0;
    static const uint32_t setWidth__9UIControlFf   = 0x02DBDAC0;
    static const uint32_t setOpacity__9UIControlFf = 0x02DBDB28;
}

class UIControl {
public:

    static inline UIControl *Ctor(UIControl *ptr) {
        return ((UIControl*(*)(UIControl*))link::__ct__9UIControlFv)
        (ptr);
    }

    inline void setWidth(float width) {
        return ((void(*)(UIControl*, float))link::setWidth__9UIControlFf)
        (this, width);
    }

    inline void setOpacity(float opacity) {
        return ((void(*)(UIControl*, float))link::setOpacity__9UIControlFf)
        (this, opacity);
    }

};

#endif