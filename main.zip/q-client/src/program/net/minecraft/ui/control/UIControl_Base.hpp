#ifndef __UI_CONTROL_BASE_H__
#define __UI_CONTROL_BASE_H__

#include <net/library/types.hpp>
#include <net/minecraft/ui/control/UIControl.hpp>

class UIControl_Base : public UIControl {
public:



};

#endif