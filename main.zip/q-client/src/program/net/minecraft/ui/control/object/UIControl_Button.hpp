#ifndef __UI_CONTROL_BUTTON_H__
#define __UI_CONTROL_BUTTON_H__

#include <net/library/types.hpp>
#include <net/minecraft/ui/control/util/UIString.hpp>
#include <net/minecraft/ui/control/UIControl_Base.hpp>

namespace link {
    static const uint32_t __ct__16UIControl_ButtonFv          = 0x02DBE7B0;
    static const uint32_t init__16UIControl_ButtonF8UIStringi = 0x02DBE848;
}

class UIControl_Button : public UIControl_Base {
public:

    static inline UIControl_Button *Ctor(UIControl_Button *ptr) {
        return ((UIControl_Button*(*)(UIControl_Button*))link::__ct__16UIControl_ButtonFv)
        (ptr);
    }

    inline void init(UIString uiString, int32_t unk) {
        return ((void(*)(UIControl_Button*, UIString, int32_t))link::init__16UIControl_ButtonF8UIStringi)
        (this, uiString, unk);
    }

};

#endif