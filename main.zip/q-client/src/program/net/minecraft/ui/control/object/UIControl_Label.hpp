#ifndef __UI_CONTROL_LABEL_H__
#define __UI_CONTROL_LABEL_H__

#include <net/library/types.hpp>
#include <net/minecraft/ui/control/util/UIString.hpp>
#include <net/minecraft/ui/control/UIControl_Base.hpp>

namespace link {
    static const uint32_t __ct__15UIControl_LabelFv         = 0x02DBEF08;
    static const uint32_t init__15UIControl_LabelF8UIString = 0x02DBEF94;
}

class UIControl_Label : public UIControl_Base {
public:

    static inline UIControl_Label *Ctor(UIControl_Label *ptr) {
        return ((UIControl_Label*(*)(UIControl_Label*))link::__ct__15UIControl_LabelFv)
        (ptr);
    }

    inline void init(UIString uiString) {
        return ((void(*)(UIControl_Label*, UIString))link::init__15UIControl_LabelF8UIString)
        (this, uiString);
    }

};

#endif