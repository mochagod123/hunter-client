#ifndef __UI_STRING_H__
#define __UI_STRING_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __ct__8UIStringFPCw = 0x02F47938;
}

class UIString {
public:

    static inline UIString *Ctor(UIString *ptr, const wchar_t *wc) {
        return ((UIString*(*)(UIString*, const wchar_t*))link::__ct__8UIStringFPCw)
        (ptr, wc);
    }

    inline UIString(const wchar_t *wc) {
        UIString::Ctor(this, wc);
    }

};

#endif