#ifndef __UI_LAYER_H__
#define __UI_LAYER_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t removeScene__7UILayerFP7UIScene = 0x02E855F4;
}

class UIScene;

class UILayer {
public:

    static inline UILayer *GetLayer() {
        UILayer *ptr   = *(UILayer**)((uint32_t)0x10A09490);
        UILayer *layer = *(UILayer**)((uint32_t)ptr + 0x10);
        return layer;
    }

    inline void removeScene(UIScene *scene) {
        return ((void(*)(UILayer*, UIScene*))link::removeScene__7UILayerFP7UIScene)
        (this, scene);
    }

};

#endif