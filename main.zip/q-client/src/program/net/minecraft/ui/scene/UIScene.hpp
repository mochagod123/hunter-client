#ifndef __UI_SCENE_H__
#define __UI_SCENE_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __ct__7UISceneFiP7UILayer = 0x02E39FD8;
    static const uint32_t setVisible__7UISceneFb    = 0x02E89C68;
    static const uint32_t setOpacity__7UISceneFf    = 0x02E89B38;
}

class UILayer;

class UIScene {
public:

    static inline UIScene *Ctor(UIScene *ptr, int32_t unk, UILayer *layer) {
        return ((UIScene*(*)(UIScene*, int32_t, UILayer*))link::__ct__7UISceneFiP7UILayer)
        (ptr, unk, layer);
    }

    inline void setOpacity(float opacity) {
        return ((void(*)(UIScene*, float))link::setOpacity__7UISceneFf)
        (this, opacity);
    }

    inline void setVisible(bool visible) {
        return ((void(*)(UIScene*, bool))link::setVisible__7UISceneFb)
        (this, visible);
    }

};

#endif