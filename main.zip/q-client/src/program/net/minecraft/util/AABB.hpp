#ifndef __AABB_H__
#define __AABB_H__

#include <net/library/types.hpp>
#include <net/library/converter.hpp>

namespace link {
    static const uint32_t CreateNewThreadStorage__4AABBSFv = 0x0200C76C;
    static const uint32_t __ct__4AABBFdN51                 = 0x0200C920;
    static const uint32_t move__4AABBCFdN21                = 0x0200d260;
}

class AABB {
public:

    double minX;
    double minY;
    double minZ;
    double maxX;
    double maxY;
    double maxZ;
    
    static inline AABB *Ctor(AABB *ptr, double x0, double y0, double z0, double x1, double y1, double z1) {
        return ((AABB*(*)(AABB*, double, double, double, double, double, double))link::__ct__4AABBFdN51)
        (ptr, x0, y0, z0, x1, y1, z1);
    }

    static void CreateNewThreadStorage() {
        return ((void(*)())link::CreateNewThreadStorage__4AABBSFv)
        ();
    }

    void move(double offsetX, double offsetY, double offsetZ) {
        return ((void(*)(AABB*, double, double, double))link::move__4AABBCFdN21)
        (this, offsetX, offsetY, offsetZ);
    }

    // __attribute__((longcall)) void move(double offsetX, double offsetY, double offsetZ) const asm("0x0200d260");

};

#endif