#ifndef __BLOCK_POS_H__
#define __BLOCK_POS_H__

#include <net/library/types.hpp>
#include <net/minecraft/util/Vec3.hpp>

namespace link {
    static const uint32_t __ct__8BlockPosFRCQ2_5boost25shared_ptr__tm__8_6Entity = 0x020C3C2C;
    static const uint32_t __ct__8BlockPosFP6Entity                               = 0x020C3D38;
    static const uint32_t __ct__8BlockPosFP4Vec3                                 = 0x020C3DB0;
}

class BlockPos {
public:

    int32_t x;
    int32_t y;
    int32_t z;

    inline BlockPos() {
        this->x = 0;
        this->y = 0;
        this->z = 0;
    }

    inline BlockPos(int32_t x, int32_t y, int32_t z) {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    inline BlockPos(boost::shared_ptr<Entity> entity) {
        ((void(*)(BlockPos*, boost::shared_ptr<Entity>))link::__ct__8BlockPosFRCQ2_5boost25shared_ptr__tm__8_6Entity)
        (this, entity);
    }

    inline BlockPos(Entity *entity) {
        ((void(*)(BlockPos*, Entity*))link::__ct__8BlockPosFP6Entity)
        (this, entity);
    }

    inline BlockPos(Vec3 *v3) {
        ((void(*)(BlockPos*, Vec3*))link::__ct__8BlockPosFP4Vec3)
        (this, v3);
    }

};

#endif