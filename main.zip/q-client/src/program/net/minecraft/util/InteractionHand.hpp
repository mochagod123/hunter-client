#ifndef __INTERACTION_HAND_H__
#define __INTERACTION_HAND_H__

class InteractionHand {
public:

    enum class EInteractionHand {
        right,
        left
    };

};

#endif