#ifndef __MTH_H__
#define __MTH_H__

#include <net/library/types.hpp>
#include <net/library/converter.hpp>
#include <net/minecraft/util/Vec3.hpp>
#include <net/minecraft/util/AABB.hpp>

namespace link {
    static const uint32_t _sqrt  = 0x038323CC;
    static const uint32_t _sin   = 0x03832468;
    static const uint32_t _cos   = 0x0383300C;
    static const uint32_t _tan   = 0x03832234;
    static const uint32_t _atan  = 0x038331A8;
    static const uint32_t _atan2 = 0x0383310C;
    static const uint32_t _floor = 0x03832BAC;
}

/*

inline float32_t sqrt(float32_t x) {
    return ((float32_t(*)(float32_t))link::_sqrt)
    (x);
}

inline float64_t sqrt(float64_t x) {
    return ((float64_t(*)(float64_t))link::_sqrt)
    (x);
}

inline float32_t sin(float32_t x) {
    return ((float32_t(*)(float32_t))link::_sin)
    (x);
}

inline float64_t sin(float64_t x) {
    return ((float64_t(*)(float64_t))link::_sin)
    (x);
}

inline float32_t cos(float32_t x) {
    return ((float32_t(*)(float32_t))link::_cos)
    (x);
}

inline float64_t cos(float64_t x) {
    return ((float64_t(*)(float64_t))link::_cos)
    (x);
}

inline float32_t tan(float32_t x) {
    return ((float32_t(*)(float32_t))link::_tan)
    (x);
}

inline float64_t tan(float64_t x) {
    return ((float64_t(*)(float64_t))link::_tan)
    (x);
}

inline float32_t atan(float32_t x) {
    return ((float32_t(*)(float32_t))link::_atan)
    (x);
}

inline float64_t atan(float64_t x) {
    return ((float64_t(*)(float64_t))link::_atan)
    (x);
}

inline float32_t atan2(float32_t y, float32_t x) {
    return ((float32_t(*)(float32_t, float32_t))link::_atan2)
    (y, x);
}

inline float64_t atan2(float64_t y, float64_t x) {
    return ((float64_t(*)(float64_t, float64_t))link::_atan2)
    (y, x);
}

inline float32_t floor(float32_t x) {
    return ((float32_t(*)(float32_t))link::_floor)
    (x);
}

inline float64_t floor(float64_t x) {
    return ((float64_t(*)(float64_t))link::_floor)
    (x);
}

*/

    static inline float sqrt(float x){
        return ((float(*)(float))0x02623338)(x);
    }
    static inline double sqrt(double x){
        return ((double(*)(double))0x02623348)(x);
    }
    static inline float floor(double x) {
        return ((float(*)(double))0x03833C70)(x);
    }
    static inline float floor(float x) {
        return ((float(*)(double))0x03833C70)((double)x);
    }
    static inline double acos(double x) {
        return ((double(*)(double))0x038333C8)(x);
    }
    static inline double atan(double x) {
        return ((double(*)(float))0x038331A8)(x);
    }
    static inline double atan2(double x, double y) {
        return ((double(*)(double, double))0x0383310C)(x, y);
    }

int32_t hsvToRgb(float hue, float saturation, float value) {
    return ((int32_t(*)(float, float, float))0x02624178)(hue, saturation, value);
}

Vec3 getBlockMinPos(int32_t x, int32_t y, int32_t z) {
    Vec3 ret;
    ret.x = floor(todouble(x));
    ret.y = floor(todouble(y));
    ret.z = floor(todouble(z));
    return ret;
}

AABB *getBlockAABB(int32_t x, int32_t y, int32_t z) {
    Vec3 minpos = getBlockMinPos(x, y, z);
    AABB *ret = AABB::Ctor(nullptr, minpos.x, minpos.y, minpos.z, minpos.x + 1.0D, minpos.y + 1.0D, minpos.z + 1.0D);
    return ret;
}

#endif