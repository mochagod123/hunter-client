#ifndef __PARTICLE_TYPE_H__
#define __PARTICLE_TYPE_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t byId__12ParticleTypeSF14ePARTICLE_TYPE  = 0x026D9A54;
    static const uint32_t getParamCount__12ParticleTypeCFv        = 0x026D9A44;
    static const uint32_t getOverrideLimiter__12ParticleTypeCFv   = 0x026D9A4C;
}

class ParticleType {
public:

    enum class ePARTICLE_TYPE {
        bubble = 0,
        smoke = 1,
        note = 2,
        portal = 3,

        poof = 5,
        flame = 6,
        lava = 7,
        footstep = 8,
        splash_0 = 9,
        large_smoke = 10,
        dust = 11,
        item_snowball = 12,
        snow_shovel = 13,
        item_slime = 14,
        heart = 15,
        suspended = 16,
        mycelium_0 = 17,
        instant_effect = 18,
        explosion_emitterk = 19,
        explosion = 20,
        mycelium_1 = 21,
        effect_0 = 22,
        witch = 23,
        effect_1 = 24,
        ambient_entity_effect = 25,

        dripping_water = 27,
        dripping_lava = 28,
        enchant = 29,

        angry_village = 31,
        happy_village = 32,
        firework = 33,
        underwater = 34,
        enchanted_hit = 35,
        instant_spell = 36,
        cloud = 37,
        barrier = 38,
        block = 39,
        blockdust = 40,
        falling_water = 41,
        take = 42,
        mobappearance = 43,
        dragon_breath = 44,
        totem_of_undying_white = 45,
        damage_indicator = 46,
        sweep_attack = 47,
        falling_dust = 48,
        totem_of_undying = 49,
        ink = 50,
        spit = 51,
        bubble_pop = 52,
        current_down = 53,
        conduit = 54
    };

    std::basic_string<wchar_t> name;
    ePARTICLE_TYPE id;
    bool override_limiter;
    int32_t param_count;

    static inline ParticleType *byId(ePARTICLE_TYPE eParticleType) {
        return ((ParticleType*(*)(ePARTICLE_TYPE))link::byId__12ParticleTypeSF14ePARTICLE_TYPE)
        (eParticleType);
    }

    int32_t getParamCount() {
        return ((int32_t(*)(ParticleType*))link::getParamCount__12ParticleTypeCFv)
        (this);
	}

	bool getOverrideLimiter() {
		return ((bool(*)(ParticleType*))link::getOverrideLimiter__12ParticleTypeCFv)
        (this);
	}

};

#endif