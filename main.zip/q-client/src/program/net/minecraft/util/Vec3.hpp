#ifndef __VEC_3_H__
#define __VEC_3_H__

#include <net/library/types.hpp>
#include <net/library/converter.hpp>

class Vec3 {
public:

    double x, y, z;

};

#endif