#ifndef __ARRAY_WITH_LENGTH_H__
#define __ARRAY_WITH_LENGTH_H__

#include <net/library/types.hpp>

template<typename T>
class arrayWithLength {
public:

	T *elements;
	int32_t length;

};

#endif