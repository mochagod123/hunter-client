#ifndef __CONV_H__
#define __CONV_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t convUtf8ToWstring__FPCc                                                                                         = 0x028D85B4;
    static const uint32_t convStringToWstring__FPw                                                                                        = 0x028D851C;
    static const uint32_t convWstringToString__FRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x028D83F4;
}

inline const wchar_t *convUtf8ToUtf16(const char *c) {
    int32_t sizec = strlen(c);
    wchar_t *wc = (wchar_t*)mem::malloc(sizec * 2 + 1 * 2);
    
    int32_t i;

    for (i = 0; i < sizec; i++) {
        wc[i] = c[i];
    }
    wc[sizec] = 0;

    return (const wchar_t*)wc;
}

inline const char *convUtf16ToUtf8(const wchar_t *wc) {
    int32_t sizewc = wcslen(wc);
    char *c = (char*)mem::malloc(sizewc + 1);

    int32_t i;

    for (i = 0; i < sizewc; i++) {
        c[i] = wc[i];
    }

    c[sizewc] = 0;

    return (const char*)c;
}

inline std::basic_string<wchar_t> convUtf8ToWstring(const char *c) {
    std::basic_string<wchar_t> wcstr;
    ((void(*)(std::basic_string<wchar_t>*, const char*))link::convUtf8ToWstring__FPCc)
    (&wcstr, c);
    return wcstr;
}

inline std::basic_string<wchar_t> convStringToWstring(wchar_t *wc) {
    std::basic_string<wchar_t> wcstr;
    ((void(*)(std::basic_string<wchar_t>*, wchar_t*))link::convUtf8ToWstring__FPCc)
    (&wcstr, wc);
    return wcstr;
}

inline wchar_t *convWstringToString(std::basic_string<wchar_t> wcstr) {
    wchar_t *wc;
    ((void(*)(wchar_t*, std::basic_string<wchar_t>*))link::convWstringToString__FRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
    (wc, &wcstr);
    return wc;
}

#endif