#ifndef __SOUND_EVENT_H__
#define __SOUND_EVENT_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>

namespace link {
    static const uint32_t getName__10SoundEventCFv = 0x028E11EC;
}

class SoundEvent {
public:

    static SoundEvent *block_chest_open asm("0x109C6228");

    std::basic_string<wchar_t> getName() {
        std::basic_string<wchar_t> name;
        ((void(*)(SoundEvent*, std::basic_string<wchar_t>*))link::getName__10SoundEventCFv)
        (this, &name);
        return name;
    }

};

#endif