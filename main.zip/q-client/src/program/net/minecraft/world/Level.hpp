#ifndef __LEVEL_H__
#define __LEVEL_H__

#include <net/library/types.hpp>
#include <net/library/basic_string.hpp>
#include <net/library/vector.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/entity/LivingEntity.hpp>
#include <net/minecraft/entity/player/Player.hpp>

namespace link {
    static const uint32_t getBlockId__5LevelFiN21                                                                                           = 0x0254CCAC;
    static const uint32_t getBlockData__5LevelFiN21                                                                                         = 0x0254D800;
    static const uint32_t addEntity__5LevelFQ2_5boost25shared_ptr__tm__8_6Entity                                                            = 0x02550EE4;
    static const uint32_t getPlayerByName__5LevelFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w = 0x02569AE4;
}

class Level {
public:

    uint32_t unk_0x0;
    uint32_t unk_0x4;
    uint32_t unk_0x8;
    uint32_t unk_0xC;
    uint32_t unk_0x10;
    uint32_t unk_0x14;
    uint32_t unk_0x18;
    uint32_t unk_0x1C;
    uint32_t unk_0x20;
    uint32_t unk_0x24;
    uint32_t unk_0x28;
    uint32_t unk_0x2C;
    uint32_t unk_0x30;
    std::vector<boost::shared_ptr<Entity>> entities;
    uint32_t unk_0x44;
    uint32_t unk_0x48;
    uint32_t unk_0x4C;
    uint32_t unk_0x50;
    uint32_t unk_0x54;
    uint32_t unk_0x58;
    uint32_t unk_0x5C;
    uint32_t unk_0x60;
    uint32_t unk_0x64;
    uint32_t unk_0x68;
    uint32_t unk_0x6C;
    uint32_t unk_0x70;
    uint32_t unk_0x74;
    uint32_t unk_0x78;
    uint32_t unk_0x7C;
    uint32_t unk_0x80;
    uint32_t unk_0x84;
    uint32_t unk_0x88;
    uint32_t unk_0x8C;
    uint32_t unk_0x90;
    uint32_t unk_0x94;
    uint32_t unk_0x98;
    uint32_t unk_0x9C;
    uint32_t unk_0xA0;
    uint32_t unk_0xA4;
    uint32_t unk_0xA8;
    uint32_t unk_0xAC;
    uint32_t unk_0xB0;
    uint32_t unk_0xB4;
    uint32_t unk_0xB8;
    uint32_t unk_0xBC;
    uint32_t unk_0xC0;
    std::vector<boost::shared_ptr<Player>> players;
    uint32_t unk_0xD4;
    uint32_t unk_0xD8;
    uint32_t unk_0xDC;
    uint32_t unk_0xE0;
    uint32_t unk_0xE4;
    uint32_t unk_0xE8;
    uint32_t unk_0xEC;
    uint32_t unk_0xF0;
    uint32_t unk_0xF4;
    uint32_t unk_0xF8;
    uint32_t unk_0xFC;
    uint32_t unk_0x100;
    uint32_t unk_0x104;
    uint32_t unk_0x108;
    uint32_t unk_0x10C;
    uint32_t unk_0x110;
    uint32_t unk_0x114;
    uint32_t unk_0x118;
    uint32_t unk_0x11C;
    uint32_t unk_0x120;
    uint32_t unk_0x124;
    uint32_t unk_0x128;
    uint32_t unk_0x12C;
    uint32_t unk_0x130;
    uint32_t unk_0x134;
    uint32_t unk_0x138;
    uint32_t unk_0x13C;
    uint32_t unk_0x140;
    uint32_t unk_0x144;
    uint32_t unk_0x148;
    uint32_t unk_0x14C;
    uint32_t unk_0x150;
    uint32_t unk_0x154;
    uint32_t unk_0x158;
    uint32_t unk_0x15C;
    uint32_t unk_0x160;
    uint32_t unk_0x164;
    uint32_t unk_0x168;
    uint32_t unk_0x16C;
    uint32_t unk_0x170;
    uint32_t unk_0x174;
    uint32_t unk_0x178;
    uint32_t unk_0x17C;
    uint32_t unk_0x180;
    uint32_t unk_0x184;
    uint32_t unk_0x188;
    uint32_t unk_0x18C;
    uint32_t unk_0x190;
    uint32_t unk_0x194;
    uint32_t unk_0x198;
    uint32_t unk_0x19C;
    uint32_t unk_0x1A0;
    uint32_t unk_0x1A4;
    uint32_t unk_0x1A8;
    uint32_t unk_0x1AC;
    uint32_t unk_0x1B0;
    uint32_t unk_0x1B4;
    std::vector<boost::shared_ptr<LivingEntity>> livingEntities;
    uint32_t unk_0x1C8;
    uint32_t unk_0x1CC;
    uint32_t unk_0x1D0;
    uint32_t unk_0x1D4;
    uint32_t unk_0x1D8;
    uint32_t unk_0x1DC;
    uint32_t unk_0x1E0;
    uint32_t unk_0x1E4;
    uint32_t unk_0x1E8;
    uint32_t unk_0x1EC;
    uint32_t unk_0x1F0;
    uint32_t unk_0x1F4;
    uint32_t unk_0x1F8;
    uint32_t unk_0x1FC;
    uint32_t unk_0x200;

    int32_t getBlockId(int32_t x, int32_t y, int32_t z) {
        return ((int32_t(*)(Level*, int32_t, int32_t, int32_t))link::getBlockId__5LevelFiN21)
        (this, x, y, z);
    }
    int32_t getBlockData(int32_t x, int32_t y, int32_t z) {
        return ((int32_t(*)(Level*, int32_t, int32_t, int32_t))link::getBlockData__5LevelFiN21)
        (this, x, y, z);
    }

    inline void addEntity(boost::shared_ptr<Entity> entity) {
        return ((void(*)(Level*, boost::shared_ptr<Entity>))link::addEntity__5LevelFQ2_5boost25shared_ptr__tm__8_6Entity)
        (this, entity);
    }

    inline boost::shared_ptr<Player> getPlayerByName(const std::basic_string<wchar_t> &wcstr) {
        boost::shared_ptr<Player> player;
        ((void(*)(Level*, boost::shared_ptr<Player>*, std::basic_string<wchar_t>))link::getPlayerByName__5LevelFRCQ2_3std78basic_string__tm__58_wQ2_3std20char_traits__tm__2_wQ2_3std18allocator__tm__2_w)
        (this, &player, wcstr);
        return player;
    }
    
};

#endif