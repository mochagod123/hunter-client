#ifndef __SERVER_LEVEL_H__
#define __SERVER_LEVEL_H__

#include <net/library/types.hpp>
#include <net/library/shared_ptr.hpp>
#include <net/minecraft/entity/Entity.hpp>
#include <net/minecraft/world/Level.hpp>

namespace link {
    static const uint32_t addGlobalEntity__11ServerLevelFQ2_5boost25shared_ptr__tm__8_6Entity = 0x032BA450;
}

class ServerLevel : public Level {
public:

    void addGlobalEntity(boost::shared_ptr<Entity> entity) {
        return ((void(*)(ServerLevel*, boost::shared_ptr<Entity>))link::addGlobalEntity__11ServerLevelFQ2_5boost25shared_ptr__tm__8_6Entity)
        (this, entity);
    }

};

#endif