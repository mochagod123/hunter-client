#ifndef __LEVEL_CHUNK_H__
#define __LEVEL_CHUNK_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t CreateNewThreadStorage__10LevelChunkSFv = 0x025A1AD0;
}

class LevelChunk {
public:

    static inline void CreateNewThreadStorage() {
        return ((void(*)())link::CreateNewThreadStorage__10LevelChunkSFv)
        ();
    }

};

#endif