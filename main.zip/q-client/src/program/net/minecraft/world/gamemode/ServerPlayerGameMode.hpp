#ifndef __SERVER_PLAYER_GAME_MODE_H__
#define __SERVER_PLAYER_GAME_MODE_H__

#include <net/library/types.hpp>
#include <net/minecraft/util/BlockPos.hpp>

namespace link {
    static const uint32_t destroyBlock__20ServerPlayerGameModeFRC8BlockPos = 0x032DE9D8;
}

class ServerPlayerGameMode {
public:

    void destroyBlock(BlockPos position) {
        return ((void(*)(ServerPlayerGameMode*, BlockPos))link::destroyBlock__20ServerPlayerGameModeFRC8BlockPos)
        (this, position);
    }

};

#endif