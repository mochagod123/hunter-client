#ifndef __MAP_DECORATION_H__
#define __MAP_DECORATION_H__

namespace link {
    static const uint32_t byIcon__Q2_13MapDecoration4TypeSFUc                   = 0x025CD738;
    static const uint32_t __ct__13MapDecorationFPCQ2_13MapDecoration4TypecN22ib = 0x025CD05C;
}

class MapDecoration {
public:

    class Type {
    public:

        static Type *byIcon(uint8_t icon) {
			return ((Type*(*)(uint8_t))link::byIcon__Q2_13MapDecoration4TypeSFUc)
            (icon);
		}

    };

    static inline MapDecoration *Ctor(MapDecoration *ptr, Type *type, int8_t posX, int8_t posY, int8_t rotation, int32_t unk_i0, bool unk_b0) {
        return ((MapDecoration*(*)(MapDecoration*, Type*, int8_t, int8_t, int8_t, int32_t, bool))link::__ct__13MapDecorationFPCQ2_13MapDecoration4TypecN22ib)
        (ptr, type, posX, posY, rotation, unk_i0, unk_b0);
    }

};

#endif