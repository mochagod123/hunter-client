#ifndef __DIRECTORY_LEVEL_STORAGE_H__
#define __DIRECTORY_LEVEL_STORAGE_H__

class DirectoryLevelStorage {
public:

    class PlayerMappings {
    public:



    };

};

#endif