#ifndef __ELEMENT_STORAGE_H__
#define __ELEMENT_STORAGE_H__

#include <net/library/types.hpp>

namespace link {
    static const uint32_t __CPR75__CreateNewThreadStorage__14ElementStorageSFQ2_J24J12eHESThreadId = 0x0229CFFC;
}

class ElementStorage {
public:

    enum class eHESThreadId {
        unk_0,
        unk_1
    };

    static inline void CreateNewThreadStorage(ElementStorage::eHESThreadId eHesThreadId) {
        return ((void(*)(ElementStorage::eHESThreadId))link::__CPR75__CreateNewThreadStorage__14ElementStorageSFQ2_J24J12eHESThreadId)
        (eHesThreadId);
    }

};

#endif