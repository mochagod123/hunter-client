#include "program.h"
#include "../dynamic_libs/os_functions.h"

#include "net/mc.h"
#include "net/library/MinecraftPatcher.hpp"
#include "kernel.h"
#include "framerate/Framerate.h"
#include <dynamic_libs/curl_functions.h>
#include <curl/curl.h>
// #include "downloader/Downloader.h"

#define get_value(address,offset) (*( (uint32_t*) ((address)+(offset)) ))
#define MC_GL_ZERO                  0
#define MC_GL_ONE                   1
#define MC_GL_SRC_ALPHA             4
#define MC_GL_ONE_MINUS_SRC_ALPHA   5

#define MC_GL_TRIANGLES             0
#define MC_GL_TRIANGLE_FAN          1
#define MC_GL_QUADS                 2
#define MC_GL_QUADS_STRIP           3
#define MC_GL_LINES                 4
#define MC_GL_LINES_STRIP           5

#define MC_GL_MODELVIEW             0
#define MC_GL_PROJECTION            1
#define MC_GL_TEXTURE               2

char *joinNNID_old = nullptr;

bool notifyModeEnabled = false;
bool inGame = false;
bool isInitialized = false;
bool not_inGame_isInitialized = false;
bool isRenderAllowed = true;
void (*real_handleChat)(ClientPacketListener *_this, boost::shared_ptr<ClientboundChatPacket> packet);
void (*real_handlePreLogin)(void *_this, boost::shared_ptr<ServerboundPreLoginPacket> packet);
void (*real_renderSkull)(void *_this, float arg_f0, float arg_f1, float arg_f2, Direction const *direction, float arg_f3, float arg_f4, int32_t skullType, int32_t arg_i0, float arg_f5, bool arg_b0);
void (*real_SetPresenceString)(CProfile *_this, int32_t unk);
void (*real_handlePlayerAction)(ServerGamePacketListenerImpl *_this, boost::shared_ptr<ServerboundPlayerActionPacket> packet);
void (*real_dispense)(void *_this, void *block_source, not_null_ptr<ItemInstance> item_instance);
double (*real_getWidth)(void *_this);
double (*real_getHeight)(void *_this);
void (*real_UpdateStatusEffectTile)(void *_this, int32_t unk_i0, int32_t unk_i1, int32_t unk_i2, bool unk_b0, float unk_f0);
void (*real_copy)(ItemInstance *_this, void *unk);
void (*real__ExitWorld)(void *unk);
bool isInWorld = false;

bool isZoomEnabled = false;
float (*real_getFieldOfViewModifier)(AbstractClientPlayer *_this);

unsigned long long basetime = Minecraft::currentTimeMillis();
int count = 0;
float clicks = 0.0f;

bool grapplerEnabled = false;
bool xyzview = false;
bool fpsview = false;

wchar_t *playing_sound[32];
int32_t current_playing_count = 0;

#define get_value(address,offset) (*( (uint32_t*) ((address)+(offset)) ))

bool isShowingKeyboardByChatClient = false;

typedef struct {
    void* (*p_memset)(void * dest, unsigned int value, unsigned int bytes);
    void* (*p_memcpy)(void * dest, void * val, unsigned int size);
    void  (*DCFlushRange)(const void *dest, unsigned int size);
    void  (*ICInvalidateRange)(const void *dest, unsigned size);
    void* (*MEMAllocFromDefaultHeapEx)(unsigned int size, unsigned int align);
    void* (*MEMAllocFromDefaultHeap)(unsigned int size);
    void  (*MEMFreeToDefaultHeap)(void *ptr);
    void (*OSExitThread)(int);
    void (*OSYieldThread)(void);
    void (*OSFatal)(const char *msg);
    void (*OSSleepTicks)(unsigned long long time);
    int  (*OSCreateThread)(void *thread, void *entry, int argc, void *args, unsigned int stack, unsigned int stack_size, int priority, unsigned short attr);
    int  (*OSResumeThread)(void *thread);
    int  (*OSIsThreadTerminated)(void *thread);
    int  (*OSJoinThread)(void *thread,int * returnVal);
} os_function_ptr_t;

typedef struct {
    CURLcode (*n_curl_global_init)(long flags);
    CURL* (*n_curl_easy_init)();
    CURLcode (*n_curl_easy_setopt)(void *cptr, CURLoption, ...);
    CURLcode (*n_curl_easy_perform)(void *cptr);
    void (*n_curl_easy_cleanup)(void *cptr);
    CURLcode (*n_curl_easy_getinfo)(void *cptr, CURLINFO, ...);
    CURL *curl_ptr;
} curl_function_ptr_t;

typedef struct {
    void (*socket_lib_init)();
} nsysnet_function_ptr_t;

void init_os_function_ptr(os_function_ptr_t *ptr) {
    unsigned int coreinit_handle;
    OSDynLoad_Acquire("coreinit.rpl", &coreinit_handle);

    unsigned int *function_pointer;

    OSDynLoad_FindExport(coreinit_handle, 1, "MEMAllocFromDefaultHeapEx", &function_pointer);
    ptr->MEMAllocFromDefaultHeapEx = (void*(*)(unsigned int, unsigned int))*function_pointer;
    OSDynLoad_FindExport(coreinit_handle, 1, "MEMAllocFromDefaultHeap", &function_pointer);
    ptr->MEMAllocFromDefaultHeap = (void*(*)(unsigned int))*function_pointer;
    OSDynLoad_FindExport(coreinit_handle, 1, "MEMFreeToDefaultHeap", &function_pointer);
    ptr->MEMFreeToDefaultHeap = (void (*)(void *))*function_pointer;

    OSDynLoad_FindExport(coreinit_handle, 0, "memset", &ptr->p_memset);
    OSDynLoad_FindExport(coreinit_handle, 0, "memcpy", &ptr->p_memcpy);
    OSDynLoad_FindExport(coreinit_handle, 0, "DCFlushRange", &ptr->DCFlushRange);
    OSDynLoad_FindExport(coreinit_handle, 0, "ICInvalidateRange", &ptr->ICInvalidateRange);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSFatal", &ptr->OSFatal);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSSleepTicks", &ptr->OSSleepTicks);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSCreateThread", &ptr->OSCreateThread);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSResumeThread", &ptr->OSResumeThread);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSIsThreadTerminated", &ptr->OSIsThreadTerminated);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSExitThread", &ptr->OSExitThread);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSJoinThread", &ptr->OSJoinThread);
    OSDynLoad_FindExport(coreinit_handle, 0, "OSYieldThread", &ptr->OSYieldThread);
}

void init_curl_function_ptr(curl_function_ptr_t *ptr) {
    unsigned int nlibcurl_handle;
    OSDynLoad_Acquire("nlibcurl.rpl", &nlibcurl_handle);

    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_global_init", &ptr->n_curl_global_init);
    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_easy_init", &ptr->n_curl_easy_init);
    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_easy_setopt", &ptr->n_curl_easy_setopt);
    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_easy_perform", &ptr->n_curl_easy_perform);
    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_easy_getinfo", &ptr->n_curl_easy_getinfo);
    OSDynLoad_FindExport(nlibcurl_handle, 0, "curl_easy_cleanup", &ptr->n_curl_easy_cleanup);
    ptr->curl_ptr = NULL;
}

void init_nsysnet_function_ptr(nsysnet_function_ptr_t *ptr) {
    unsigned int nsysnet_handle;
    OSDynLoad_Acquire("nsysnet.rpl", &nsysnet_handle);

    OSDynLoad_FindExport(nsysnet_handle, 0, "socket_lib_init", &ptr->socket_lib_init);
}

typedef struct {
    void *progressArg;
    unsigned char *buffer;
    unsigned int filesize;
    curl_function_ptr_t curl_functions;
    os_function_ptr_t os_functions;
    nsysnet_function_ptr_t nsysnet_functions;
} curl_private_data_t;

os_function_ptr_t g_os_functions;
curl_function_ptr_t g_curl_functions;
nsysnet_function_ptr_t g_nsysnet_functions;

void handlePreLogin(void *_this, boost::shared_ptr<ServerboundPreLoginPacket> packet) {
    real_handlePreLogin(_this, packet);
}

void *xmemcpy(void *addr, void *val, unsigned int size) {
    char *addrp      = (char*)addr;
    const char *valp = (const char*)val;
    while (size--) {
        *addrp++ = *valp++;
    }
    return addr;
}

// #define EXPORT_DECL(res, func, ...)     res (* func)(__VA_ARGS__) __attribute__((section(".data"))) = 0;

void *xrealloc(void *ptr, size_t size, os_function_ptr_t os_functions) {
    void *newPtr;

    if (!ptr) {
        newPtr = os_functions.MEMAllocFromDefaultHeap(size);
        if (!newPtr) {
            goto error;
        }
    } else {
        newPtr = os_functions.MEMAllocFromDefaultHeap(size);
        if (!newPtr) {
            goto error;
        }

        xmemcpy(newPtr, ptr, size);

        os_functions.MEMFreeToDefaultHeap(ptr);
    }

    return newPtr;
error:
    return NULL;
}

int curlCallback(void *buffer, int size, int nmemb, void *userp) {
    curl_private_data_t *private_data = (curl_private_data_t *)userp;
    int read_len = size * nmemb;

    if(0) {
        // int res = private_data->file->write((unsigned char*)buffer, read_len);
        // private_data->filesize += res;
        // return res;
    } else {
        if(!private_data->buffer) {
            private_data->buffer = (unsigned char*) private_data->os_functions.MEMAllocFromDefaultHeap(read_len);
        } else {
            unsigned char *tmp = (unsigned char*) xrealloc(private_data->buffer, private_data->filesize + read_len, private_data->os_functions);
            if(!tmp) {
                private_data->os_functions.MEMFreeToDefaultHeap(private_data->buffer);
                private_data->buffer = NULL;
            } else {
                private_data->buffer = tmp;
            }
        }

        if(!private_data->buffer) {
            private_data->filesize = 0;
            return -1;
        }

        xmemcpy(private_data->buffer + private_data->filesize, buffer, read_len);
        private_data->filesize += read_len;
        return read_len;
    }
}

int internalGetFile(const char *url, curl_private_data_t *private_data) {
    int result = 0;
    int resp = 404;
    int ret = -1;
    private_data->nsysnet_functions.socket_lib_init();
    private_data->curl_functions.curl_ptr = private_data->curl_functions.n_curl_easy_init();
    if(!private_data->curl_functions.curl_ptr) {
        return 0;
    }

    /*
    std::string prefix = "https";
    if(strncmp(downloadUrl.c_str(), prefix.c_str(), prefix.size()) == 0) {
        ssl_context = NSSLCreateContext(0);
        if(ssl_context < 0) {
            goto exit_error;
        }

        // Add all existing certs
        for(int i = 100; i<106; i++) {
            NSSLAddServerPKI(ssl_context,i);
        }

        for(int i = 1001; i<1034; i++) {
            NSSLAddServerPKI(ssl_context,i);
        }
        n_curl_easy_setopt(curl, CURLOPT_GSSAPI_DELEGATION, ssl_context); // Is CURLOPT_NSSL_CONTEXT on the Wii U
    }
    */

    private_data->curl_functions.n_curl_easy_setopt(private_data->curl_functions.curl_ptr, CURLOPT_URL, url);
    private_data->curl_functions.n_curl_easy_setopt(private_data->curl_functions.curl_ptr, CURLOPT_WRITEFUNCTION, curlCallback);
    private_data->curl_functions.n_curl_easy_setopt(private_data->curl_functions.curl_ptr, CURLOPT_WRITEDATA, private_data);
    private_data->curl_functions.n_curl_easy_setopt(private_data->curl_functions.curl_ptr, CURLOPT_USERAGENT, "r/4.3.2.11274.JP");
    private_data->curl_functions.n_curl_easy_setopt(private_data->curl_functions.curl_ptr, CURLOPT_FOLLOWLOCATION, 1L);

    // n_curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);

    /*
    if(private_data->progressCallback) {
        n_curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, FileDownloader::curlProgressCallback);
        n_curl_easy_setopt(curl, CURLOPT_PROGRESSDATA, private_data);
        n_curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    }
    */

    ret = private_data->curl_functions.n_curl_easy_perform(private_data->curl_functions.curl_ptr);
    if(ret) {
        
    }

    if(!private_data->filesize) {
        
    }

    private_data->curl_functions.n_curl_easy_getinfo(private_data->curl_functions.curl_ptr, CURLINFO_RESPONSE_CODE, &resp);

    if(resp != 200) {
        
    }

    result = 1;

exit_error:
    /*
    if(ssl_context >= 0) {
        NSSLDestroyContext(ssl_context);
    }
    */

    private_data->curl_functions.n_curl_easy_cleanup(private_data->curl_functions.curl_ptr);
    return result;
}

int getFile(const char *url, unsigned char **outBuffer, int *outSize, curl_function_ptr_t curl_functions, os_function_ptr_t os_functions, nsysnet_function_ptr_t nsysnet_functions) {
    curl_private_data_t private_data;
    // private_data.progressCallback = callback;
    private_data.progressArg = 0;
    private_data.buffer = 0;
    private_data.filesize = 0;

    private_data.curl_functions    = curl_functions;
    private_data.os_functions      = os_functions;
    private_data.nsysnet_functions = nsysnet_functions;

    int result = internalGetFile(url, &private_data);

    if(private_data.filesize > 0 && private_data.buffer) {
        unsigned char *buffer = (unsigned char*)os_functions.MEMAllocFromDefaultHeap(private_data.filesize);
        xmemcpy(buffer, private_data.buffer, private_data.filesize);
        *outBuffer = buffer;
        *outSize   = private_data.filesize;
    }

    if(private_data.buffer) {
        os_functions.MEMFreeToDefaultHeap(private_data.buffer);
    }

    return result;
}

void _ExitWorld(void *unk) {
    real__ExitWorld(unk);
}

inline double getDistance(Entity *entity_1, Entity *entity_2) {
    Vec3 entity_1_pos = entity_1->position;
    Vec3 entity_2_pos = entity_2->position;
    
    return sqrt((entity_1_pos.x - entity_2_pos.x) * (entity_1_pos.x-entity_2_pos.x) + 
                (entity_1_pos.y - entity_2_pos.y) * (entity_1_pos.y - entity_2_pos.y) + 
                (entity_1_pos.z - entity_2_pos.z) * (entity_1_pos.z - entity_2_pos.z));
}

boost::shared_ptr<Player> getPlayerByName(Level *level, std::basic_string<wchar_t> name) {
    boost::shared_ptr<Player> player = level->getPlayerByName(name);
    if (player.get() != nullptr) {
        return player;
    }
    wchar_t result[32];
    swprintf(result, 32, L"[Q] %ls", name.c_str());
    player = level->getPlayerByName(result);
    if (player.get() == nullptr) {
        wchar_t result2[32];
        swprintf(result2, 32, L"[Q-DEV] %ls", name.c_str());
        player = level->getPlayerByName(result2);
        if (player.get() == nullptr) {
            wchar_t result3[32];
            swprintf(result3, 32, L"[P] %ls", name.c_str());
            player = level->getPlayerByName(result3);
            if (player.get() == nullptr) {
                wchar_t result4[32];
                swprintf(result4, 32, L"[P-DEV] %ls", name.c_str());
                player = level->getPlayerByName(result4);
            }
        }
    }
    return player;
}

void (*real_retrieve)(FishingHook *_this);

void GrapplingHook() {
    Minecraft *mc = Minecraft::GetInstance();
    Level     *level  = mc->getLevel(0);

    LocalPlayer *player = mc->thePlayer;
    if (level != nullptr) {
        boost::shared_ptr<Entity> target = player->thrownItem;
        if (target.get() != nullptr && Item::getId(player->getCarriedItem()->base) == 346) {
            Vec3 target_pos = target->position;
            Vec3 player_pos = player->position;

            double m = 0.25d * 2.0d;
            double d = getDistance(player, target.get());
            double v_x = (1.0d + m * d) * (target_pos.x - player_pos.x) / d;
            double v_y = (1.0d + 0.3d * d) * (target_pos.y - player_pos.y) / d - 0.5d * 0.35d * d;
            double v_z = (1.0d + m * d) * (target_pos.z - player_pos.z) / d;

            *(double*)0x40000000 = v_x;
            *(double*)0x40000010 = v_y;
            *(double*)0x40000020 = v_z;
        }
    }
}

void UpdateStatusEffectTile(void *_this, int32_t unk_i0, int32_t unk_i1, int32_t unk_i2, bool unk_b0, float unk_f0) {
    if ((uint32_t)_this >= 0x10000000) {
        real_UpdateStatusEffectTile(_this, unk_i0, unk_i1, unk_i2, unk_b0, unk_f0);
    }
}

void retrieve(FishingHook *_this) {
    boost::shared_ptr<Player> owner = _this->getOwner();
    if (owner.get() == nullptr) {
        real_retrieve(_this);
        return;
    }
    else if (grapplerEnabled == false) {
        real_retrieve(_this);
        return;
    }

    real_retrieve(_this);

    double x = *(double*)0x40000000;
    double y = *(double*)0x40000010;
    double z = *(double*)0x40000020;

    owner->motionX = x;
    owner->motionY = y;
    owner->motionZ = z;
}

void SetPresenceString(CProfile *_this, int32_t unk) {
    nn::fp::UpdateGameModeDescription(L"リオレウスを討伐中。。");
}

void NotifyMessage(const wchar_t *title, const wchar_t *text) {
    L10N::ReplaceString(0x1AD380AB, (wchar_t*)title);
    L10N::ReplaceString(0x4523129E, (wchar_t*)text);

    ConsoleUIController::GetUIController()->SetAchievementUnlocked(0, 0x60, 0x0, 0x0);
    ConsoleUIController::GetUIController()->PlayUISFX(SoundEvent::block_chest_open);
}

void client_handleChat(ClientPacketListener *_this, boost::shared_ptr<ClientboundChatPacket> packet) {
    wchar_t *msg = packet->str_v[0].c_str();
    if (mem::memcmp(msg, L"_vnf", wcslen(L"_vnf") * sizeof(wchar_t)) == 0) {
        msg += wcslen(L"vnf ");
        NotifyMessage(msg, L"");
        packet.detail->use_count -= 1;
        return;
    }
    packet.detail->use_count += 1;
    real_handleChat(_this, packet);
}

bool multipickEnabled = false;
int multipickSize = 0;

void handlePlayerAction(ServerGamePacketListenerImpl *_this, boost::shared_ptr<ServerboundPlayerActionPacket> packet) {
    if (multipickEnabled == true) {
        int32_t size = multipickSize;
        if (packet->action == ServerboundPlayerActionPacket::Action::continueDestroyBlock) {
            for (int32_t ox = size - size - size; ox < size + size; ox++)
            for (int32_t oy = size - size - size; oy < size + size; oy++)
            for (int32_t oz = size - size - size; oz < size + size; oz++) {
                BlockPos position(packet->position.x + ox, packet->position.y + oy, packet->position.z + oz);
                _this->player->gamemode->destroyBlock(position);
            }
        }
    }
    real_handlePlayerAction(_this, packet);
}

void dispense(void *_this, void *block_source, not_null_ptr<ItemInstance> item_instance) {
    if (_this != nullptr) {
        real_dispense(_this, block_source, item_instance);
    }
}

void copy(ItemInstance *_this, void *unk) {
    if ((uint32_t)_this <= 0x18000000) return;

    if ((uint32_t)_this >= 0x40000000) return;

    real_copy(_this, unk);
}

void renderSkull(void *_this, float arg_f0, float arg_f1, float arg_f2, Direction const *direction, float arg_f3, float arg_f4, int32_t skullType, int32_t arg_i0, float arg_f5, bool arg_b0) {
    if (skullType >= 6 || skullType <= -1) {
        skullType = 0;
    }
    real_renderSkull(_this, arg_f0, arg_f1, arg_f2, direction, arg_f3, arg_f4, skullType, arg_i0, arg_f5, arg_b0);
}

double getWidth(void *_this) {
    /*
    if ((uint32_t)_this <= 0x10000000) {
        return 0.0;
    }
    return real_getWidth(_this);
    */
    return 0.0;
}

double getHeight(void *_this) {
    /*
    if ((uint32_t)_this <= 0x10000000) {
        return 0.0;
    }
    return real_getHeight(_this);
    */
    return 0.0;
}

void OnChatPacket(wchar_t *message, wchar_t *dmId = nullptr) {
	boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, message, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
	std::vector<boost::shared_ptr<ServerPlayer> > players = MinecraftServer::GetInstance()->getPlayers()->players;

	for (int32_t i = 0; i < players.size(); i++) {
        if (dmId != nullptr) {
            boost::shared_ptr<Player> player = getPlayerByName(MinecraftServer::GetInstance()->getLevel(0), dmId);
            if (player.get() == nullptr) {
                return;
            } else {
                ((ServerPlayer*)player.get())->listener->send(packet);
                return;
            }
        }
        else {
            players[i]->listener->send(packet);
        }
	}
}

void handleHelp() {
    log(L"ヘルプは、付いてきた説明書に載っています！");
}

void onEnable_grappler(wchar_t *name) {
    grapplerEnabled = true;

    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"Grappler Enabled", result);
}

void onDisable_grappler(wchar_t *name) {
    grapplerEnabled = false;

    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"Grappler Disabled", result);
}

void onEnable_vc_mute(wchar_t *name) {
    kernel_write_value((void *)0x035F3464, (void *)0x4E800020L);

    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"Voice Chat Disabled", result);
}

void onDisable_vc_mute(wchar_t *name) {
    kernel_write_value((void *)0x035F3464, (void *)0x7C0802A6L);

    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"Voice Chat Enabled", result);
}

void handleGiveItem(wchar_t *name, wchar_t *id, int32_t item_id, int32_t count, int32_t damage) {
    Level *level = Minecraft::GetInstance()->getLevel(0);
    boost::shared_ptr<Player> player = getPlayerByName(level, id);

    if (item_id == 397) {
        if (damage >= 6 || damage <= -1) {
            NotifyMessage(L"Failed to execute GiveItemCommand", L"");
            return;
        }
    }
    else if (item_id == 144) {
        if (damage != 0) {
            NotifyMessage(L"Failed to execute GiveItemCommand", L"");
            return;
        }
    }

    if (player.get() != nullptr) {
        boost::shared_ptr<Packet> packet(GiveItemCommand::preparePacket(player, item_id, count, damage, L"give"));
        Minecraft::GetInstance()->thePlayer->listener->send(packet);
        wchar_t result[64];
        swprintf(result, 64, L"Mod name %ls", name);
        NotifyMessage(L"GiveItemCommand executed", result);
    }
}

void handleEnch(wchar_t *name, wchar_t *id, int32_t ench_id, int32_t lvl) {
    Level *level = Minecraft::GetInstance()->getLevel(0);
    boost::shared_ptr<Player> player = getPlayerByName(level, id);

    if (player.get() != nullptr) {
        boost::shared_ptr<Packet> packet(EnchantItemCommand::preparePacket(player, ench_id, lvl));
        Minecraft::GetInstance()->thePlayer->listener->send(packet);
        wchar_t result[64];
        swprintf(result, 64, L"Mod name %ls", name);
        NotifyMessage(L"EnchantItemCommand executed", result);
    }
}

bool canZoom = false;

void handleKill(wchar_t *name) {
    boost::shared_ptr<Packet> packet(KillCommand::preparePacket());
    Minecraft::GetInstance()->thePlayer->listener->send(packet);
    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"KillCommand executed", result);
}

void handleTime(wchar_t *name, int64_t time) {
    boost::shared_ptr<Packet> packet(TimeCommand::preparePacket(time, time));
    Minecraft::GetInstance()->thePlayer->listener->send(packet);
    wchar_t result[64];
    swprintf(result, 64, L"Mod name %ls", name);
    NotifyMessage(L"TimeCommand executed", result);
}

void not_found(wchar_t *name) {
    NotifyMessage(L"! Mod Not Found !", name);
}

void handleChangeMultiPick(const wchar_t *args) {
    int size;
    swscanf(args, L"%d", &size);
    multipickSize = size;
    NotifyMessage(L"Multipick size changed !", L"");
}

void packetHandler(wchar_t *args) {
    wchar_t buffer[64];
    for (int i = 0; i < wcslen(args); i++) {
        if (args[i] == L' ' ) {
            buffer[i] = 0x0000;
            break;
        }
        buffer[i] = args[i];
    }
    if (mem::memcmp(args, L"vc on", wcslen(L"vc on") * sizeof(wchar_t)) == 0) {
        onDisable_vc_mute(buffer);
    }
    else if (mem::memcmp(args, L"vc off", wcslen(L"vc off") * sizeof(wchar_t)) == 0) {
        onEnable_vc_mute(buffer);
    }
    else if (mem::memcmp(args, L"join on", wcslen(L"join on") * sizeof(wchar_t)) == 0) {
        kernel_write_value((void*)0x02D5B28C, 0x3BC00008L);

        NotifyMessage(L"Join enabled", L"");
    }
    else if (mem::memcmp(args, L"nofall on", wcslen(L"nofall on") * sizeof(wchar_t)) == 0) {
        if (CGameNetworkManager::GetNetworkManager()->IsHost() != true) {
            NotifyMessage(L"You are not host !", L"");
            return;
        }
    }
    else if (mem::memcmp(args, L"join off", wcslen(L"join off") * sizeof(wchar_t)) == 0) {
        kernel_write_value((void*)0x02D5B28C, 0x3BC00001L);
        NotifyMessage(L"Join disabled", L"");
    }
    else if (mem::memcmp(args, L"multipick size", wcslen(L"multipick size") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"multipick size");
        if (CGameNetworkManager::GetNetworkManager()->IsHost() == false) {
            NotifyMessage(L"You are not the host !", L"This only works if you are the host");
            return;
        }
        if (multipickEnabled == false) {
            NotifyMessage(L"Multipick is not enabled yet !", L"");
            return;
        }
        handleChangeMultiPick(args);
    }
    else if (mem::memcmp(args, L"multipick on", wcslen(L"multipick on") * sizeof(wchar_t)) == 0) {
        if (CGameNetworkManager::GetNetworkManager()->IsHost() == false) {
            NotifyMessage(L"You are not the host !", L"This only works if you are the host");
            return;
        }
        multipickEnabled = true;
        NotifyMessage(L"Multipick Enabled !", L"");
    }
    else if (mem::memcmp(args, L"multipick off", wcslen(L"multipick off") * sizeof(wchar_t)) == 0) {
        if (CGameNetworkManager::GetNetworkManager()->IsHost() == false) {
            NotifyMessage(L"You are not the host !", L"This only works if you are the host");
            return;
        }
        multipickEnabled = false;
        NotifyMessage(L"Multipick Disabled !", L"");
    }
    else if (mem::memcmp(args, L"maxplayer", wcslen(L"maxplayer") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"maxplayer ");
        int max;
        int success = swscanf(args, L"%d", &max);
        if (success != 1) {
            NotifyMessage(L"Failed change max player", L"");
            return;
        }
        else if (max >= 9) {
            NotifyMessage(L"Failed change max player max is 8", L"");
            return;
        }
        int value = 0x3BC00000 + max;
        kernel_write_value((void*)0x02D5B28C, value);

        NotifyMessage(L"MaxPlayer changed", L"");
    }
    else if (mem::memcmp(args, L"help", wcslen(L"help") * sizeof(wchar_t)) == 0) {
        handleHelp();
    }
    else if (mem::memcmp(args, L"grappler on", wcslen(L"grappler on") * sizeof(wchar_t)) == 0) {
        onEnable_grappler(buffer);
    }
    else if (mem::memcmp(args, L"grappler off", wcslen(L"grappler off") * sizeof(wchar_t)) == 0) {
        onDisable_grappler(buffer);
    }
    else if (mem::memcmp(args, L"zoom on", wcslen(L"zoom on") * sizeof(wchar_t)) == 0) {
        canZoom = true;

        NotifyMessage(L"You can now zoom", L"Zoom");
    }
    else if (mem::memcmp(args, L"zoom off", wcslen(L"zoom off") * sizeof(wchar_t)) == 0) {
        canZoom = false;

        NotifyMessage(L"You cant now zoom", L"Zoom");
    }
    else if (mem::memcmp(buffer, L"give", wcslen(L"give") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"give ");
        wchar_t id[17];
        int item_id;
        int count;
        int damage;

        int success = swscanf(args, L"%ls%d%d%d", id, &item_id, &count, &damage);
        if (success != 4) {
            NotifyMessage(L"Failed to execute command", L"Type is Give");
            return;
        }
        handleGiveItem(buffer, id, item_id, count, damage);
    }
    else if (mem::memcmp(buffer, L"rpc", wcslen(L"rpc") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"rpc");
        
        nn::fp::UpdateGameModeDescription(args);
        NotifyMessage(L"Successfully changed RPC text", args);
    }
    else if (mem::memcmp(buffer, L"time", wcslen(L"time") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"time ");
        int64_t time;

        int success = swscanf(args, L"%lld", &time);
        if (success != 1) {
            NotifyMessage(L"Failed to execute command", L"Type is Time");
            return;
        }
        handleTime(buffer, time);
    }
    else if (mem::memcmp(buffer, L"ench", wcslen(L"ench") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"ench ");
        wchar_t id[17];
        int32_t ench_id;
        int32_t lvl;

        int success = swscanf(args, L"%ls%d%d", id, &ench_id, &lvl);
        if (success != 3) {
            NotifyMessage(L"Failed to execute command", L"Type is Enchant");
            return;
        }
        handleEnch(buffer, id, ench_id, lvl);
    }
    else if (mem::memcmp(buffer, L"kill", wcslen(L"kill") * sizeof(wchar_t)) == 0) {
        handleKill(buffer);
    }
    else if (mem::memcmp(args, L"render on", wcslen(L"render on") * sizeof(wchar_t)) == 0) {
        isRenderAllowed = true;
    }
    else if (mem::memcmp(args, L"render off", wcslen(L"render off") * sizeof(wchar_t)) == 0) {
        isRenderAllowed = false;
    }
    /*
    else if (mem::memcmp(buffer, L"notify", wcslen(L"notify") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"notify ");
        if (!CGameNetworkManager::GetNetworkManager()->IsHost()) {
            NotifyMessage(L"Failed to send notify", L"You are not host");
            return;
        }
        wchar_t result[128];
        swprintf(result, 128, L"_vnf %ls %ls", MinecraftServer::GetInstance()->getPlayers()->players[0]->getDisplayName().c_str(), args);
        boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, args, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
        MinecraftServer::GetInstance()->getPlayers()->players[0]->listener->send(packet);
    }
    */
    else if (mem::memcmp(args, L"dm", wcslen(L"dm") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"dm ");
        wchar_t id_buffer[32];
        for (int i = 0; i < wcslen(args); i++) {
            if (args[i] == L' ' ) {
                break;
            }
            id_buffer[i] = args[i];
        }
        args += wcslen(id_buffer) + wcslen(L" ");
        Level *level = Minecraft::GetInstance()->getLevel(0);
        boost::shared_ptr<Player> player = getPlayerByName(level, id_buffer);
        if (player.get() == nullptr) {
            wchar_t resultname[48];
            swprintf(resultname, 48, L"Player name %ls not found", id_buffer);
            NotifyMessage(L"! Player Not Found !", resultname);
            return;
        }
        wchar_t res[150];
        swprintf(res, 150, L"_vdm %ls %ls", id_buffer, args);
        boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, res, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
		Minecraft::GetInstance()->thePlayer->listener->send(packet);
    }
    /*
    else if (mem::memcmp(args, L"notify", wcslen(L"notify") * sizeof(wchar_t)) == 0) {
        args += wcslen(L"notify ");
        if (CGameNetworkManager::GetNetworkManager()->IsHost() == false) {
            NotifyMessage(L"Failed to execute mod", L"Reason: You are not host of this game");
            return;
        }
        std::vector<boost::shared_ptr<ServerPlayer> > players = MinecraftServer::GetInstance()->getPlayers()->players;
        for (int32_t i = 0; i < players.size(); i++) {
            wchar_t resultMsg[150];
            swprintf(resultMsg, 150, L"_vnf %ls", args);
            boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, resultMsg, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
            players[i]->listener->send(packet);
        }
    }
    */
    else if (mem::memcmp(args, L"ads", wcslen(L"ads") * sizeof(wchar_t)) == 0) {
        log(L"これは広告です。");
        log(L"HunterClientをインストールしよう!");
    }
    else if (mem::memcmp(args, L"xyz on", wcslen(L"xyz on") * sizeof(wchar_t)) == 0) {
        xyzview = true;
        NotifyMessage(L"XYZ Viewr 1.0a", L"ON!");
    }
    else if (mem::memcmp(args, L"xyz off", wcslen(L"xyz off") * sizeof(wchar_t)) == 0) {
        xyzview = false;
        NotifyMessage(L"XYZ Viewr 1.0a", L"OFF!");
    }
    else if (mem::memcmp(args, L"fps on", wcslen(L"fps on") * sizeof(wchar_t)) == 0) {
        fpsview = true;
        NotifyMessage(L"FPS Viewr 1.0a", L"ON!");
    }
    else if (mem::memcmp(args, L"fps off", wcslen(L"fps off") * sizeof(wchar_t)) == 0) {
        fpsview = false;
        NotifyMessage(L"FPS Viewr 1.0a", L"OFF!");
    }
    else {
        not_found(args);
    }
}

void handleChat(ServerGamePacketListenerImpl *listener, boost::shared_ptr<ClientboundChatPacket> packet) {
    if (packet->str_v[0].size() == 0) return;
	std::basic_string<wchar_t> wcstr = packet->str_v[0];
	wcstr.c_str()[wcstr.size()] = 0x0000;
    wchar_t *id = listener->player->getDisplayName().c_str();
    if (mem::memcmp(wcstr.c_str(), L"_vdm", wcslen(L"_vdm") * sizeof(wchar_t)) == 0) {
        wchar_t *wc = wcstr.c_str();
        wc += wcslen(L"_vdm ");
        if (mem::memcmp(id, L"[Q]", wcslen(L"[Q]") * sizeof(wchar_t)) == 0) {
            id += wcslen(L"[Q] ");
        }
        else if (mem::memcmp(id, L"[Q-DEV]", wcslen(L"[Q-DEV]") * sizeof(wchar_t)) == 0) {
            id += wcslen(L"[Q-DEV] ");
        }
        else if (mem::memcmp(id, L"[P]", wcslen(L"[P]") * sizeof(wchar_t)) == 0) {
            id += wcslen(L"[P] ");
        }
        else if (mem::memcmp(id, L"[P-DEV]", wcslen(L"[P-DEV]") * sizeof(wchar_t)) == 0) {
            id += wcslen(L"[P-DEV] ");
        }
        wchar_t id_buffer[32];
        wchar_t msg[128];
        swscanf(wc, L"%ls%ls", id_buffer, msg);
        wchar_t result[128];
        swprintf(result, 128, L"<from : %ls> %ls", id, msg);
        OnChatPacket(result, id_buffer);
        return;
    }
    else if (mem::memcmp(wcstr.c_str(), L"_vlb", wcslen(L"_vlb") * sizeof(wchar_t)) == 0) {
        wchar_t *wc = wcstr.c_str();
        wc += wcslen(L"_vlb ");
        if (mem::memcmp(listener->player->getDisplayName().c_str(), L"[Q-DEV]", wcslen(L"[Q-DEV]") * sizeof(wchar_t)) == 0) {
            boost::shared_ptr<Player> player = getPlayerByName(Minecraft::GetInstance()->getLevel(0), wc);
            if (player.get() != nullptr) {
                BlockPos position(player.get());
                Entity *lightning_bolt = LightningBolt::Ctor(nullptr, MinecraftServer::GetInstance()->getLevel(0), position.x, position.y, position.z);
                *(void**)lightning_bolt = lightning_bolt;
                ((void(*)(ServerLevel*, boost::shared_ptr<Entity>))0x032BA450)
                (listener->server->getLevel(0), lightning_bolt);
            }
        }
        return;
    }
    wchar_t *msg = wcstr.c_str();
    if (mem::memcmp(id, L"[Q]", wcslen(L"[Q]") * sizeof(wchar_t)) == 0) {
        id += wcslen(L"[Q] ");
    }
    else if (mem::memcmp(id, L"[Q-DEV]", wcslen(L"[Q-DEV]") * sizeof(wchar_t)) == 0) {
        id += wcslen(L"[Q-DEV] ");
    }
    else if (mem::memcmp(id, L"[P]", wcslen(L"[P]") * sizeof(wchar_t)) == 0) {
        id += wcslen(L"[P] ");
    }
        else if (mem::memcmp(id, L"[P-DEV]", wcslen(L"[P-DEV]") * sizeof(wchar_t)) == 0) {
        id += wcslen(L"[P-DEV] ");
    }
	wchar_t result[128];
	swprintf(result, 128, L"<%ls> %ls", id, msg);
	OnChatPacket(result);
}

float getFieldOfViewModifier(AbstractClientPlayer *_this) {
    if (isZoomEnabled) {
        return 0.23f;
    }
    return real_getFieldOfViewModifier(_this);
}

void (*real_renderNameTagInWorld)(Font *font, std::basic_string<wchar_t> wcstr, float f0, float f1, float f2, int32_t i0, float f3, float f4, bool b0, bool b1, int32_t i1, float f5);
// void (*real_handleSoundEvent)(ClientPacketListener *_this, boost::shared_ptr<ClientboundSoundPacket> packet);

void HPIndicator(Font *font, std::basic_string<wchar_t> wcstr, float f0, float f1, float f2, int32_t i0, float f3, float f4, bool b0, bool b1, int32_t i1, float f5) {
    boost::shared_ptr<Player> player = Minecraft::GetInstance()->getLevel(0)->getPlayerByName(wcstr);

    if (player.get() == nullptr) {
        real_renderNameTagInWorld(font, wcstr, f0, f1, f2, i0, f3, f4, b0, b1, i1, f5);
        return;
    }
	
	wchar_t result[100];
	swprintf(result, 100, L"%ls [%.1f]", player->getHealth(), wcstr.c_str());

	wcstr = result;

	real_renderNameTagInWorld(font, wcstr, f0, f1, f2, i0, f3, f4, b0, b1, i1, f5);
}

ButtonCombo<2> button_enable_zoom;
ButtonCombo<1> button_disable_zoom;

Framerate framerate;

void MCRender() {
    if (!inGame) {
        inGame = true;
    }
    wchar_t result[100];
    framerate.count();
    float fps = framerate.getFramerate();
    swprintf(result,100,L"FPS : %.1f",fps);
    std::basic_string<wchar_t> wresult = result;

    if (fps >= 60.1f) {
        wresult = L"FPS : 60.0";
    }

    uint32_t hostip = *(uint32_t*)0x10F9D8EC;

    wchar_t xresult[100];
    wchar_t yresult[100];
    wchar_t zresult[100];
    // wchar_t iresult[100];
    wchar_t cresult[100];

    if (button_enable_zoom.check(*(int32_t*)0x102efa64) && canZoom) {
        isZoomEnabled = true;
    }
    else if (button_disable_zoom.check(*(int32_t*)0x102efa64) && isZoomEnabled && canZoom) {
        isZoomEnabled = false;
    }
    /*
    else if (button_check_cps.check(*(int32_t*)0x102efa64)) {
        ++cps_count;
    }
    */

    /*
    unsigned long long cps_current_time = Minecraft::currentTimeMillis();
    if (cps_current_time - cps_base_time >= 1000)
    {
        cps_rate = (tofloat(cps_count) * 1000.0f) / (tofloat(cps_current_time) - tofloat(cps_base_time));
        cps_base_time = cps_current_time;
        cps_count = 0;
    }
    */

    // float cps = cps_rate;
    // swprintf(cresult, 100, L"CPS : %.1f", cps);

    LocalPlayer *player = Minecraft::GetInstance()->thePlayer;

    double my_x = *(double*)((uint32_t)player + 0x118);
    double my_y = *(double*)((uint32_t)player + 0x120);
    double my_z = *(double*)((uint32_t)player + 0x128);

    swprintf(xresult,100,L"X : %.3lf",my_x);
    swprintf(yresult,100,L"Y : %.3lf",my_y);
    swprintf(zresult,100,L"Z : %.3lf",my_z);
	
    /*
    swprintf(iresult,100,L"Host IP : %d.%d.%d.%d",
    (hostip & 0xFF000000) >> 24,
    (hostip & 0x00FF0000) >> 16,
    (hostip & 0x0000FF00) >> 8,
    (hostip & 0x000000FF));
    */

	GlStateManager::matrixMode(MC_GL_PROJECTION);
    GlStateManager::loadIdentity();
    GlStateManager::ortho(0.0f, 640.0f, 360.0f, 0.0f, 1000.0f, 3000.0f);
    GlStateManager::matrixMode(MC_GL_MODELVIEW);
    GlStateManager::loadIdentity();
    GlStateManager::translatef(0.0f, 0.0f, -2500.0f);
    GlStateManager::disableCull();
    GlStateManager::disableLighting();
    GlStateManager::disableDepthTest();
    GlStateManager::disableTexture();
    GlStateManager::enableBlend();
    GlStateManager::blendFunc(MC_GL_SRC_ALPHA, MC_GL_ONE_MINUS_SRC_ALPHA);

	Font *font = Minecraft::GetInstance()->font;

    if (fpsview)
    {
        GlStateManager::pushMatrix();
        GlStateManager::scalef(2.0f, 2.0f, 2.0f);
        GlStateManager::translatef(1.0f, 1.0f, 0.0f);
        font->drawShadow(wresult, 0, 0, 0xFFFFFFFF);
        GlStateManager::popMatrix();
    }

    if (xyzview)
    {
        GlStateManager::pushMatrix();
        GlStateManager::scalef(2.0f, 2.0f, 2.0f);
        GlStateManager::translatef(1.0f, 1.0f * 8.2f, 0.0f);
        font->drawShadow(xresult, 0, 0, 0xFFFFFFFF);
        GlStateManager::popMatrix();

        GlStateManager::pushMatrix();
        GlStateManager::scalef(2.0f, 2.0f, 2.0f);
        GlStateManager::translatef(1.0f, 2.0f * 8.2f, 0.0f);
        font->drawShadow(yresult, 0, 0, 0xFFFFFFFF);
        GlStateManager::popMatrix();

        GlStateManager::pushMatrix();
        GlStateManager::scalef(2.0f, 2.0f, 2.0f);
        GlStateManager::translatef(1.0f, 3.0f * 8.2f, 0.0f);
        font->drawShadow(zresult, 0, 0, 0xFFFFFFFF);
        GlStateManager::popMatrix();
    }

    /*
    GlStateManager::pushMatrix();
    GlStateManager::scalef(2.0f, 2.0f, 2.0f);
    GlStateManager::translatef(1.0f, 4.0f * 8.2f, 0.0f);
    font->drawShadow(iresult, 0, 0, 0xFFFFFFFF);
    GlStateManager::popMatrix();
    */

    /*
    GlStateManager::pushMatrix();
    GlStateManager::scalef(2.0f, 2.0f, 2.0f);
    GlStateManager::translatef(1.0f, 4.0f * 8.2f, 0.0f);
    font->drawShadow(cresult, 0, 0, 0xFFFFFFFF);
    GlStateManager::popMatrix();
    */

    GlStateManager::pushMatrix();
    GlStateManager::scalef(1.4f, 1.4f, 1.4f);
    GlStateManager::translatef(1.0f, 4.0f * 62.3f, 0.0f);
    font->drawShadow(L"Press L, R and MINUS to open keyboard", 0, 0, 0x67FFFFFF);
    GlStateManager::popMatrix();
}

bool isShowingKeyboard = false;
bool isShowingKeyboardN = false;

void NOTHING(void *ptr, bool unk) {
    CInput *input = CInput::GetInput();
    wchar_t buffer[100];
    input->GetText(buffer, 128);
    wchar_t *buf2 = buffer;
    if (buffer != nullptr) {
        if (mem::memcmp(buf2, L"/q ", wcslen(L"/q ") * sizeof(wchar_t)) == 0) {
            buf2 += wcslen(L"/q ");
            packetHandler(buf2);
            isShowingKeyboard = false;
            return;
        }
        boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, buf2, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
        Minecraft::GetInstance()->thePlayer->listener->send(packet);

        isShowingKeyboard = false;
    }
}

bool isKbdInitialized = false;
bool isKbdInitializedN = false;
bool requestJoin = false;
char *joinNNID = nullptr;

void handleKbd(void *ptr, bool unk) {
    if (isInWorld) {
        isShowingKeyboardN = false;
        return;
    }
    int *op = (int *)0x10000000;
    (*op)++;
    CInput *input = CInput::GetInput();
    wchar_t buffer[128];
    input->GetText(buffer, 128);
    wchar_t *buf2 = buffer;
    if (buf2 != nullptr) {
        if (mem::memcmp(buf2, L"/q ", wcslen(L"/q ") * sizeof(wchar_t)) == 0) {
            buf2 += wcslen(L"/q ");
            if (mem::memcmp(buf2, L"join ", wcslen(L"join ") * sizeof(wchar_t)) == 0) {
                buf2 += wcslen(L"join ");
                const char *cId = convUtf16ToUtf8(buf2);
                joinNNID = (char*)cId;
                requestJoin = true;
                // mem::free((void*)buf0);
                // mem::free((void*)cId);
                isShowingKeyboardN = false;
                return;
            }
            isShowingKeyboardN = false;
            return;
        }

        isShowingKeyboardN = false;
    }
}

void ShowKeyboardN() {
    CInput *input = CInput::GetInput();
    int32_t pushed_button_id = *(int32_t*)0x102efa64;
    if (pushed_button_id == 0x34 && isShowingKeyboardN == false) {
        input->RequestKeyboard(L"", L"", 0, 128, (int(*)(void *, bool))handleKbd, nullptr, 4);
        isShowingKeyboardN = true;
    }
}

void ShowKeyboard() {
    CInput *input = CInput::GetInput();
    int32_t pushed_button_id = *(int32_t*)0x102efa64;
    if (pushed_button_id == 0x34 && isShowingKeyboard == false) {
        if (!isKbdInitialized) {
            input->RequestKeyboard(L"", L"", 0, 128, (int(*)(void *, bool))NOTHING, nullptr, 4);
            isShowingKeyboard = true;
            isKbdInitialized = true;
            return;
        }
        input->RequestKeyboard(L"", L"", 0, 128, (int(*)(void *, bool))NOTHING, nullptr, 5);
        isShowingKeyboard = true;
    }
    /*
	// [[0x10A90E6C] + 0x288] + 0x1000
	if (get_value(swkbd_address, 0) == 0 && isShowingKeyboardByChatClient == true) {
		// [[[[0x10A8915C] + 0x1000] + 0x1008] + 0x1C] - 0x1537CC
		int32_t kbd_value = get_value(get_value(get_value(get_value(0x10A8915C, 0), 0x1000), 0x1008), 0x1c) - 0x1537cc;
		wchar_t *msg = (wchar_t*)kbd_value;
        log(msg);
        if (mem::memcmp(msg, L"/q ", wcslen(L"/q ") * sizeof(wchar_t)) == 0) {
            msg[wcslen(msg) - 1] = 0x0000;
            msg += 3;
            packetHandler(msg);
            isShowingKeyboardByChatClient = false;
            return;
        }
		boost::shared_ptr<Packet> packet(ClientboundChatPacket::Ctor(nullptr, msg, ClientboundChatPacket::EChatPacketMessage::unk_0, 0));
		Minecraft::GetInstance()->thePlayer->listener->send(packet);

		isShowingKeyboardByChatClient = false;
	}
    */
}


/*
void RenderSounds() {
    GlStateManager::matrixMode(MC_GL_PROJECTION);
    GlStateManager::loadIdentity();
    GlStateManager::ortho(0.0f, 640.0f, 360.0f, 0.0f, 1000.0f, 3000.0f);
    GlStateManager::matrixMode(MC_GL_MODELVIEW);
    GlStateManager::loadIdentity();
    GlStateManager::translatef(0.0f, 0.0f, -2500.0f);
    GlStateManager::disableCull();
    GlStateManager::disableLighting();
    GlStateManager::disableDepthTest();
    GlStateManager::disableTexture();
    GlStateManager::enableBlend();
    GlStateManager::blendFunc(MC_GL_SRC_ALPHA, MC_GL_ONE_MINUS_SRC_ALPHA);

    Font *font = Minecraft::GetInstance()->font;
    for (int32_t i = 0; i < current_playing_count; i++) {
        GlStateManager::pushMatrix();
        GlStateManager::scalef(1.4f, 1.4f, 1.4f);
        GlStateManager::translatef(300.0f, 4.0f * 62.3f - (i * 4.0f), 0.0f);
        font->drawShadow(playing_sound[i], 0, 0, 0x67FFFFFF);
        GlStateManager::popMatrix();
    }
}
*/

unsigned char *img;
int img_size;

unsigned char *load_img;
int load_img_size;

void RenderIcon(int id, float sizeX, float sizeY, float x, float y, float z) {
    GlStateManager::matrixMode(MC_GL_PROJECTION);
    GlStateManager::loadIdentity();
    GlStateManager::ortho(0.0f, 640.0f, 360.0f, 0.0f, 1000.0f, 3000.0f);
    GlStateManager::matrixMode(MC_GL_MODELVIEW);
    GlStateManager::loadIdentity();
    GlStateManager::translatef(0.0f, 0.0f, -2500.0f);
    GlStateManager::disableCull();
    GlStateManager::disableLighting();
    GlStateManager::disableDepthTest();
    GlStateManager::disableTexture();
    GlStateManager::enableBlend();
    GlStateManager::depthMask(0);
    GlStateManager::blendFunc(MC_GL_SRC_ALPHA, MC_GL_ONE_MINUS_SRC_ALPHA);
    GlStateManager::color4f(1.0f, 1.0f, 1.0f, 1.0f);
    GlStateManager::disableAlphaTest();

    BufferBuilder *builder = Tesselator::getInstance()->getBuilder();

    Minecraft::GetInstance()->textures->bind(id);

    GlStateManager::pushMatrix();
    GlStateManager::translatef(x, y, z);
    builder->begin();
    builder->vertexUV(0.0f, sizeY, -90.0f, 0.0f, 1.0f);
    builder->vertexUV(sizeX, sizeY, -90.0f, 1.0f, 1.0f);
    builder->vertexUV(sizeX, 0.0f, -90.0f, 1.0f, 0.0f);
    builder->vertexUV(0.0f, 0.0f, -90.0f, 0.0f, 0.0f);
    builder->end();
    GlStateManager::popMatrix();

    GlStateManager::pushMatrix();
    GlStateManager::translatef(x, y, z);
    builder->begin();
    builder->vertexUV(0.0f, sizeY, -90.0f, 0.0f, 1.0f);
    builder->vertexUV(sizeX, sizeY, -90.0f, 1.0f, 1.0f);
    builder->vertexUV(sizeX, 0.0f, -90.0f, 1.0f, 0.0f);
    builder->vertexUV(0.0f, 0.0f, -90.0f, 0.0f, 0.0f);
    builder->end();
    GlStateManager::popMatrix();
}

bool canPress = true;

void CountCPS() {
    unsigned long long now = Minecraft::currentTimeMillis();
    if (now - basetime >= 1000)
    {
        clicks = (tofloat(count) * 1000.0f) / (tofloat(now) - tofloat(basetime));
        basetime = now;
        count = 0;
    }
}

int texture_icon_id;
int texture_load_id;

int registerTexture(unsigned char *buffer) {
    if (not_inGame_isInitialized == true) return 0;
    BufferedImage *image = BufferedImage::Ctor(nullptr, buffer, img_size);

    int32_t id = GlStateManager::genTexture();
    Minecraft::GetInstance()->textures->loadTexture(image, id);

    return id;
}

unsigned long long time_base_load = Minecraft::currentTimeMillis();
bool loading = true;
bool LOADisInitialized = false;


void (*real_draw)(Font *_this, std::basic_string<wchar_t> wcstr, bool unk_b0, bool unk_b1);

float hue = 0.0f;

void draw(Font *_this, std::basic_string<wchar_t> wcstr, bool unk_b0, bool unk_b1) {
    if (mem::memcmp(wcstr.c_str(), L"[Q-DEV] Quarky-314", wcslen(L"[Q-DEV] Quarky-314") * sizeof(wchar_t)) == 0 || mem::memcmp(wcstr.c_str(), L"[Q-DEV] kazu2204", wcslen(L"[Q-DEV] kazu2204") * sizeof(wchar_t)) == 0 ) {
        int32_t rgb = hsvToRgb(hue, 1.0f, 1.0f);
        uint8_t r = ((rgb) & 0x00FF0000) >> 16;
        uint8_t g = ((rgb) & 0x0000FF00) >> 8;
        uint8_t b = ((rgb) & 0x000000FF) >> 0;
        GlStateManager::color3f(r / 255.0, g / 255.0, b / 255.0);
    }
    real_draw(_this, wcstr, unk_b0, unk_b1);
}

bool isQuarkyInWorld = false;

void particle() {
    if (!CGameNetworkManager::GetNetworkManager()->IsHost()) return;

    if (!isQuarkyInWorld) return;

    boost::shared_ptr<Player> player = getPlayerByName(MinecraftServer::GetInstance()->getLevel(0), L"[Q-DEV] Quarky-314");
    if (player.get() != nullptr) {
        Vec3 v_p = player->position;
        ParticleType *particle_type = ParticleType::byId(ParticleType::ePARTICLE_TYPE::heart);
        *(int32_t*)0x40000000 = 0x1;
        arrayWithLength<int32_t> awl;
        int32_t *unk = (int32_t*)0x40000000;
        awl.length = 1;
        awl.elements = unk;
        boost::shared_ptr<Packet> packet(ClientboundLevelParticlesPacket::Ctor(nullptr, particle_type, particle_type->getOverrideLimiter(), v_p.x, v_p.y, v_p.z, v_p.x, v_p.y - 2.0f, v_p.z, 0.0f, particle_type->getParamCount(), awl));
        MinecraftServer::GetInstance()->getPlayers()->broadcastAll(packet);
        // ((ServerPlayer*)player.get())->listener->send();
    }
}

unsigned long long starttime = 0;
unsigned long long current_particle_time = 0;

void CALLING() {
    if (!isInitialized) {
        isInitialized = true;
    }
    if (isRenderAllowed)
        MCRender();
    ShowKeyboard();
    if (grapplerEnabled == true) {
        GrapplingHook();
    }
}

void MCNotInGame() {
    isInWorld = false;
    if (!LOADisInitialized) {
        LOADisInitialized = true;
    }
    ShowKeyboardN();
}

/*
void handleSoundEvent(ClientPacketListener *_this, boost::shared_ptr<ClientboundSoundPacket> packet) {
    playing_sound[current_playing_count] = packet->getSound()->getName().c_str();
    current_playing_count++;

    real_handleSoundEvent(_this, packet);
}
*/

int MainThread(int argc, void* argv) {
	uint64_t title_id = OSGetTitleID();
	if(title_id != 0x00050000101dbe00) return 0;

    button_enable_zoom.init().setButton(0, 0x80).setButton(1, 0x80).setRelease(true).start();
    button_disable_zoom.init().setButton(0, 0x40).setRelease(true).start();

    // cps_base_time = Minecraft::currentTimeMillis();

	kernel_write_value((void*)0x031B2B4C, 0x38600001L);
    kernel_write_value((void*)0x03415730, 0x387F0968L);
    kernel_write_value((void*)0x02F5C874, 0x38600001L);
	
	uint32_t hook_CALLING[4] = {
        0x3D800000UL | ((uint32_t)&CALLING >> 16),
        0x618C0000UL | ((uint32_t)&CALLING & 0xFFFF),
        0x7D8903A6UL,
        0x4E800421UL
    };

    uint32_t hook_MCNotInGame[4] = {
        0x3D800000UL | ((uint32_t)&MCNotInGame >> 16),
        0x618C0000UL | ((uint32_t)&MCNotInGame & 0xFFFF),
        0x7D8903A6UL,
        0x4E800421UL
    };

    //BA C1 00 50 80 01 00 7C  7C 08 03 A6 38 21 00 78

    uint32_t hook_neighborChanged_check_nullptr[7] = {
        0x28030000,
        0x40A20018,
        0xBAC10050,
        0x8001007C,
        0x7C0803A6,
        0x38210078,
        0x4E800020
    };

    uint32_t hook_loadFromTag_check_nullptr[2] = {
        0x28030000,
        0x4D820020
    };

    uint32_t hook_setBoxedValueg_check_nullptr[17] = {
        0x28030000,
        0x40A20040,
        0x3D800218,
        0x398CBF50,
        0x7D8903A6,
        0xA0DF0014,
        0x7FC5F378,
        0x7FA4EB78,
        0x807F0010,
        0x4E800421,
        0x83A1000C,
        0x8001001C,
        0x83C10010,
        0x7C0803A6,
        0x83E10014,
        0x38210018,
        0x4E800020
    };

    uint32_t hook_read_check_nullptr[12] = {
        0x281E0000,
        0x40A2002C,
        0x281F0000,
        0x40A20024,
        0x83810028,
        0x83A1002C,
        0x8001003C,
        0x83C10030,
        0x7C0803A6,
        0x83E10034,
        0x38210038,
        0x4E800020
    };

    /*
    uint32_t hook_tick_check_nullptr[22] = {
        0x28060000,
        0x40A20054,
        0xBA2100D4,
        0xC3C10168,
        0xC3810148,
        0xCBC10160,
        0xC3610138,
        0xCB810140,
        0xCB610130,
        0xC3410128,
        0xC3A10158,
        0xCB410120,
        0xCBA10150,
        0xC3210118,
        0xC3E10178,
        0xCB210110,
        0xCBE10170,
        0x4C00012C,
        0x80010184,
        0x7C0803A6,
        0x38210180,
        0x4E800020
    };
    */

    uint32_t hook_tick_check_nullptr[22] = {
        0x28060000,
        0x40A20004,
        0xBA2100D4,
        0xC3C10168,
        0xC3810148,
        0xCBC10160,
        0xC3610138,
        0xCB810140,
        0xCB610130,
        0xC3410128,
        0xC3A10158,
        0xCB410120,
        0xCBA10150,
        0xC3210118,
        0xC3E10178,
        0xCB210110,
        0xCBE10170,
        0x4C00012C,
        0x80010184,
        0x7C0803A6,
        0x38210180,
        0x4E800020
    };

    /*
    uint32_t hook_tick_check_nullptr[22] = {
        0x28030000,
        0x40A20054,
        0xBA2100D4,
        0xC3C10168,
        0xC3810148,
        0xCBC10160,
        0xC3610138,
        0xCB810140,
        0xCB610130,
        0xC3410128,
        0xC3A10158,
        0xCB410120,
        0xCBA10150,
        0xC3210118,
        0xC3E10178,
        0xCB210110,
        0xCBE10170,
        0x4C00012C,
        0x80010184,
        0x7C0803A6,
        0x38210180,
        0x4E800020
    };
    */

    /*
    uint32_t hook_dispense_check_nullptr[7] = {
        0x28030000,
        0x40A20018,
        0xBB61001C,
        0x80010034,
        0x7C0803A6,
        0x38210030,
        0x4E800020
    };

    uint32_t hook_copy_check_nullptr[7] = {
        0x28055000,
        0x40A00018,
        0xBB410020,
        0x8001003C,
        0x7C0803A6,
        0x38210038,
        0x4E800020
    };
    */

    uint32_t hook_getWidth[3] = {
        0x28031000,
        0x40A10008,
        0x4E800020
    };

    uint32_t hook_getHeight[3] = {
        0x28031000,
        0x40A00008,
        0x4E800020
    };

    uint32_t hook_UpdateStatusEffectTile[22] = {
        0x28161000,
        0x40A00054,
        0xBAC10010,
        0xC3C10090,
        0xC3810070,
        0xCBC10088,
        0xC3610060,
        0xCB810068,
        0xCB610058,
        0xC3410050,
        0xC3A10080,
        0xCB410048,
        0xCBA10078,
        0xC3210040,
        0xC3E100A0,
        0xCB210038,
        0xCBE10098,
        0x4C00012C,
        0x800100AC,
        0x7C0803A6,
        0x382100A8,
        0x4E800020
    };

    /*
    uint32_t hook_copy_check_nullptr[2] = {
        0x28030000,
        0x4D820020
    };
    */

    uint32_t hook_dispense_check_nullptr[7] = {
        0x28030000,
        0x40A20018,
        0xBB61001C,
        0x80010034,
        0x7C0803A6,
        0x38210030,
        0x4E800020
    };

    uint32_t hook_copy_check_value[7] = {
        0x3D801058,
        0x618CFA54,
        0x7C0C2840,
        0x3D800248,
        0x618C7164,
        0x7D8903A6,
        0x4C820420
    };

    // handleChat

	MinecraftPatcher::injectInstruction((void *)0x02D9CAC0, hook_CALLING, sizeof(hook_CALLING));
    MinecraftPatcher::injectInstruction((void *)0x02D9C8B0, hook_MCNotInGame, sizeof(hook_MCNotInGame));
    MinecraftPatcher::injectInstruction((void *)0x022B4DFC, hook_neighborChanged_check_nullptr, sizeof(hook_neighborChanged_check_nullptr));
    MinecraftPatcher::injectInstruction((void *)0x028C6EB4, hook_loadFromTag_check_nullptr, sizeof(hook_loadFromTag_check_nullptr));
    MinecraftPatcher::injectInstruction((void *)0x0217C224, hook_setBoxedValueg_check_nullptr, sizeof(hook_setBoxedValueg_check_nullptr));
    MinecraftPatcher::injectInstruction((void *)0x0299FEF8, hook_read_check_nullptr, sizeof(hook_read_check_nullptr));
    MinecraftPatcher::injectInstruction((void *)0x0206A37C, hook_tick_check_nullptr, sizeof(hook_tick_check_nullptr));
    // MinecraftPatcher::injectInstruction((void *)0x0206A0F0, hook_tick_check_nullptr, sizeof(hook_tick_check_nullptr));
    kernel_write_value((void *)0x0206A3A8, 0x80C10010);
    // MinecraftPatcher::injectInstruction((void *)0x02487150, hook_copy_check_value, sizeof(hook_copy_check_value));
    // MinecraftPatcher::injectInstruction((void *)0x022ABC88, hook_dispense_check_nullptr, sizeof(hook_dispense_check_nullptr));
    // kernel_write_value((void *)0x22ABB40, 0x4E800020L);
    // MinecraftPatcher::injectInstruction((void *)0x02487150, hook_copy_check_nullptr, sizeof(hook_copy_check_nullptr));
    // MinecraftPatcher::injectInstruction((void *)0x02B56960, hook_UpdateStatusEffectTile, sizeof(hook_UpdateStatusEffectTile));
    // MinecraftPatcher::injectInstruction((void *)0x02AFB32C, hook_getWidth, sizeof(hook_getWidth));
    // MinecraftPatcher::injectInstruction((void *)0x02AFB340, hook_getHeight, sizeof(hook_getHeight));
    // MinecraftPatcher::injectInstruction((void *)0x02486E20, hook_copy_check_nullptr, sizeof(hook_copy_check_nullptr));
    MinecraftPatcher::replaceFunction((void *)0x032E68A4, (void *)&handleChat);
    // real_getWidth = (decltype(real_getWidth))MinecraftPatcher::replaceFunction((void *)0x02AFB32C, (void *)&getWidth);
    // real_getHeight = (decltype(real_getHeight))MinecraftPatcher::replaceFunction((void *)0x02AFB340, (void *)&getHeight);
    // kernel_write_value((void *)0x02AFB340, 0x4E800020L);
    // kernel_write_value((void *)0x02AFB32C, 0x4E800020L);
    // real_copy = (decltype(real_copy))MinecraftPatcher::replaceFunction((void *)0x02486E20, (void *)&copy);
    // real_UpdateStatusEffectTile = (decltype(real_UpdateStatusEffectTile))MinecraftPatcher::replaceFunction((void *)0x02B563FC, (void *)&UpdateStatusEffectTile);
    real_retrieve = (decltype(real_retrieve))MinecraftPatcher::replaceFunction((void *)0x0241557C, (void *)&retrieve);
	real_renderNameTagInWorld = (decltype(real_renderNameTagInWorld))MinecraftPatcher::replaceFunction((void*)0x030E9C14, (void*)&HPIndicator);
    real_getFieldOfViewModifier = (decltype(real_getFieldOfViewModifier))MinecraftPatcher::replaceFunction((void*)0x02F6F6D0, (void*)&getFieldOfViewModifier);
    real_renderSkull = (decltype(real_renderSkull))MinecraftPatcher::replaceFunction((void*)0x0334dc70, (void*)&renderSkull);
    real_handlePlayerAction = (decltype(real_handlePlayerAction))MinecraftPatcher::replaceFunction((void*)0x032DFF9C, (void*)&handlePlayerAction);
    real_draw = (decltype(real_draw))MinecraftPatcher::replaceFunction((void*)0x030E9534, (void*)&draw);
    real__ExitWorld = (decltype(real__ExitWorld))MinecraftPatcher::replaceFunction((void *)0x02F2CAF4, (void*)&_ExitWorld);
    // real_SetPresenceString = (decltype(real_SetPresenceString))MinecraftPatcher::replaceFunction((void*)0x034114F4, (void*)&SetPresenceString);
    // real_handleChat = (decltype(real_handleChat))MinecraftPatcher::replaceFunction((void*)0x03054C08, (void*)&client_handleChat);
    // real_Ctor_PreLoginPacket = (decltype(real_Ctor_PreLoginPacket))MinecraftPatcher::replaceFunction((void*)0x028AFC9C, (void*)&CtorPreLogin);
    // real_handleSoundEvent = (decltype(real_handleSoundEvent))MinecraftPatcher::replaceFunction((void*)0x0306EB2C, (void*)&handleSoundEvent);


	return 0;

}