#ifndef __PROGRAM_H__
#define __PROGRAM_H__

int MainThread(int argc, void* argv);

#endif