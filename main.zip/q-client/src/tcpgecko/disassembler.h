#ifndef TCPGECKO_DISASSEMBLER_H
#define TCPGECKO_DISASSEMBLER_H

void formatDisassembled(char *format, ...);

#endif