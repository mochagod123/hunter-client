#ifndef TCPGECKO_SD_CHEATS_H
#define TCPGECKO_SD_CHEATS_H

void considerApplyingSDCheats();

#endif